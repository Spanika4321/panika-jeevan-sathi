import Link from "next/link";
import { requireUser } from "@/lib/auth";
import { getMiniProfile } from "@/lib/data";
import { searchParam } from "@/lib/utils";
import { Avatar, NoticeBar, SectionHeading } from "@/components/ui";

export const dynamic = "force-dynamic";

type ReportUserPageProps = {
  searchParams: Promise<Record<string, string | string[] | undefined>>;
};

export default async function ReportUserPage({ searchParams }: ReportUserPageProps) {
  const params = await searchParams;
  await requireUser();
  const targetUserId = Number.parseInt(searchParam(params, "userId"), 10);
  const profile = Number.isFinite(targetUserId) ? await getMiniProfile(targetUserId) : null;

  return (
    <div className="mx-auto max-w-3xl px-4 py-8 sm:px-6 lg:px-8">
      <NoticeBar notice={searchParam(params, "notice")} error={searchParam(params, "error")} />
      <SectionHeading eyebrow="Report User" title="Report a safety concern">
        Reports are reviewed by the admin team. Use this for suspicious behavior, fraud, harassment, fake details or unsafe requests.
      </SectionHeading>
      <div className="rounded-[2rem] bg-white p-6 shadow-xl shadow-slate-200/70">
        {profile ? <div className="mb-5 flex items-center gap-3 rounded-2xl bg-slate-50 p-4"><Avatar profile={profile} /><div><p className="font-black text-[#1E1B4B]">{profile.fullName}</p><Link href={`/profile/${profile.userId}`} className="text-sm font-bold text-[#F43F5E]">View profile</Link></div></div> : <p className="mb-5 rounded-2xl bg-amber-50 p-4 text-sm font-bold text-amber-800">Please open a profile and use Report Profile so the correct user is selected.</p>}
        <form action="/api/actions" method="post" className="space-y-4">
          <input type="hidden" name="action" value="reportProfile" />
          <input type="hidden" name="reportedUserId" value={Number.isFinite(targetUserId) ? targetUserId : ""} />
          <label className="block text-sm font-bold text-slate-700">Reason<select name="reason" className="mt-2 w-full rounded-2xl border border-slate-200 px-4 py-3"><option>Fake or misleading profile</option><option>Asking for money</option><option>Harassment or abusive messages</option><option>Suspicious identity</option><option>Other safety concern</option></select></label>
          <label className="block text-sm font-bold text-slate-700">Details<textarea name="details" rows={5} className="mt-2 w-full rounded-2xl border border-slate-200 px-4 py-3" placeholder="Share clear details for admin review." /></label>
          <button className="w-full rounded-full bg-[#F43F5E] px-6 py-3 font-black text-white shadow-lg shadow-rose-500/25">Submit Report</button>
        </form>
      </div>
    </div>
  );
}
