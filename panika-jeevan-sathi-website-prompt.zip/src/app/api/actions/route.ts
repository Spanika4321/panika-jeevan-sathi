import { NextRequest, NextResponse } from "next/server";
import { and, desc, eq, gt, isNull, or } from "drizzle-orm";
import { db } from "@/db";
import {
  adminUsers,
  announcements,
  blocks,
  comments,
  conversationParticipants,
  conversations,
  emailOtps,
  interests,
  messages,
  notifications,
  partnerPreferences,
  passwordResetTokens,
  photos,
  postLikes,
  posts,
  profileLikes,
  privacySettings,
  profiles,
  reports,
  shortlists,
  users,
  verificationRequests,
} from "@/db/schema";
import { ADMIN_EMAIL, ADMIN_NAME, APP_NAME } from "@/lib/constants";
import {
  clearSessionCookie,
  createSession,
  ensureAdminUser,
  getCurrentUser,
  isAdminUser,
  setSessionCookie,
} from "@/lib/auth";
import { sendOtpEmail, sendPasswordResetEmail } from "@/lib/email";
import {
  addMinutes,
  generateOtp,
  hashPassword,
  hashSecret,
  isStrongPassword,
  randomToken,
  verifyPassword,
} from "@/lib/security";
import { canUsersMessage, createMatchForAcceptedInterest, createNotification, findOrCreateConversation, getOtherParticipant } from "@/lib/mutations";
import { calculateAge, cleanPhone, getBool, getInt, getOptionalString, getString, normalizeEmail, safeReturnTo } from "@/lib/utils";

export const dynamic = "force-dynamic";

function getPublicOrigin(req: NextRequest): string {
  const forwardedHost = req.headers.get("x-forwarded-host") || req.headers.get("host");
  const forwardedProto = req.headers.get("x-forwarded-proto") || (req.url.startsWith("https") ? "https" : "http");
  if (forwardedHost) {
    return `${forwardedProto}://${forwardedHost}`;
  }
  return req.nextUrl.origin;
}

function wantsJson(req: NextRequest, formData: FormData) {
  return req.headers.get("accept")?.includes("application/json") || getString(formData, "_json") === "1";
}

function respond(req: NextRequest, formData: FormData, ok: boolean, message: string, redirectTo?: string) {
  if (wantsJson(req, formData)) {
    return NextResponse.json({ ok, message, redirectTo }, { status: ok ? 200 : 400 });
  }
  const destination = safeReturnTo(redirectTo || getString(formData, "returnTo") || "/", "/");
  const origin = getPublicOrigin(req);
  const url = new URL(destination, origin);
  url.searchParams.set(ok ? "notice" : "error", message);
  return NextResponse.redirect(url, 303);
}

function parseTargetId(formData: FormData, key = "targetUserId") {
  const parsed = getInt(formData, key);
  return parsed && parsed > 0 ? parsed : null;
}

async function requireActionUser(req: NextRequest, formData: FormData) {
  const user = await getCurrentUser();
  if (!user) return { user: null, response: respond(req, formData, false, "Please login to continue.", "/login") };
  if (user.status === "suspended") {
    return { user: null, response: respond(req, formData, false, "Your account is suspended. Please contact support.", "/settings") };
  }
  if (!user.emailVerified) {
    return { user: null, response: respond(req, formData, false, "Please verify your email first.", "/verify-otp?email=" + encodeURIComponent(user.email)) };
  }
  return { user, response: null };
}

async function requireActionAdmin(req: NextRequest, formData: FormData) {
  const { user, response } = await requireActionUser(req, formData);
  if (!user) return { admin: null, response };
  if (!(await isAdminUser(user))) {
    return { admin: null, response: respond(req, formData, false, "Admin permission required.", "/") };
  }
  return { admin: await ensureAdminUser(user), response: null };
}

async function handleRegister(req: NextRequest, formData: FormData) {
  const fullName = getString(formData, "fullName");
  const gender = getString(formData, "gender");
  const dateOfBirth = getOptionalString(formData, "dateOfBirth");
  const email = normalizeEmail(getString(formData, "email"));
  const mobile = cleanPhone(getString(formData, "mobile"));
  const password = getString(formData, "password");
  const age = calculateAge(dateOfBirth);

  if (fullName.length < 2) return respond(req, formData, false, "Please enter your full name.");
  if (!gender) return respond(req, formData, false, "Please select gender.");
  if (!dateOfBirth || !age || age < 18) return respond(req, formData, false, "You must be at least 18 years old to register.");
  if (!email.includes("@")) return respond(req, formData, false, "Please enter a valid email address.");
  if (mobile.length < 8) return respond(req, formData, false, "Please enter a valid mobile number.");
  if (!isStrongPassword(password)) return respond(req, formData, false, "Password must be at least 8 characters and include letters and numbers.");

  const existing = await db
    .select({ id: users.id })
    .from(users)
    .where(or(eq(users.email, email), eq(users.mobile, mobile)))
    .limit(1);
  if (existing.length > 0) return respond(req, formData, false, "An account already exists with this email or mobile.", "/login");

  const otp = generateOtp();
  const photoUrl = getOptionalString(formData, "profilePhotoUrl");
  const safePhotoUrl = photoUrl && photoUrl.length < 750_000 ? photoUrl : null;
  const isConfiguredAdmin = email === ADMIN_EMAIL.toLowerCase();

  const userId = await db.transaction(async (tx) => {
    const insertedUsers = await tx
      .insert(users)
      .values({
        fullName,
        gender,
        dateOfBirth,
        email,
        mobile,
        passwordHash: hashPassword(password),
        role: isConfiguredAdmin ? "admin" : "member",
        status: "email_pending",
        emailVerified: false,
      })
      .returning({ id: users.id });

    const createdUserId = insertedUsers[0]!.id;

    await tx.insert(profiles).values({
      userId: createdUserId,
      displayName: fullName,
      profilePhotoUrl: safePhotoUrl,
      about: getOptionalString(formData, "about"),
      religion: getOptionalString(formData, "religion"),
      community: getOptionalString(formData, "community"),
      motherTongue: getOptionalString(formData, "motherTongue"),
      maritalStatus: getOptionalString(formData, "maritalStatus"),
      education: getOptionalString(formData, "education"),
      profession: getOptionalString(formData, "profession"),
      income: getInt(formData, "income"),
      location: getOptionalString(formData, "location"),
      approvalStatus: "pending",
      verificationStatus: "unverified",
      visibility: "public",
    });

    await tx.insert(partnerPreferences).values({
      userId: createdUserId,
      lookingFor: gender === "Male" ? "Female" : gender === "Female" ? "Male" : null,
      description: getOptionalString(formData, "partnerPreference"),
    });

    await tx.insert(privacySettings).values({ userId: createdUserId, hidePhone: true, hideEmail: true, profileVisibility: "public" });

    if (safePhotoUrl) {
      await tx.insert(photos).values({ userId: createdUserId, url: safePhotoUrl, isPrimary: true, approvalStatus: "pending" });
    }

    if (isConfiguredAdmin) {
      await tx
        .insert(adminUsers)
        .values({ userId: createdUserId, name: ADMIN_NAME, email: ADMIN_EMAIL.toLowerCase(), role: "owner", isActive: true })
        .onConflictDoNothing();
    }

    await tx.insert(emailOtps).values({
      userId: createdUserId,
      email,
      codeHash: hashSecret(otp),
      purpose: "registration",
      expiresAt: addMinutes(15),
    });

    return createdUserId;
  });

  await createNotification({
    userId,
    type: "welcome",
    title: `Welcome to ${APP_NAME}`,
    body: "Verify your email OTP. Your profile will become publicly visible after admin approval.",
    linkUrl: "/profile",
  });

  await sendOtpEmail(email, otp);
  return respond(req, formData, true, "Registration successful. Please enter the verification OTP sent to your email.", `/verify-otp?email=${encodeURIComponent(email)}`);
}

async function handleResendOtp(req: NextRequest, formData: FormData) {
  const email = normalizeEmail(getString(formData, "email"));
  if (!email.includes("@")) return respond(req, formData, false, "Please enter a valid email address.");

  const row = await db.select({ id: users.id, email: users.email, emailVerified: users.emailVerified }).from(users).where(eq(users.email, email)).limit(1);
  const user = row[0];
  if (!user) return respond(req, formData, false, "No account found for this email.");
  if (user.emailVerified) return respond(req, formData, true, "Your email is already verified. Please login.", "/login");

  const recentOtp = await db
    .select({ createdAt: emailOtps.createdAt })
    .from(emailOtps)
    .where(and(eq(emailOtps.userId, user.id), eq(emailOtps.purpose, "registration")))
    .orderBy(desc(emailOtps.createdAt))
    .limit(1);

  if (recentOtp[0]) {
    const elapsedMs = Date.now() - new Date(recentOtp[0].createdAt).getTime();
    if (elapsedMs < 60_000) {
      const waitSec = Math.ceil((60_000 - elapsedMs) / 1000);
      return respond(req, formData, false, `Please wait ${waitSec} seconds before requesting another OTP.`);
    }
  }

  const otp = generateOtp();
  await db.insert(emailOtps).values({ userId: user.id, email, codeHash: hashSecret(otp), purpose: "registration", expiresAt: addMinutes(15) });
  await sendOtpEmail(email, otp);
  return respond(req, formData, true, "A new OTP has been sent to your email.", `/verify-otp?email=${encodeURIComponent(email)}`);
}

async function handleVerifyOtp(req: NextRequest, formData: FormData) {
  const email = normalizeEmail(getString(formData, "email"));
  const otp = getString(formData, "otp").trim();
  if (!otp) return respond(req, formData, false, "Please enter the OTP.");

  const userRows = await db.select({ id: users.id, email: users.email }).from(users).where(eq(users.email, email)).limit(1);
  const user = userRows[0];
  if (!user) return respond(req, formData, false, "Account not found for this email.");

  const otpRows = await db
    .select()
    .from(emailOtps)
    .where(and(eq(emailOtps.userId, user.id), eq(emailOtps.purpose, "registration"), isNull(emailOtps.consumedAt), gt(emailOtps.expiresAt, new Date())))
    .orderBy(desc(emailOtps.createdAt))
    .limit(1);

  const latest = otpRows[0];
  if (!latest) return respond(req, formData, false, "OTP expired or invalid. Please request a new OTP.");
  if (latest.attempts >= 5) {
    return respond(req, formData, false, "Too many failed attempts. Please request a new OTP.");
  }

  if (latest.codeHash !== hashSecret(otp)) {
    await db.update(emailOtps).set({ attempts: latest.attempts + 1 }).where(eq(emailOtps.id, latest.id));
    return respond(req, formData, false, "Invalid OTP. Please check and try again.");
  }

  await db.update(emailOtps).set({ consumedAt: new Date() }).where(eq(emailOtps.id, latest.id));
  await db.update(users).set({ emailVerified: true, status: "active", updatedAt: new Date() }).where(eq(users.id, user.id));

  if (email === ADMIN_EMAIL.toLowerCase()) {
    await db.update(users).set({ role: "admin", updatedAt: new Date() }).where(eq(users.id, user.id));
    await db
      .insert(adminUsers)
      .values({ userId: user.id, name: ADMIN_NAME, email: ADMIN_EMAIL.toLowerCase(), role: "owner", isActive: true })
      .onConflictDoNothing();
  }

  await createNotification({
    userId: user.id,
    type: "profile_review",
    title: "Email verified successfully",
    body: "Your email is verified. Admin approval is required before your profile appears in public search.",
    linkUrl: "/profile",
  });

  return respond(req, formData, true, "Email verified successfully. You can now login.", "/login");
}

async function handleLogin(req: NextRequest, formData: FormData) {
  const identifier = getString(formData, "identifier").toLowerCase();
  const password = getString(formData, "password");
  const returnTo = safeReturnTo(getString(formData, "returnTo"), "/profile");

  const rows = await db
    .select()
    .from(users)
    .where(or(eq(users.email, identifier), eq(users.mobile, cleanPhone(identifier))))
    .limit(1);
  const user = rows[0];

  if (!user || !verifyPassword(password, user.passwordHash)) {
    return respond(req, formData, false, "Invalid email/mobile or password.", "/login");
  }
  if (user.status === "deleted") return respond(req, formData, false, "This account has been deleted.", "/login");
  if (user.status === "suspended") return respond(req, formData, false, "This account is suspended. Please contact support.", "/login");
  if (!user.emailVerified) {
    return respond(req, formData, false, "Please verify your email OTP before logging in.", `/verify-otp?email=${encodeURIComponent(user.email)}`);
  }

  if (user.email.toLowerCase() === ADMIN_EMAIL.toLowerCase()) {
    await ensureAdminUser({
      id: user.id,
      fullName: user.fullName,
      email: user.email,
      mobile: user.mobile,
      gender: user.gender,
      dateOfBirth: user.dateOfBirth,
      role: user.role,
      status: user.status,
      emailVerified: user.emailVerified,
    });
  }

  await db.update(users).set({ lastLoginAt: new Date(), updatedAt: new Date() }).where(eq(users.id, user.id));
  const session = await createSession(user.id);
  await setSessionCookie(session.token, session.expiresAt);
  return respond(req, formData, true, "Logged in successfully.", returnTo);
}

async function handleLogout(req: NextRequest, formData: FormData) {
  await clearSessionCookie();
  return respond(req, formData, true, "Logged out successfully.", "/");
}

async function handleForgotPassword(req: NextRequest, formData: FormData) {
  const email = normalizeEmail(getString(formData, "email"));
  const rows = await db.select({ id: users.id, email: users.email }).from(users).where(eq(users.email, email)).limit(1);
  const user = rows[0];

  if (user) {
    const token = randomToken(36);
    await db.insert(passwordResetTokens).values({ userId: user.id, tokenHash: hashSecret(token), expiresAt: addMinutes(30) });
    const origin = getPublicOrigin(req);
    const resetLink = `${origin}/forgot-password?token=${token}`;
    await sendPasswordResetEmail(user.email, resetLink);
  }

  return respond(req, formData, true, "If the email exists, a password reset link has been sent to it.", "/forgot-password");
}

async function handleResetPassword(req: NextRequest, formData: FormData) {
  const token = getString(formData, "token");
  const password = getString(formData, "password");
  if (!isStrongPassword(password)) return respond(req, formData, false, "Use at least 8 characters with letters and numbers.");

  const rows = await db
    .select()
    .from(passwordResetTokens)
    .where(and(eq(passwordResetTokens.tokenHash, hashSecret(token)), isNull(passwordResetTokens.consumedAt), gt(passwordResetTokens.expiresAt, new Date())))
    .limit(1);
  const reset = rows[0];
  if (!reset) return respond(req, formData, false, "Reset link is invalid or expired.", "/forgot-password");

  await db.update(users).set({ passwordHash: hashPassword(password), updatedAt: new Date() }).where(eq(users.id, reset.userId));
  await db.update(passwordResetTokens).set({ consumedAt: new Date() }).where(eq(passwordResetTokens.id, reset.id));
  return respond(req, formData, true, "Password reset successfully. Please login.", "/login");
}

async function handleUpdateProfile(req: NextRequest, formData: FormData) {
  const { user, response } = await requireActionUser(req, formData);
  if (!user) return response!;

  const fullName = getString(formData, "fullName");
  const dateOfBirth = getOptionalString(formData, "dateOfBirth");
  const mobile = cleanPhone(getString(formData, "mobile"));
  const age = calculateAge(dateOfBirth);
  const photoUrl = getOptionalString(formData, "profilePhotoUrl");
  const safePhotoUrl = photoUrl && photoUrl.length < 750_000 ? photoUrl : null;

  if (fullName.length < 2) return respond(req, formData, false, "Please enter your full name.");
  if (!dateOfBirth || !age || age < 18) return respond(req, formData, false, "You must be at least 18 years old.");

  const currentProfile = await db.select({ approvalStatus: profiles.approvalStatus }).from(profiles).where(eq(profiles.userId, user.id)).limit(1);
  const nextApproval = user.role === "admin" ? currentProfile[0]?.approvalStatus || "approved" : "pending";

  await db.update(users).set({
    fullName,
    gender: getString(formData, "gender") || user.gender,
    dateOfBirth,
    mobile,
    updatedAt: new Date(),
  }).where(eq(users.id, user.id));

  await db.update(profiles).set({
    displayName: fullName,
    profilePhotoUrl: safePhotoUrl,
    headline: getOptionalString(formData, "headline"),
    about: getOptionalString(formData, "about"),
    familyDetails: getOptionalString(formData, "familyDetails"),
    lifestyle: getOptionalString(formData, "lifestyle"),
    religion: getOptionalString(formData, "religion"),
    community: getOptionalString(formData, "community"),
    motherTongue: getOptionalString(formData, "motherTongue"),
    maritalStatus: getOptionalString(formData, "maritalStatus"),
    education: getOptionalString(formData, "education"),
    profession: getOptionalString(formData, "profession"),
    income: getInt(formData, "income"),
    location: getOptionalString(formData, "location"),
    heightCm: getInt(formData, "heightCm"),
    visibility: getString(formData, "visibility") || "public",
    approvalStatus: nextApproval,
    updatedAt: new Date(),
  }).where(eq(profiles.userId, user.id));

  if (safePhotoUrl) {
    await db.insert(photos).values({ userId: user.id, url: safePhotoUrl, isPrimary: true, approvalStatus: nextApproval }).onConflictDoNothing();
  }

  await createNotification({
    userId: user.id,
    type: "profile_review",
    title: nextApproval === "pending" ? "Profile submitted for admin review" : "Profile updated",
    body: nextApproval === "pending" ? "Your updates will become publicly visible after admin review." : "Your profile has been updated.",
    linkUrl: "/profile",
  });

  return respond(req, formData, true, "Profile saved successfully.", "/profile");
}

async function handleDeleteProfile(req: NextRequest, formData: FormData) {
  const { user, response } = await requireActionUser(req, formData);
  if (!user) return response!;
  await db.update(users).set({ status: "deleted", updatedAt: new Date() }).where(eq(users.id, user.id));
  await db.update(profiles).set({ approvalStatus: "deleted", visibility: "private", updatedAt: new Date() }).where(eq(profiles.userId, user.id));
  await clearSessionCookie();
  return respond(req, formData, true, "Your profile has been deleted.", "/");
}

async function handleUpdatePreferences(req: NextRequest, formData: FormData) {
  const { user, response } = await requireActionUser(req, formData);
  if (!user) return response!;

  const values = {
    userId: user.id,
    lookingFor: getOptionalString(formData, "lookingFor"),
    ageMin: getInt(formData, "ageMin"),
    ageMax: getInt(formData, "ageMax"),
    location: getOptionalString(formData, "location"),
    religion: getOptionalString(formData, "religion"),
    community: getOptionalString(formData, "community"),
    motherTongue: getOptionalString(formData, "motherTongue"),
    maritalStatus: getOptionalString(formData, "maritalStatus"),
    education: getOptionalString(formData, "education"),
    profession: getOptionalString(formData, "profession"),
    incomeMin: getInt(formData, "incomeMin"),
    incomeMax: getInt(formData, "incomeMax"),
    heightMinCm: getInt(formData, "heightMinCm"),
    heightMaxCm: getInt(formData, "heightMaxCm"),
    description: getOptionalString(formData, "description"),
    updatedAt: new Date(),
  };

  await db.insert(partnerPreferences).values(values).onConflictDoUpdate({
    target: partnerPreferences.userId,
    set: values,
  });

  return respond(req, formData, true, "Partner preferences saved.", "/partner-preferences");
}

async function handleSendInterest(req: NextRequest, formData: FormData) {
  const { user, response } = await requireActionUser(req, formData);
  if (!user) return response!;
  const receiverId = parseTargetId(formData);
  if (!receiverId || receiverId === user.id) return respond(req, formData, false, "Invalid profile selection.");

  const receiverProfile = await db.select({ approvalStatus: profiles.approvalStatus }).from(profiles).where(eq(profiles.userId, receiverId)).limit(1);
  if (receiverProfile[0]?.approvalStatus !== "approved") return respond(req, formData, false, "This profile is not currently available.");

  const blocked = await db
    .select({ id: blocks.id })
    .from(blocks)
    .where(or(and(eq(blocks.blockerId, user.id), eq(blocks.blockedUserId, receiverId)), and(eq(blocks.blockerId, receiverId), eq(blocks.blockedUserId, user.id))))
    .limit(1);
  if (blocked.length > 0) return respond(req, formData, false, "You cannot send interest to this profile.");

  const existing = await db
    .select({ id: interests.id, status: interests.status })
    .from(interests)
    .where(and(eq(interests.senderId, user.id), eq(interests.receiverId, receiverId)))
    .limit(1);
  if (existing[0]) return respond(req, formData, true, `Interest already ${existing[0].status}.`, "/interests");

  await db.insert(interests).values({ senderId: user.id, receiverId, status: "pending", message: getOptionalString(formData, "message") });
  await createNotification({ userId: receiverId, actorId: user.id, type: "new_interest", title: "New matrimonial interest", body: `${user.fullName} sent you a matrimonial interest.`, linkUrl: "/interests" });
  return respond(req, formData, true, "Interest sent successfully.", "/interests");
}

async function handleCancelInterest(req: NextRequest, formData: FormData) {
  const { user, response } = await requireActionUser(req, formData);
  if (!user) return response!;
  const interestId = getInt(formData, "interestId");
  if (!interestId) return respond(req, formData, false, "Invalid interest.");

  const rows = await db.select().from(interests).where(eq(interests.id, interestId)).limit(1);
  const interest = rows[0];
  if (!interest || interest.senderId !== user.id) return respond(req, formData, false, "Interest not found.");
  if (interest.status !== "pending") return respond(req, formData, false, "Only pending interests can be cancelled.");

  await db.delete(interests).where(eq(interests.id, interestId));
  return respond(req, formData, true, "Interest cancelled.", "/interests");
}

async function handleInterestStatus(req: NextRequest, formData: FormData) {
  const { user, response } = await requireActionUser(req, formData);
  if (!user) return response!;
  const interestId = getInt(formData, "interestId");
  const status = getString(formData, "status");
  if (!interestId || !["accepted", "rejected"].includes(status)) return respond(req, formData, false, "Invalid interest action.");

  const rows = await db.select().from(interests).where(eq(interests.id, interestId)).limit(1);
  const interest = rows[0];
  if (!interest || interest.receiverId !== user.id) return respond(req, formData, false, "Interest not found.");

  await db.update(interests).set({ status, updatedAt: new Date() }).where(eq(interests.id, interestId));
  let redirectTo = "/interests";

  if (status === "accepted") {
    const conversationId = await createMatchForAcceptedInterest(interest.id, interest.senderId, interest.receiverId, 92);
    redirectTo = `/messages/${conversationId}`;
    await createNotification({ userId: interest.senderId, actorId: user.id, type: "interest_accepted", title: "Interest accepted", body: `${user.fullName} accepted your interest. You can now message privately.`, linkUrl: redirectTo });
  } else {
    await createNotification({ userId: interest.senderId, actorId: user.id, type: "interest_rejected", title: "Interest response", body: `${user.fullName} responded to your interest.`, linkUrl: "/interests" });
  }

  return respond(req, formData, true, `Interest ${status}.`, redirectTo);
}

async function handleStartConversation(req: NextRequest, formData: FormData) {
  const { user, response } = await requireActionUser(req, formData);
  if (!user) return response!;
  const targetUserId = parseTargetId(formData);
  if (!targetUserId || targetUserId === user.id) return respond(req, formData, false, "Invalid conversation target.");
  if (!(await canUsersMessage(user.id, targetUserId))) {
    return respond(req, formData, false, "Private messaging opens after a matrimonial interest is accepted.", `/profile/${targetUserId}`);
  }
  const conversationId = await findOrCreateConversation(user.id, targetUserId);
  return respond(req, formData, true, "Conversation opened.", `/messages/${conversationId}`);
}

async function handleSendMessage(req: NextRequest, formData: FormData) {
  const { user, response } = await requireActionUser(req, formData);
  if (!user) return response!;
  const conversationId = getInt(formData, "conversationId");
  const content = getString(formData, "content");
  if (!conversationId || content.length < 1) return respond(req, formData, false, "Message cannot be empty.");

  const participant = await db
    .select({ id: conversationParticipants.id })
    .from(conversationParticipants)
    .where(and(eq(conversationParticipants.conversationId, conversationId), eq(conversationParticipants.userId, user.id)))
    .limit(1);
  if (!participant[0]) return respond(req, formData, false, "Conversation not found.", "/messages");

  const receiverId = await getOtherParticipant(conversationId, user.id);
  if (!receiverId) return respond(req, formData, false, "Recipient not found.", "/messages");

  const blocked = await db
    .select({ id: blocks.id })
    .from(blocks)
    .where(or(and(eq(blocks.blockerId, user.id), eq(blocks.blockedUserId, receiverId)), and(eq(blocks.blockerId, receiverId), eq(blocks.blockedUserId, user.id))))
    .limit(1);
  if (blocked.length > 0) return respond(req, formData, false, "Messaging is blocked for this user.", "/messages");

  await db.insert(messages).values({ conversationId, senderId: user.id, receiverId, content });
  await db.update(conversations).set({ updatedAt: new Date() }).where(eq(conversations.id, conversationId));
  await createNotification({ userId: receiverId, actorId: user.id, type: "new_message", title: "New message", body: `${user.fullName}: ${content.slice(0, 80)}`, linkUrl: `/messages/${conversationId}` });
  return respond(req, formData, true, "Message sent.", `/messages/${conversationId}`);
}

async function handleDeleteConversation(req: NextRequest, formData: FormData) {
  const { user, response } = await requireActionUser(req, formData);
  if (!user) return response!;
  const conversationId = getInt(formData, "conversationId");
  if (!conversationId) return respond(req, formData, false, "Conversation not found.");
  await db.update(conversationParticipants).set({ deletedAt: new Date() }).where(and(eq(conversationParticipants.conversationId, conversationId), eq(conversationParticipants.userId, user.id)));
  return respond(req, formData, true, "Conversation removed from your inbox.", "/messages");
}

async function handleShortlist(req: NextRequest, formData: FormData) {
  const { user, response } = await requireActionUser(req, formData);
  if (!user) return response!;
  const targetUserId = parseTargetId(formData);
  if (!targetUserId || targetUserId === user.id) return respond(req, formData, false, "Invalid profile.");
  await db.insert(shortlists).values({ userId: user.id, shortlistedUserId: targetUserId }).onConflictDoNothing();
  await createNotification({ userId: targetUserId, actorId: user.id, type: "shortlist", title: "Profile shortlisted", body: `${user.fullName} shortlisted your profile.`, linkUrl: `/profile/${user.id}` });
  return respond(req, formData, true, "Profile added to shortlist.", "/shortlist");
}

async function handleProfileLike(req: NextRequest, formData: FormData) {
  const { user, response } = await requireActionUser(req, formData);
  if (!user) return response!;
  const targetUserId = parseTargetId(formData);
  if (!targetUserId || targetUserId === user.id) return respond(req, formData, false, "Invalid profile.");
  await db.insert(profileLikes).values({ userId: user.id, likedUserId: targetUserId }).onConflictDoNothing();
  await createNotification({ userId: targetUserId, actorId: user.id, type: "profile_like", title: "New profile like", body: `${user.fullName} liked your profile.`, linkUrl: `/profile/${user.id}` });
  return respond(req, formData, true, "Profile liked.", `/profile/${targetUserId}`);
}

async function handleReportProfile(req: NextRequest, formData: FormData) {
  const { user, response } = await requireActionUser(req, formData);
  if (!user) return response!;
  const targetUserId = parseTargetId(formData, "reportedUserId");
  if (!targetUserId || targetUserId === user.id) return respond(req, formData, false, "Invalid report target.");
  await db.insert(reports).values({ reporterId: user.id, reportedUserId: targetUserId, reason: getString(formData, "reason") || "Safety concern", details: getOptionalString(formData, "details"), status: "pending" });
  return respond(req, formData, true, "Report submitted. Our admin will review it.", "/safety-guidelines");
}

async function handleBlockUser(req: NextRequest, formData: FormData) {
  const { user, response } = await requireActionUser(req, formData);
  if (!user) return response!;
  const targetUserId = parseTargetId(formData, "blockedUserId");
  if (!targetUserId || targetUserId === user.id) return respond(req, formData, false, "Invalid user.");
  await db.insert(blocks).values({ blockerId: user.id, blockedUserId: targetUserId, reason: getOptionalString(formData, "reason") }).onConflictDoNothing();
  return respond(req, formData, true, "User blocked. They cannot interact with you.", "/settings");
}

async function handleUnblockUser(req: NextRequest, formData: FormData) {
  const { user, response } = await requireActionUser(req, formData);
  if (!user) return response!;
  const targetUserId = parseTargetId(formData, "blockedUserId");
  if (!targetUserId) return respond(req, formData, false, "Invalid user.");
  await db.delete(blocks).where(and(eq(blocks.blockerId, user.id), eq(blocks.blockedUserId, targetUserId)));
  return respond(req, formData, true, "User unblocked.", "/settings");
}

async function handleUpdatePrivacy(req: NextRequest, formData: FormData) {
  const { user, response } = await requireActionUser(req, formData);
  if (!user) return response!;
  const values = {
    userId: user.id,
    hidePhone: getBool(formData, "hidePhone"),
    hideEmail: getBool(formData, "hideEmail"),
    profileVisibility: getString(formData, "profileVisibility") || "public",
    allowMessagesFrom: getString(formData, "allowMessagesFrom") || "accepted_matches",
    updatedAt: new Date(),
  };
  await db.insert(privacySettings).values(values).onConflictDoUpdate({ target: privacySettings.userId, set: values });
  await db.update(profiles).set({ visibility: values.profileVisibility, updatedAt: new Date() }).where(eq(profiles.userId, user.id));
  return respond(req, formData, true, "Privacy settings updated.", "/settings");
}

async function handleRequestVerification(req: NextRequest, formData: FormData) {
  const { user, response } = await requireActionUser(req, formData);
  if (!user) return response!;
  await db.insert(verificationRequests).values({ userId: user.id, status: "pending", note: getOptionalString(formData, "note") }).onConflictDoNothing();
  await createNotification({ userId: user.id, type: "verification_requested", title: "Verification request submitted", body: "Admin will review your profile verification request.", linkUrl: "/profile" });
  return respond(req, formData, true, "Verification request submitted.", "/profile");
}

async function handleCreatePost(req: NextRequest, formData: FormData) {
  const { user, response } = await requireActionUser(req, formData);
  if (!user) return response!;
  const content = getString(formData, "content");
  const photoUrl = getOptionalString(formData, "photoUrl");
  const safePhotoUrl = photoUrl && photoUrl.length < 750_000 ? photoUrl : null;
  if (content.length < 2) return respond(req, formData, false, "Post text is required.");
  await db.insert(posts).values({ authorId: user.id, content, photoUrl: safePhotoUrl, status: "active" });
  return respond(req, formData, true, "Post shared.", "/feed");
}

async function handleDeletePost(req: NextRequest, formData: FormData) {
  const { user, response } = await requireActionUser(req, formData);
  if (!user) return response!;
  const postId = getInt(formData, "postId");
  if (!postId) return respond(req, formData, false, "Post not found.");
  const post = await db.select({ authorId: posts.authorId }).from(posts).where(eq(posts.id, postId)).limit(1);
  if (!post[0]) return respond(req, formData, false, "Post not found.");
  if (post[0].authorId !== user.id && !(await isAdminUser(user))) return respond(req, formData, false, "You can delete only your own post.");
  await db.delete(posts).where(eq(posts.id, postId));
  return respond(req, formData, true, "Post deleted.", "/feed");
}

async function handleLikePost(req: NextRequest, formData: FormData) {
  const { user, response } = await requireActionUser(req, formData);
  if (!user) return response!;
  const postId = getInt(formData, "postId");
  if (!postId) return respond(req, formData, false, "Post not found.");
  const existing = await db.select({ id: postLikes.id }).from(postLikes).where(and(eq(postLikes.postId, postId), eq(postLikes.userId, user.id))).limit(1);
  if (existing[0]) {
    await db.delete(postLikes).where(eq(postLikes.id, existing[0].id));
  } else {
    await db.insert(postLikes).values({ postId, userId: user.id }).onConflictDoNothing();
    const post = await db.select({ authorId: posts.authorId }).from(posts).where(eq(posts.id, postId)).limit(1);
    if (post[0]) await createNotification({ userId: post[0].authorId, actorId: user.id, type: "post_like", title: "New post like", body: `${user.fullName} liked your post.`, linkUrl: "/feed" });
  }
  return respond(req, formData, true, "Post reaction updated.", "/feed");
}

async function handleCommentPost(req: NextRequest, formData: FormData) {
  const { user, response } = await requireActionUser(req, formData);
  if (!user) return response!;
  const postId = getInt(formData, "postId");
  const content = getString(formData, "content");
  if (!postId || content.length < 1) return respond(req, formData, false, "Comment cannot be empty.");
  await db.insert(comments).values({ postId, authorId: user.id, content });
  const post = await db.select({ authorId: posts.authorId }).from(posts).where(eq(posts.id, postId)).limit(1);
  if (post[0]) await createNotification({ userId: post[0].authorId, actorId: user.id, type: "post_comment", title: "New comment", body: `${user.fullName} commented on your post.`, linkUrl: "/feed" });
  return respond(req, formData, true, "Comment added.", "/feed");
}

async function handleDeleteComment(req: NextRequest, formData: FormData) {
  const { user, response } = await requireActionUser(req, formData);
  if (!user) return response!;
  const commentId = getInt(formData, "commentId");
  if (!commentId) return respond(req, formData, false, "Comment not found.");
  const comment = await db.select({ authorId: comments.authorId }).from(comments).where(eq(comments.id, commentId)).limit(1);
  if (!comment[0]) return respond(req, formData, false, "Comment not found.");
  if (comment[0].authorId !== user.id && !(await isAdminUser(user))) return respond(req, formData, false, "You can delete only your own comment.");
  await db.delete(comments).where(eq(comments.id, commentId));
  return respond(req, formData, true, "Comment deleted.", "/feed");
}

async function handleReportPost(req: NextRequest, formData: FormData) {
  const { user, response } = await requireActionUser(req, formData);
  if (!user) return response!;
  const postId = getInt(formData, "postId");
  if (!postId) return respond(req, formData, false, "Post not found.");
  await db.insert(reports).values({ reporterId: user.id, postId, reason: getString(formData, "reason") || "Reported post", details: getOptionalString(formData, "details"), status: "pending" });
  return respond(req, formData, true, "Post reported for admin review.", "/feed");
}

async function handleNotificationAction(req: NextRequest, formData: FormData) {
  const { user, response } = await requireActionUser(req, formData);
  if (!user) return response!;
  const action = getString(formData, "notificationAction");
  if (action === "all") {
    await db.update(notifications).set({ readAt: new Date() }).where(and(eq(notifications.userId, user.id), isNull(notifications.readAt)));
  } else {
    const id = getInt(formData, "notificationId");
    if (id) await db.update(notifications).set({ readAt: new Date() }).where(and(eq(notifications.id, id), eq(notifications.userId, user.id)));
  }
  return respond(req, formData, true, "Notifications updated.", "/notifications");
}

async function handleAdminUserAction(req: NextRequest, formData: FormData) {
  const { admin, response } = await requireActionAdmin(req, formData);
  if (!admin) return response!;
  const targetUserId = parseTargetId(formData);
  const task = getString(formData, "adminTask");
  if (!targetUserId) return respond(req, formData, false, "Target user not found.", "/admin");

  if (task === "approveProfile") {
    await db.update(profiles).set({ approvalStatus: "approved", updatedAt: new Date() }).where(eq(profiles.userId, targetUserId));
    await db.update(photos).set({ approvalStatus: "approved" }).where(eq(photos.userId, targetUserId));
    await db.update(users).set({ status: "active", updatedAt: new Date() }).where(eq(users.id, targetUserId));
    await createNotification({ userId: targetUserId, actorId: admin.id, type: "admin_approval", title: "Profile approved", body: "Your profile is now approved and visible to matching members.", linkUrl: "/profile" });
  }
  if (task === "rejectProfile") {
    await db.update(profiles).set({ approvalStatus: "rejected", updatedAt: new Date() }).where(eq(profiles.userId, targetUserId));
    await createNotification({ userId: targetUserId, actorId: admin.id, type: "admin_review", title: "Profile review update", body: "Admin reviewed your profile. Please update missing details and resubmit.", linkUrl: "/profile/edit" });
  }
  if (task === "verifyProfile") {
    await db.update(profiles).set({ verificationStatus: "verified", updatedAt: new Date() }).where(eq(profiles.userId, targetUserId));
    await db.update(verificationRequests).set({ status: "approved", reviewedByUserId: admin.id, reviewedAt: new Date(), updatedAt: new Date() }).where(and(eq(verificationRequests.userId, targetUserId), eq(verificationRequests.status, "pending")));
    await createNotification({ userId: targetUserId, actorId: admin.id, type: "verification_approved", title: "Profile verified", body: "Your Panika Jeevan Sathi profile is verified by platform admin.", linkUrl: "/profile" });
  }
  if (task === "unverifyProfile") {
    await db.update(profiles).set({ verificationStatus: "unverified", updatedAt: new Date() }).where(eq(profiles.userId, targetUserId));
    await createNotification({ userId: targetUserId, actorId: admin.id, type: "admin_action", title: "Verification badge updated", body: "Your verification badge has been reset.", linkUrl: "/profile" });
  }
  if (task === "suspendUser") {
    await db.update(users).set({ status: "suspended", updatedAt: new Date() }).where(eq(users.id, targetUserId));
    await createNotification({ userId: targetUserId, actorId: admin.id, type: "admin_action", title: "Account suspended", body: "Your account has been suspended by administration. Contact support for help.", linkUrl: "/settings" });
  }
  if (task === "activateUser") {
    await db.update(users).set({ status: "active", updatedAt: new Date() }).where(eq(users.id, targetUserId));
    await createNotification({ userId: targetUserId, actorId: admin.id, type: "admin_action", title: "Account activated", body: "Your account is active again.", linkUrl: "/profile" });
  }
  if (task === "deleteUser") {
    await db.update(users).set({ status: "deleted", updatedAt: new Date() }).where(eq(users.id, targetUserId));
    await db.update(profiles).set({ approvalStatus: "deleted", visibility: "private", updatedAt: new Date() }).where(eq(profiles.userId, targetUserId));
  }

  return respond(req, formData, true, "Admin action completed.", "/admin");
}

async function handleAdminReportAction(req: NextRequest, formData: FormData) {
  const { admin, response } = await requireActionAdmin(req, formData);
  if (!admin) return response!;
  const reportId = getInt(formData, "reportId");
  const status = getString(formData, "status") || "reviewed";
  const deleteReportedPost = getBool(formData, "deleteReportedPost");

  if (!reportId) return respond(req, formData, false, "Report not found.", "/admin");

  const reportRow = await db.select().from(reports).where(eq(reports.id, reportId)).limit(1);
  if (reportRow[0]?.postId && deleteReportedPost) {
    await db.delete(posts).where(eq(posts.id, reportRow[0].postId));
  }

  await db.update(reports).set({ status, adminNote: getOptionalString(formData, "adminNote"), updatedAt: new Date() }).where(eq(reports.id, reportId));
  return respond(req, formData, true, "Report updated.", "/admin");
}

async function handleAdminAnnouncement(req: NextRequest, formData: FormData) {
  const { admin, response } = await requireActionAdmin(req, formData);
  if (!admin) return response!;
  const title = getString(formData, "title");
  const body = getString(formData, "body");
  if (title.length < 2 || body.length < 2) return respond(req, formData, false, "Announcement title and body are required.", "/admin");

  const adminRow = await db.select({ id: adminUsers.id }).from(adminUsers).where(eq(adminUsers.userId, admin.id)).limit(1);
  await db.insert(announcements).values({ adminUserId: adminRow[0]?.id, title, body, audience: "all" });
  const activeUsers = await db.select({ id: users.id }).from(users).where(eq(users.status, "active")).limit(1000);
  await Promise.all(activeUsers.map((target) => createNotification({ userId: target.id, actorId: admin.id, type: "admin_announcement", title, body, linkUrl: "/notifications" })));
  return respond(req, formData, true, "Announcement sent.", "/admin");
}

export async function POST(req: NextRequest) {
  const formData = await req.formData();
  const action = getString(formData, "action");

  try {
    switch (action) {
      case "register":
        return handleRegister(req, formData);
      case "resendOtp":
        return handleResendOtp(req, formData);
      case "verifyOtp":
        return handleVerifyOtp(req, formData);
      case "login":
        return handleLogin(req, formData);
      case "logout":
        return handleLogout(req, formData);
      case "forgotPassword":
        return handleForgotPassword(req, formData);
      case "resetPassword":
        return handleResetPassword(req, formData);
      case "updateProfile":
        return handleUpdateProfile(req, formData);
      case "deleteProfile":
        return handleDeleteProfile(req, formData);
      case "updatePreferences":
        return handleUpdatePreferences(req, formData);
      case "sendInterest":
        return handleSendInterest(req, formData);
      case "cancelInterest":
        return handleCancelInterest(req, formData);
      case "interestStatus":
        return handleInterestStatus(req, formData);
      case "startConversation":
        return handleStartConversation(req, formData);
      case "sendMessage":
        return handleSendMessage(req, formData);
      case "deleteConversation":
        return handleDeleteConversation(req, formData);
      case "shortlist":
        return handleShortlist(req, formData);
      case "profileLike":
        return handleProfileLike(req, formData);
      case "reportProfile":
        return handleReportProfile(req, formData);
      case "blockUser":
        return handleBlockUser(req, formData);
      case "unblockUser":
        return handleUnblockUser(req, formData);
      case "updatePrivacy":
        return handleUpdatePrivacy(req, formData);
      case "requestVerification":
        return handleRequestVerification(req, formData);
      case "createPost":
        return handleCreatePost(req, formData);
      case "deletePost":
        return handleDeletePost(req, formData);
      case "likePost":
        return handleLikePost(req, formData);
      case "commentPost":
        return handleCommentPost(req, formData);
      case "deleteComment":
        return handleDeleteComment(req, formData);
      case "reportPost":
        return handleReportPost(req, formData);
      case "notificationAction":
        return handleNotificationAction(req, formData);
      case "adminUserAction":
        return handleAdminUserAction(req, formData);
      case "adminReportAction":
        return handleAdminReportAction(req, formData);
      case "adminAnnouncement":
        return handleAdminAnnouncement(req, formData);
      default:
        return respond(req, formData, false, "Unknown action.");
    }
  } catch (error) {
    console.error("Action failed", error);
    return respond(req, formData, false, "Something went wrong. Please try again.");
  }
}
