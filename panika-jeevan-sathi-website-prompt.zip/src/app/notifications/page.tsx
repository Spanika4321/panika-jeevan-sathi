import Link from "next/link";
import { requireUser } from "@/lib/auth";
import { getNotifications, getUnreadNotificationCount } from "@/lib/data";
import { formatTime, searchParam } from "@/lib/utils";
import { EmptyState, NoticeBar, SectionHeading } from "@/components/ui";

export const dynamic = "force-dynamic";

type NotificationsPageProps = {
  searchParams: Promise<Record<string, string | string[] | undefined>>;
};

export default async function NotificationsPage({ searchParams }: NotificationsPageProps) {
  const params = await searchParams;
  const user = await requireUser();
  const [items, unreadCount] = await Promise.all([getNotifications(user.id), getUnreadNotificationCount(user.id)]);

  return (
    <div className="mx-auto max-w-4xl px-4 py-8 sm:px-6 lg:px-8">
      <NoticeBar notice={searchParam(params, "notice")} error={searchParam(params, "error")} />
      <div className="flex flex-col justify-between gap-4 sm:flex-row sm:items-end">
        <SectionHeading eyebrow="Notifications" title="Platform updates">
          You have <strong>{unreadCount}</strong> unread notifications for interests, messages, likes, shortlists and admin announcements.
        </SectionHeading>
        {unreadCount > 0 && <form action="/api/actions" method="post"><input type="hidden" name="action" value="notificationAction" /><input type="hidden" name="notificationAction" value="all" /><button className="rounded-full bg-[#1E1B4B] px-5 py-3 text-sm font-black text-white">Mark all read</button></form>}
      </div>
      <div className="rounded-[2rem] bg-white p-4 shadow-xl shadow-slate-200/70">
        {items.length === 0 ? <EmptyState title="No notifications" body="Important account, match and admin updates will appear here." /> : items.map((item) => (
          <article key={item.id} className={`border-b border-slate-100 p-4 last:border-b-0 ${item.readAt ? "opacity-70" : ""}`}>
            <div className="flex flex-col gap-3 sm:flex-row sm:items-start sm:justify-between">
              <div>
                <div className="flex flex-wrap items-center gap-2"><h2 className="font-black text-[#1E1B4B]">{item.title}</h2>{!item.readAt && <span className="rounded-full bg-[#F43F5E] px-2 py-0.5 text-[10px] font-black text-white">NEW</span>}</div>
                {item.body && <p className="mt-1 text-sm leading-6 text-slate-600">{item.body}</p>}
                <p className="mt-1 text-xs font-semibold text-slate-400">{formatTime(item.createdAt)}</p>
              </div>
              <div className="flex gap-2">
                {item.linkUrl && <Link href={item.linkUrl} className="rounded-full bg-slate-100 px-4 py-2 text-xs font-black text-slate-700">Open</Link>}
                {!item.readAt && <form action="/api/actions" method="post"><input type="hidden" name="action" value="notificationAction" /><input type="hidden" name="notificationId" value={item.id} /><button className="rounded-full bg-rose-50 px-4 py-2 text-xs font-black text-[#F43F5E]">Mark read</button></form>}
              </div>
            </div>
          </article>
        ))}
      </div>
    </div>
  );
}
