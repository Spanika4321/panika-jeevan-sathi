import Link from "next/link";
import { requireUser } from "@/lib/auth";
import { getShortlistData } from "@/lib/data";
import { formatTime, searchParam } from "@/lib/utils";
import { Avatar, EmptyState, NoticeBar, SectionHeading } from "@/components/ui";

export const dynamic = "force-dynamic";

type ShortlistPageProps = {
  searchParams: Promise<Record<string, string | string[] | undefined>>;
};

export default async function ShortlistPage({ searchParams }: ShortlistPageProps) {
  const params = await searchParams;
  const user = await requireUser();
  const items = await getShortlistData(user.id);

  return (
    <div className="mx-auto max-w-5xl px-4 py-8 sm:px-6 lg:px-8">
      <NoticeBar notice={searchParam(params, "notice")} error={searchParam(params, "error")} />
      <SectionHeading eyebrow="Shortlist" title="Profiles saved for later">
        Keep a private list of profiles you want to review with family or revisit later.
      </SectionHeading>
      <div className="grid gap-4 md:grid-cols-2">
        {items.length === 0 ? <div className="md:col-span-2"><EmptyState title="Your shortlist is empty" body="Use the Shortlist button on profile cards to save profiles privately." actionHref="/find-matches" actionLabel="Find Matches" /></div> : items.map(({ shortlist, profile }) => profile && (
          <article key={shortlist.id} className="rounded-3xl bg-white p-5 shadow-xl shadow-slate-200/70">
            <div className="flex items-center gap-4">
              <Avatar profile={profile} size="lg" />
              <div className="min-w-0 flex-1">
                <Link href={`/profile/${profile.userId}`} className="text-lg font-black text-[#1E1B4B] hover:text-[#F43F5E]">{profile.fullName}</Link>
                <p className="text-sm text-slate-600">{[profile.age ? `${profile.age} yrs` : null, profile.location, profile.profession].filter(Boolean).join(" • ")}</p>
                <p className="mt-1 text-xs font-semibold text-slate-400">Saved {formatTime(shortlist.createdAt)}</p>
              </div>
            </div>
            <div className="mt-4 grid grid-cols-2 gap-2">
              <Link href={`/profile/${profile.userId}`} className="rounded-full bg-[#1E1B4B] px-4 py-2 text-center text-sm font-black text-white">View</Link>
              <form action="/api/actions" method="post"><input type="hidden" name="action" value="sendInterest" /><input type="hidden" name="targetUserId" value={profile.userId} /><button className="w-full rounded-full bg-[#F43F5E] px-4 py-2 text-sm font-black text-white">Interest</button></form>
            </div>
          </article>
        ))}
      </div>
    </div>
  );
}
