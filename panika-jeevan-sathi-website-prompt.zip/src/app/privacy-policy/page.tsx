import { CONTACT_EMAIL } from "@/lib/constants";
import { SectionHeading } from "@/components/ui";

export default function PrivacyPolicyPage() {
  return (
    <div className="mx-auto max-w-4xl px-4 py-10 sm:px-6 lg:px-8">
      <SectionHeading eyebrow="Privacy Policy" title="Your privacy matters">
        We collect only information needed to run a matrimonial service and provide privacy controls for sensitive contact details.
      </SectionHeading>
      <div className="space-y-5 rounded-[2rem] bg-white p-6 text-sm leading-7 text-slate-700 shadow-xl shadow-slate-200/70">
        <h2 className="text-xl font-black text-[#1E1B4B]">English</h2>
        <p>Panika Jeevan Sathi stores account details, matrimonial profile information, partner preferences, messages, interests, reports and feed activity to provide matching, communication and safety features.</p>
        <p>Passwords are stored using one-way hashing. Private contact information such as phone number and email is hidden from public profile pages unless your privacy settings explicitly allow sharing with accepted matches.</p>
        <p>You can edit, hide or delete your profile. Admins may review profiles, reports and posts for safety and platform quality.</p>
        <h2 className="pt-4 text-xl font-black text-[#1E1B4B]">हिन्दी</h2>
        <p>Panika Jeevan Sathi आपकी matrimonial सेवा चलाने के लिए account details, profile information, partner preferences, messages, interests, reports और feed activity सुरक्षित रूप से रखता है।</p>
        <p>Passwords one-way hashing से सुरक्षित रहते हैं। Phone number और email public profile पर नहीं दिखाए जाते, जब तक आप privacy settings में स्पष्ट रूप से अनुमति न दें।</p>
        <p>आप अपना profile edit, hide या delete कर सकते हैं। Safety और quality के लिए admin profiles, reports और posts review कर सकता है।</p>
        <p>Questions: <a className="font-bold text-[#F43F5E]" href={`mailto:${CONTACT_EMAIL}`}>{CONTACT_EMAIL}</a></p>
      </div>
    </div>
  );
}
