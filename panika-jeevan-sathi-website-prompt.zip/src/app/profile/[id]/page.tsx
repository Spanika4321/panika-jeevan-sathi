import { notFound } from "next/navigation";
import { getCurrentUser } from "@/lib/auth";
import { getProfileDetails } from "@/lib/data";
import { searchParam } from "@/lib/utils";
import { NoticeBar, SectionHeading } from "@/components/ui";
import { ProfileDetail } from "@/components/profile-detail";

export const dynamic = "force-dynamic";

type PublicProfilePageProps = {
  params: Promise<{ id: string }>;
  searchParams: Promise<Record<string, string | string[] | undefined>>;
};

export default async function PublicProfilePage({ params, searchParams }: PublicProfilePageProps) {
  const [{ id }, query] = await Promise.all([params, searchParams]);
  const profileUserId = Number.parseInt(id, 10);
  if (!Number.isFinite(profileUserId)) notFound();

  const viewer = await getCurrentUser();
  const profile = await getProfileDetails(profileUserId, viewer);
  if (!profile) notFound();

  return (
    <div className="mx-auto max-w-7xl px-4 py-8 sm:px-6 lg:px-8">
      <NoticeBar notice={searchParam(query, "notice")} error={searchParam(query, "error")} />
      <SectionHeading eyebrow="Profile" title={`${profile.fullName}'s matrimonial profile`}>
        Review details carefully, use interest before messaging, and follow safety guidelines.
      </SectionHeading>
      <ProfileDetail profile={profile} viewerId={viewer?.id} />
    </div>
  );
}
