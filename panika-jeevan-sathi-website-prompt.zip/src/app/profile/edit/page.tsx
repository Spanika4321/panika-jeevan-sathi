import { redirect } from "next/navigation";
import { ProfileEditor } from "@/components/client-forms";
import { NoticeBar, SectionHeading } from "@/components/ui";
import { requireUser } from "@/lib/auth";
import { getOwnProfile } from "@/lib/data";
import { searchParam } from "@/lib/utils";

export const dynamic = "force-dynamic";

type EditProfilePageProps = {
  searchParams: Promise<Record<string, string | string[] | undefined>>;
};

export default async function EditProfilePage({ searchParams }: EditProfilePageProps) {
  const params = await searchParams;
  const user = await requireUser();
  const profile = await getOwnProfile(user.id);
  if (!profile) redirect("/register");

  return (
    <div className="mx-auto max-w-5xl px-4 py-8 sm:px-6 lg:px-8">
      <NoticeBar notice={searchParam(params, "notice")} error={searchParam(params, "error")} />
      <SectionHeading eyebrow="Edit Profile" title="Update your matrimonial details">
        Changes may be reviewed by admin before appearing in public match results.
      </SectionHeading>
      <ProfileEditor
        user={{ fullName: user.fullName, gender: user.gender, dateOfBirth: user.dateOfBirth, mobile: user.mobile }}
        profile={{
          profilePhotoUrl: profile.profilePhotoUrl,
          headline: profile.headline,
          about: profile.about,
          familyDetails: profile.familyDetails,
          lifestyle: profile.lifestyle,
          religion: profile.religion,
          community: profile.community,
          motherTongue: profile.motherTongue,
          maritalStatus: profile.maritalStatus,
          education: profile.education,
          profession: profile.profession,
          income: profile.income,
          location: profile.location,
          heightCm: profile.heightCm,
          visibility: profile.visibility,
        }}
      />
    </div>
  );
}
