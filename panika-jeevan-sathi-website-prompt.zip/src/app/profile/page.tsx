import { redirect } from "next/navigation";
import { requireUser } from "@/lib/auth";
import { getProfileDetails } from "@/lib/data";
import { searchParam } from "@/lib/utils";
import { NoticeBar, SectionHeading } from "@/components/ui";
import { ProfileDetail } from "@/components/profile-detail";

export const dynamic = "force-dynamic";

type ProfilePageProps = {
  searchParams: Promise<Record<string, string | string[] | undefined>>;
};

export default async function ProfilePage({ searchParams }: ProfilePageProps) {
  const params = await searchParams;
  const user = await requireUser();
  const profile = await getProfileDetails(user.id, user);
  if (!profile) redirect("/profile/edit");

  return (
    <div className="mx-auto max-w-7xl px-4 py-8 sm:px-6 lg:px-8">
      <NoticeBar notice={searchParam(params, "notice")} error={searchParam(params, "error")} />
      <SectionHeading eyebrow="My Profile" title="Your matrimonial profile">
        Edit your information anytime. Public visibility requires admin approval after registration or major edits.
      </SectionHeading>
      <ProfileDetail profile={profile} viewerId={user.id} />
    </div>
  );
}
