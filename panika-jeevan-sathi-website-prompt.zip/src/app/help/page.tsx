import Link from "next/link";
import { SectionHeading } from "@/components/ui";

export default function HelpPage() {
  const items = [
    ["How registration works", "Create profile → verify email OTP → admin reviews profile → approved profiles become visible."],
    ["How messaging works", "Send interest first. Private messaging opens only when the interest is accepted."],
    ["How privacy works", "Phone and email are hidden by default. You can change visibility in Settings."],
    ["How reporting works", "Use Report Profile or Report Post. Admin reviews reports from the dashboard."],
  ];
  return (
    <div className="mx-auto max-w-5xl px-4 py-10 sm:px-6 lg:px-8">
      <SectionHeading eyebrow="Help" title="Easy guide for first-time matrimonial users">
        Simple answers in a clear, mobile-friendly format.
      </SectionHeading>
      <div className="grid gap-4 md:grid-cols-2">{items.map(([title, body]) => <article key={title} className="rounded-3xl bg-white p-6 shadow-xl shadow-slate-200/70"><h2 className="text-lg font-black text-[#1E1B4B]">{title}</h2><p className="mt-2 text-sm leading-6 text-slate-600">{body}</p></article>)}</div>
      <div className="mt-6 flex flex-wrap gap-3"><Link href="/register" className="rounded-full bg-[#F43F5E] px-5 py-3 text-sm font-black text-white">Register</Link><Link href="/safety-guidelines" className="rounded-full bg-white px-5 py-3 text-sm font-black text-[#1E1B4B] shadow">Safety Guidelines</Link></div>
    </div>
  );
}
