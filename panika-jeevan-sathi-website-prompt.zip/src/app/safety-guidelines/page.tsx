import { CONTACT_EMAIL, CONTACT_WHATSAPP, safetyEnglish, safetyHindi } from "@/lib/constants";
import { SafetyBanner, SectionHeading } from "@/components/ui";

export default function SafetyGuidelinesPage() {
  return (
    <div className="mx-auto max-w-5xl px-4 py-10 sm:px-6 lg:px-8">
      <SectionHeading eyebrow="Safety Guidelines" title="Stay safe while finding a life partner">
        Panika Jeevan Sathi is built with privacy and reporting tools, but every user must make careful decisions.
      </SectionHeading>
      <SafetyBanner />
      <div className="mt-8 grid gap-6 md:grid-cols-2">
        <section className="rounded-[2rem] bg-white p-6 shadow-xl shadow-slate-200/70">
          <h2 className="text-2xl font-black text-[#1E1B4B]">English</h2>
          <ul className="mt-4 list-disc space-y-3 pl-5 text-sm leading-7 text-slate-700">{safetyEnglish.map((item) => <li key={item}>{item}</li>)}<li>Use Report Profile or Report Post for suspicious activity.</li><li>Block anyone who pressures, threatens or harasses you.</li><li>Contact support at {CONTACT_EMAIL} or WhatsApp {CONTACT_WHATSAPP}.</li></ul>
        </section>
        <section className="rounded-[2rem] bg-white p-6 shadow-xl shadow-slate-200/70">
          <h2 className="text-2xl font-black text-[#1E1B4B]">हिन्दी</h2>
          <ul className="mt-4 list-disc space-y-3 pl-5 text-sm leading-7 text-slate-700">{safetyHindi.map((item) => <li key={item}>{item}</li>)}<li>संदिग्ध गतिविधि के लिए Report Profile या Report Post का उपयोग करें।</li><li>दबाव, धमकी या परेशानी देने वाले व्यक्ति को Block करें।</li><li>सहायता के लिए {CONTACT_EMAIL} या WhatsApp {CONTACT_WHATSAPP} पर संपर्क करें।</li></ul>
        </section>
      </div>
    </div>
  );
}
