import { CONTACT_EMAIL, CONTACT_WHATSAPP } from "@/lib/constants";
import { SectionHeading } from "@/components/ui";

export default function ContactPage() {
  return (
    <div className="mx-auto max-w-4xl px-4 py-10 sm:px-6 lg:px-8">
      <SectionHeading eyebrow="Contact Us" title="We are here to help">
        For profile help, safety reports, admin approval questions or technical support, contact Panika Jeevan Sathi.
      </SectionHeading>
      <div className="rounded-[2rem] bg-white p-6 shadow-xl shadow-slate-200/70">
        <div className="grid gap-4 md:grid-cols-2">
          <a href={`mailto:${CONTACT_EMAIL}`} className="rounded-3xl bg-rose-50 p-6"><p className="text-sm font-black uppercase tracking-[0.16em] text-[#F43F5E]">Email</p><p className="mt-2 text-lg font-black text-[#1E1B4B]">{CONTACT_EMAIL}</p></a>
          <a href={`https://wa.me/91${CONTACT_WHATSAPP}`} className="rounded-3xl bg-indigo-50 p-6"><p className="text-sm font-black uppercase tracking-[0.16em] text-[#1E1B4B]">WhatsApp</p><p className="mt-2 text-lg font-black text-[#1E1B4B]">{CONTACT_WHATSAPP}</p></a>
        </div>
        <p className="mt-5 rounded-2xl bg-slate-50 p-4 text-sm leading-6 text-slate-600">Office address: Not provided. Please use email or WhatsApp for official communication.</p>
      </div>
    </div>
  );
}
