import Link from "next/link";
import { getCurrentUser } from "@/lib/auth";
import { getRecommendedMatches } from "@/lib/data";
import { EmptyState, ProfileCard, SectionHeading } from "@/components/ui";

export const dynamic = "force-dynamic";

export default async function RecommendedMatchesPage() {
  const user = await getCurrentUser().catch(() => null);
  const matches = await getRecommendedMatches(user).catch(() => []);

  return (
    <div className="mx-auto max-w-7xl px-4 py-10 sm:px-6 lg:px-8">
      <div className="flex flex-col justify-between gap-4 sm:flex-row sm:items-end">
        <SectionHeading eyebrow="Recommended Matches" title="Preference-based matches">
          Match percentage is calculated from age, location, religion/community, education, profession, marital status and partner preferences. No AI is used.
        </SectionHeading>
        <Link href="/partner-preferences" className="h-fit rounded-full bg-white px-5 py-3 text-sm font-black text-[#1E1B4B] shadow">Edit Preferences</Link>
      </div>
      {matches.length === 0 ? (
        <EmptyState title="No recommended matches yet" body="Complete your profile and partner preferences, then check again after admin-approved members join." actionHref="/profile/edit" actionLabel="Complete Profile" />
      ) : (
        <div className="grid gap-5 md:grid-cols-2 xl:grid-cols-3">
          {matches.map((profile) => <ProfileCard key={profile.userId} profile={profile} viewerId={user?.id} />)}
        </div>
      )}
    </div>
  );
}
