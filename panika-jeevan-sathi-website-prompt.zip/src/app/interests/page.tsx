import Link from "next/link";
import { requireUser } from "@/lib/auth";
import { getInterestsData } from "@/lib/data";
import { formatTime, searchParam } from "@/lib/utils";
import { Avatar, EmptyState, NoticeBar, SectionHeading, StatusPill } from "@/components/ui";

export const dynamic = "force-dynamic";

type InterestsPageProps = {
  searchParams: Promise<Record<string, string | string[] | undefined>>;
};

export default async function InterestsPage({ searchParams }: InterestsPageProps) {
  const params = await searchParams;
  const user = await requireUser();
  const data = await getInterestsData(user.id);

  return (
    <div className="mx-auto max-w-6xl px-4 py-8 sm:px-6 lg:px-8">
      <NoticeBar notice={searchParam(params, "notice")} error={searchParam(params, "error")} />
      <SectionHeading eyebrow="Interests" title="Matrimonial interest requests">
        Accepting an interest creates a match and unlocks private messaging.
      </SectionHeading>

      <div className="grid gap-6 lg:grid-cols-2">
        <section className="rounded-[2rem] bg-white p-5 shadow-xl shadow-slate-200/70">
          <h2 className="text-2xl font-black text-[#1E1B4B]">Interests Received</h2>
          <div className="mt-5 space-y-3">
            {data.received.length === 0 ? (
              <EmptyState title="No received interests" body="When members express interest in your profile, they will appear here for you to accept or decline." />
            ) : (
              data.received.map(({ interest, profile }) => profile && (
                <article key={interest.id} className="rounded-3xl border border-slate-100 p-4">
                  <div className="flex items-center gap-3">
                    <Avatar profile={profile} />
                    <div className="min-w-0 flex-1">
                      <Link href={`/profile/${profile.userId}`} className="font-black text-[#1E1B4B] hover:text-[#F43F5E]">{profile.fullName}</Link>
                      <p className="text-sm text-slate-600">{[profile.age ? `${profile.age} yrs` : null, profile.location, profile.profession].filter(Boolean).join(" • ")}</p>
                      <p className="mt-1 text-xs font-semibold text-slate-400">{formatTime(interest.createdAt)}</p>
                    </div>
                    <StatusPill value={interest.status} />
                  </div>
                  {interest.message && <p className="mt-3 rounded-2xl bg-slate-50 p-3 text-sm text-slate-600">{interest.message}</p>}
                  {interest.status === "pending" && (
                    <div className="mt-4 grid grid-cols-2 gap-2">
                      <form action="/api/actions" method="post">
                        <input type="hidden" name="action" value="interestStatus" />
                        <input type="hidden" name="interestId" value={interest.id} />
                        <input type="hidden" name="status" value="accepted" />
                        <button className="w-full rounded-full bg-[#F43F5E] px-4 py-2 text-sm font-black text-white transition hover:bg-rose-600" type="submit">Accept</button>
                      </form>
                      <form action="/api/actions" method="post">
                        <input type="hidden" name="action" value="interestStatus" />
                        <input type="hidden" name="interestId" value={interest.id} />
                        <input type="hidden" name="status" value="rejected" />
                        <button className="w-full rounded-full bg-slate-100 px-4 py-2 text-sm font-black text-slate-700 transition hover:bg-slate-200" type="submit">Reject</button>
                      </form>
                    </div>
                  )}
                  {interest.status === "accepted" && (
                    <div className="mt-4">
                      <Link href="/messages" className="block rounded-full bg-[#1E1B4B] px-4 py-2 text-center text-sm font-black text-white transition hover:bg-indigo-950">Open Chat</Link>
                    </div>
                  )}
                </article>
              ))
            )}
          </div>
        </section>

        <section className="rounded-[2rem] bg-white p-5 shadow-xl shadow-slate-200/70">
          <h2 className="text-2xl font-black text-[#1E1B4B]">Interests Sent</h2>
          <div className="mt-5 space-y-3">
            {data.sent.length === 0 ? (
              <EmptyState title="No sent interests" body="Browse profiles and send an interest to start your matrimonial journey." actionHref="/find-matches" actionLabel="Find Matches" />
            ) : (
              data.sent.map(({ interest, profile }) => profile && (
                <article key={interest.id} className="rounded-3xl border border-slate-100 p-4">
                  <div className="flex items-center gap-3">
                    <Avatar profile={profile} />
                    <div className="min-w-0 flex-1">
                      <Link href={`/profile/${profile.userId}`} className="font-black text-[#1E1B4B] hover:text-[#F43F5E]">{profile.fullName}</Link>
                      <p className="text-sm text-slate-600">{[profile.age ? `${profile.age} yrs` : null, profile.location, profile.profession].filter(Boolean).join(" • ")}</p>
                      <p className="mt-1 text-xs font-semibold text-slate-400">Sent {formatTime(interest.createdAt)}</p>
                    </div>
                    <StatusPill value={interest.status === "pending" ? "sent" : interest.status} />
                  </div>
                  {interest.status === "pending" && (
                    <form action="/api/actions" method="post" className="mt-3">
                      <input type="hidden" name="action" value="cancelInterest" />
                      <input type="hidden" name="interestId" value={interest.id} />
                      <button className="rounded-full bg-slate-100 px-4 py-1.5 text-xs font-bold text-slate-700 hover:bg-red-50 hover:text-red-700" type="submit">Cancel Interest</button>
                    </form>
                  )}
                  {interest.status === "accepted" && (
                    <Link href="/messages" className="mt-4 block rounded-full bg-[#1E1B4B] px-4 py-2 text-center text-sm font-black text-white transition hover:bg-indigo-950">Open Chat</Link>
                  )}
                </article>
              ))
            )}
          </div>
        </section>
      </div>
    </div>
  );
}
