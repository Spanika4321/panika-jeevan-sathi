import FindMatchesPage from "../find-matches/page";

export const dynamic = "force-dynamic";

export default FindMatchesPage;
