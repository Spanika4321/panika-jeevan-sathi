import Link from "next/link";
import { PrivacySettingsForm } from "@/components/client-forms";
import { NoticeBar, SafetyBanner, SectionHeading, StatusPill } from "@/components/ui";
import { requireUser } from "@/lib/auth";
import { getBlockedUsers, getOwnPrivacy, getOwnProfile } from "@/lib/data";
import { searchParam } from "@/lib/utils";

export const dynamic = "force-dynamic";

type SettingsPageProps = {
  searchParams: Promise<Record<string, string | string[] | undefined>>;
};

export default async function SettingsPage({ searchParams }: SettingsPageProps) {
  const params = await searchParams;
  const user = await requireUser();
  const [privacy, profile, blockedUsers] = await Promise.all([
    getOwnPrivacy(user.id),
    getOwnProfile(user.id),
    getBlockedUsers(user.id),
  ]);

  return (
    <div className="mx-auto grid max-w-6xl gap-8 px-4 py-8 sm:px-6 lg:grid-cols-[1fr_0.9fr] lg:px-8">
      <section className="space-y-6">
        <NoticeBar notice={searchParam(params, "notice")} error={searchParam(params, "error")} />
        <SectionHeading eyebrow="Settings" title="Privacy & Security Controls">
          Your phone number and email are private by default and only visible to accepted connections.
        </SectionHeading>
        <PrivacySettingsForm privacy={privacy ? { hidePhone: privacy.hidePhone, hideEmail: privacy.hideEmail, profileVisibility: privacy.profileVisibility, allowMessagesFrom: privacy.allowMessagesFrom } : null} />

        <div className="rounded-[2rem] bg-white p-6 shadow-xl shadow-slate-200/70">
          <h2 className="text-xl font-black text-[#1E1B4B]">Blocked Members</h2>
          <p className="mt-1 text-xs text-slate-500">Blocked members cannot see your profile, send interests, or message you.</p>
          <div className="mt-4 space-y-3">
            {blockedUsers.length === 0 ? (
              <p className="text-xs text-slate-400">You have not blocked any members.</p>
            ) : (
              blockedUsers.map(({ blockedUserId, profile: blockedProfile }) => (
                <div key={blockedUserId} className="flex items-center justify-between gap-3 rounded-2xl bg-slate-50 p-3">
                  <div>
                    <p className="text-sm font-bold text-slate-800">{blockedProfile?.fullName || `User #${blockedUserId}`}</p>
                    <p className="text-xs text-slate-400">{blockedProfile?.location || "No location"}</p>
                  </div>
                  <form action="/api/actions" method="post">
                    <input type="hidden" name="action" value="unblockUser" />
                    <input type="hidden" name="blockedUserId" value={blockedUserId} />
                    <button className="rounded-full bg-slate-200 px-3 py-1.5 text-xs font-bold text-slate-700 hover:bg-emerald-50 hover:text-emerald-700" type="submit">Unblock</button>
                  </form>
                </div>
              ))
            )}
          </div>
        </div>
      </section>

      <aside className="space-y-5 lg:sticky lg:top-24 lg:h-fit">
        <div className="rounded-[2rem] bg-white p-6 shadow-xl shadow-slate-200/70">
          <h2 className="text-xl font-black text-[#1E1B4B]">Account Overview</h2>
          <div className="mt-4 space-y-3 text-sm text-slate-600">
            <p><strong>Full Name:</strong> {user.fullName}</p>
            <p><strong>Email:</strong> {user.email}</p>
            <p><strong>Mobile:</strong> {user.mobile}</p>
            <p><strong>Account Status:</strong> <StatusPill value={user.status} /></p>
            <p><strong>Profile Review:</strong> <StatusPill value={profile?.approvalStatus} /></p>
            <p><strong>Verification:</strong> <StatusPill value={profile?.verificationStatus} /></p>
          </div>
          <div className="mt-5 grid gap-2">
            <Link href="/profile/edit" className="rounded-full bg-[#1E1B4B] px-5 py-3 text-center text-sm font-black text-white hover:bg-indigo-950">Edit Profile</Link>
            <Link href="/partner-preferences" className="rounded-full bg-slate-100 px-5 py-3 text-center text-sm font-black text-slate-700 hover:bg-slate-200">Partner Preferences</Link>
            <form action="/api/actions" method="post">
              <input type="hidden" name="action" value="logout" />
              <button className="w-full rounded-full bg-red-50 px-5 py-3 text-sm font-black text-red-700 hover:bg-red-100">Logout</button>
            </form>
          </div>
        </div>
        <SafetyBanner />
      </aside>
    </div>
  );
}
