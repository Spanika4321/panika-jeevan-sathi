import Link from "next/link";
import { LoginForm } from "@/components/client-forms";
import { NoticeBar, SectionHeading } from "@/components/ui";
import { getCurrentUser } from "@/lib/auth";
import { safeReturnTo, searchParam } from "@/lib/utils";

export const dynamic = "force-dynamic";

type LoginPageProps = {
  searchParams: Promise<Record<string, string | string[] | undefined>>;
};

export default async function LoginPage({ searchParams }: LoginPageProps) {
  const params = await searchParams;
  const user = await getCurrentUser();
  const returnTo = safeReturnTo(searchParam(params, "next") || searchParam(params, "returnTo"), "/profile");

  return (
    <div className="mx-auto grid max-w-6xl gap-8 px-4 py-10 sm:px-6 lg:grid-cols-2 lg:px-8">
      <section className="rounded-[2rem] bg-white p-7 shadow-xl shadow-slate-200/70">
        <NoticeBar notice={searchParam(params, "notice") || (user ? `You are logged in as ${user.fullName}.` : "")} error={searchParam(params, "error")} />
        <SectionHeading eyebrow="Secure Login" title="Welcome back">
          Login with your registered email or mobile number.
        </SectionHeading>
        <LoginForm returnTo={returnTo} />
        <div className="mt-5 flex flex-wrap items-center justify-between gap-3 text-xs font-bold text-slate-600">
          <Link className="text-[#F43F5E] hover:underline" href="/forgot-password">Forgot Password?</Link>
          <Link className="text-indigo-900 hover:underline" href="/verify-otp">Verify Email OTP</Link>
          <Link className="text-[#1E1B4B] hover:underline" href="/register">Create new profile</Link>
        </div>
      </section>
      <aside className="rounded-[2rem] bg-gradient-to-br from-[#1E1B4B] to-[#F43F5E] p-8 text-white shadow-2xl shadow-rose-500/20">
        <h2 className="text-3xl font-black">Trust + Privacy + Easy Matching</h2>
        <p className="mt-4 text-sm leading-6 text-white/85">Only email-verified members can log in. New profiles are reviewed by administration before becoming publicly searchable.</p>
        <div className="mt-8 grid gap-3 text-sm font-bold">
          <div className="rounded-2xl bg-white/10 p-4">🔐 Passwords are securely hashed with PBKDF2.</div>
          <div className="rounded-2xl bg-white/10 p-4">🛡️ Contact phone & email remain private by default.</div>
          <div className="rounded-2xl bg-white/10 p-4">💬 Private messaging unlocks upon accepted interest.</div>
        </div>
      </aside>
    </div>
  );
}
