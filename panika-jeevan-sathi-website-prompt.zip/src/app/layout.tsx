import type { Metadata } from "next";
import type { ReactNode } from "react";
import { APP_NAME, CONTACT_EMAIL, TAGLINE, SITE_URL } from "@/lib/constants";
import { getCurrentUser } from "@/lib/auth";
import { getUnreadNotificationCount } from "@/lib/data";
import { SiteChrome } from "@/components/site-chrome";
import "./globals.css";

export const dynamic = "force-dynamic";

function getBaseUrl(rawUrl: string): URL {
  try {
    const formatted = rawUrl.startsWith("http://") || rawUrl.startsWith("https://") ? rawUrl : `https://${rawUrl}`;
    return new URL(formatted);
  } catch {
    return new URL("http://localhost:3000");
  }
}

const baseUrl = getBaseUrl(SITE_URL);

export const metadata: Metadata = {
  title: `${APP_NAME} — ${TAGLINE}`,
  description: "A trusted, privacy-first matrimonial platform for finding meaningful life partnerships.",
  metadataBase: baseUrl,
  alternates: {
    canonical: baseUrl.toString(),
  },
  openGraph: {
    title: APP_NAME,
    description: TAGLINE,
    url: baseUrl.toString(),
    siteName: APP_NAME,
    type: "website",
  },
  twitter: {
    card: "summary_large_image",
    title: APP_NAME,
    description: TAGLINE,
  },
  other: {
    "contact:email": CONTACT_EMAIL,
  },
};

export default async function RootLayout({ children }: { children: ReactNode }) {
  const user = await getCurrentUser().catch(() => null);
  const unreadCount = user ? await getUnreadNotificationCount(user.id).catch(() => 0) : 0;

  return (
    <html lang="en-IN">
      <body className="bg-slate-50 text-slate-900 antialiased">
        <SiteChrome user={user} unreadCount={unreadCount}>
          {children}
        </SiteChrome>
      </body>
    </html>
  );
}
