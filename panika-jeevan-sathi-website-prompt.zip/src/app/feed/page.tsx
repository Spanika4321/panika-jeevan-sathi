import Link from "next/link";
import { PostComposer } from "@/components/client-forms";
import { Avatar, EmptyState, NoticeBar, SectionHeading } from "@/components/ui";
import { getCurrentUser } from "@/lib/auth";
import { getFeed } from "@/lib/data";
import { formatTime, searchParam } from "@/lib/utils";

export const dynamic = "force-dynamic";

type FeedPageProps = {
  searchParams: Promise<Record<string, string | string[] | undefined>>;
};

export default async function FeedPage({ searchParams }: FeedPageProps) {
  const params = await searchParams;
  const user = await getCurrentUser().catch(() => null);
  const feed = await getFeed(user?.id).catch(() => []);

  return (
    <div className="mx-auto grid max-w-6xl gap-8 px-4 py-8 sm:px-6 lg:grid-cols-[360px_1fr] lg:px-8">
      <aside className="space-y-5 lg:sticky lg:top-24 lg:h-fit">
        <NoticeBar notice={searchParam(params, "notice")} error={searchParam(params, "error")} />
        <SectionHeading eyebrow="Community Feed" title="Matrimonial Community Updates">
          Share reflections on family values, personal milestones, and thoughts on companionship.
        </SectionHeading>
        {user ? (
          <PostComposer />
        ) : (
          <div className="rounded-3xl bg-white p-6 shadow-xl shadow-slate-200/70">
            <p className="text-sm leading-6 text-slate-600">Login to share posts, like, and comment on matrimonial updates.</p>
            <Link href="/login?next=/feed" className="mt-4 inline-flex rounded-full bg-[#F43F5E] px-5 py-3 text-sm font-black text-white">Login</Link>
          </div>
        )}
      </aside>

      <section className="space-y-5">
        {feed.length === 0 ? (
          <EmptyState title="No community posts yet" body="Be the first to share a respectful matrimonial post with the community." />
        ) : (
          feed.map(({ post, author, likesCount, commentsCount, likedByMe, comments }) => author && (
            <article key={post.id} className="overflow-hidden rounded-[2rem] bg-white shadow-xl shadow-slate-200/70">
              <div className="flex items-center gap-3 p-5">
                <Avatar profile={author} />
                <div className="min-w-0 flex-1">
                  <Link href={`/profile/${author.userId}`} className="font-black text-[#1E1B4B] hover:text-[#F43F5E]">{author.fullName}</Link>
                  <p className="text-xs font-semibold text-slate-400">{formatTime(post.createdAt)}</p>
                </div>
                {user && (user.id === post.authorId || user.role === "admin") && (
                  <form action="/api/actions" method="post">
                    <input type="hidden" name="action" value="deletePost" />
                    <input type="hidden" name="postId" value={post.id} />
                    <button className="rounded-full bg-red-50 px-3 py-1.5 text-xs font-black text-red-700 hover:bg-red-100">Delete</button>
                  </form>
                )}
              </div>
              <p className="whitespace-pre-line px-5 pb-4 text-sm leading-7 text-slate-700">{post.content}</p>
              {post.photoUrl && <img src={post.photoUrl} alt="Community post" loading="lazy" className="max-h-[520px] w-full object-cover" />}
              <div className="flex flex-wrap items-center justify-between gap-3 border-y border-slate-100 px-5 py-3 text-sm font-bold text-slate-600">
                <span>{likesCount} likes • {commentsCount} comments</span>
                {user && (
                  <div className="flex gap-2">
                    <form action="/api/actions" method="post">
                      <input type="hidden" name="action" value="likePost" />
                      <input type="hidden" name="postId" value={post.id} />
                      <button className={`rounded-full px-4 py-1.5 text-xs font-black transition ${likedByMe ? "bg-[#F43F5E] text-white" : "bg-rose-50 text-[#F43F5E] hover:bg-rose-100"}`}>{likedByMe ? "Liked" : "Like"}</button>
                    </form>
                    <form action="/api/actions" method="post">
                      <input type="hidden" name="action" value="reportPost" />
                      <input type="hidden" name="postId" value={post.id} />
                      <input type="hidden" name="reason" value="Reported post" />
                      <button className="rounded-full bg-amber-50 px-4 py-1.5 text-xs font-black text-amber-800 hover:bg-amber-100">Report</button>
                    </form>
                  </div>
                )}
              </div>
              <div className="space-y-3 p-5">
                {comments.map(({ comment, author: commentAuthor }) => commentAuthor && (
                  <div key={comment.id} className="flex items-start justify-between gap-3 rounded-2xl bg-slate-50 p-3">
                    <div className="flex gap-3">
                      <Avatar profile={commentAuthor} size="sm" />
                      <div>
                        <p className="text-xs font-black text-[#1E1B4B]">{commentAuthor.fullName}</p>
                        <p className="text-sm leading-6 text-slate-700">{comment.content}</p>
                      </div>
                    </div>
                    {user && (user.id === comment.authorId || user.role === "admin") && (
                      <form action="/api/actions" method="post">
                        <input type="hidden" name="action" value="deleteComment" />
                        <input type="hidden" name="commentId" value={comment.id} />
                        <button className="text-[11px] font-bold text-red-500 hover:underline">Delete</button>
                      </form>
                    )}
                  </div>
                ))}
                {user && (
                  <form action="/api/actions" method="post" className="flex gap-2 pt-2">
                    <input type="hidden" name="action" value="commentPost" />
                    <input type="hidden" name="postId" value={post.id} />
                    <input name="content" placeholder="Write a respectful comment..." className="min-w-0 flex-1 rounded-full bg-slate-50 px-4 py-2.5 text-sm outline-none focus:ring-4 focus:ring-rose-100" required />
                    <button className="rounded-full bg-[#1E1B4B] px-5 py-2.5 text-sm font-black text-white hover:bg-indigo-950">Comment</button>
                  </form>
                )}
              </div>
            </article>
          ))
        )}
      </section>
    </div>
  );
}
