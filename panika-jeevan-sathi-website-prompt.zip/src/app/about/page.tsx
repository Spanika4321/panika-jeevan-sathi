import { APP_NAME, TAGLINE } from "@/lib/constants";
import { SectionHeading } from "@/components/ui";

export default function AboutPage() {
  return (
    <div className="mx-auto max-w-5xl px-4 py-10 sm:px-6 lg:px-8">
      <SectionHeading eyebrow="About Us" title={APP_NAME}>
        {TAGLINE}
      </SectionHeading>
      <div className="grid gap-5 md:grid-cols-2">
        <section className="rounded-[2rem] bg-white p-6 shadow-xl shadow-slate-200/70"><h2 className="text-xl font-black text-[#1E1B4B]">Our Purpose</h2><p className="mt-3 text-sm leading-7 text-slate-700">Panika Jeevan Sathi helps people and families discover meaningful life-partner connections through detailed profiles, respectful interests, privacy-first messaging and admin-reviewed visibility.</p></section>
        <section className="rounded-[2rem] bg-white p-6 shadow-xl shadow-slate-200/70"><h2 className="text-xl font-black text-[#1E1B4B]">हमारा उद्देश्य</h2><p className="mt-3 text-sm leading-7 text-slate-700">Panika Jeevan Sathi detailed profiles, privacy controls और safe communication के साथ meaningful life partner खोजने में सहायता करता है।</p></section>
      </div>
    </div>
  );
}
