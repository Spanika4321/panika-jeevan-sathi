import Link from "next/link";
import { requireAdmin } from "@/lib/auth";
import { getAdminDashboardData } from "@/lib/data";
import { formatTime, searchParam } from "@/lib/utils";
import { Avatar, NoticeBar, SectionHeading, StatusPill } from "@/components/ui";

export const dynamic = "force-dynamic";

type AdminPageProps = {
  searchParams: Promise<Record<string, string | string[] | undefined>>;
};

const statLabels = [
  ["totalUsers", "Total Users"],
  ["activeUsers", "Active Users"],
  ["newUsers", "New Users (7d)"],
  ["verifiedProfiles", "Verified Profiles"],
  ["pendingReports", "Pending Reports"],
  ["suspendedAccounts", "Suspended Accounts"],
] as const;

function AdminAction({ userId, task, label, tone = "navy" }: { userId: number; task: string; label: string; tone?: "navy" | "rose" | "green" | "amber" | "red" }) {
  const classes =
    tone === "rose"
      ? "bg-[#F43F5E] text-white hover:bg-rose-600"
      : tone === "green"
        ? "bg-emerald-50 text-emerald-700 hover:bg-emerald-100"
        : tone === "amber"
          ? "bg-amber-50 text-amber-700 hover:bg-amber-100"
          : tone === "red"
            ? "bg-red-50 text-red-700 hover:bg-red-100"
            : "bg-[#1E1B4B] text-white hover:bg-indigo-950";
  return (
    <form action="/api/actions" method="post">
      <input type="hidden" name="action" value="adminUserAction" />
      <input type="hidden" name="targetUserId" value={userId} />
      <input type="hidden" name="adminTask" value={task} />
      <button className={`rounded-full px-3 py-1.5 text-[11px] font-black transition ${classes}`}>{label}</button>
    </form>
  );
}

export default async function AdminPage({ searchParams }: AdminPageProps) {
  const params = await searchParams;
  const admin = await requireAdmin();
  const search = searchParam(params, "q");
  const data = await getAdminDashboardData(search);

  return (
    <div className="mx-auto max-w-7xl px-4 py-8 sm:px-6 lg:px-8">
      <NoticeBar notice={searchParam(params, "notice")} error={searchParam(params, "error")} />
      <div className="grid gap-8 lg:grid-cols-[280px_1fr]">
        <aside className="space-y-4 lg:sticky lg:top-24 lg:h-fit">
          <div className="rounded-[2rem] bg-[#1E1B4B] p-6 text-white shadow-2xl shadow-indigo-950/20">
            <p className="text-xs font-black uppercase tracking-[0.2em] text-rose-200">Admin Dashboard</p>
            <h1 className="mt-3 text-2xl font-black">Welcome, {admin.fullName}</h1>
            <p className="mt-2 text-xs leading-5 text-indigo-100">Review registrations, moderate profiles, handle safety reports, verify members and issue platform announcements.</p>
          </div>
          <nav className="grid gap-2 rounded-3xl bg-white p-4 text-sm font-bold shadow-xl shadow-slate-200/70">
            <a href="#users" className="rounded-2xl px-4 py-3 hover:bg-rose-50">Users & Profiles</a>
            <a href="#reports" className="rounded-2xl px-4 py-3 hover:bg-rose-50">Reports ({data.stats.pendingReports})</a>
            <a href="#verification" className="rounded-2xl px-4 py-3 hover:bg-rose-50">Verification Requests</a>
            <a href="#interests" className="rounded-2xl px-4 py-3 hover:bg-rose-50">Interests Stream</a>
            <a href="#announcements" className="rounded-2xl px-4 py-3 hover:bg-rose-50">Announcements</a>
          </nav>
        </aside>

        <main className="space-y-8">
          <SectionHeading eyebrow="Platform Statistics" title="Overview & Moderation Controls" />
          <section className="grid gap-4 sm:grid-cols-2 xl:grid-cols-3">
            {statLabels.map(([key, label]) => (
              <div key={key} className="rounded-3xl bg-white p-6 shadow-xl shadow-slate-200/70">
                <p className="text-sm font-bold text-slate-500">{label}</p>
                <p className="mt-2 text-4xl font-black text-[#1E1B4B]">{data.stats[key]}</p>
              </div>
            ))}
          </section>

          <section id="users" className="rounded-[2rem] bg-white p-5 shadow-xl shadow-slate-200/70">
            <div className="flex flex-col justify-between gap-4 sm:flex-row sm:items-center">
              <div>
                <h2 className="text-2xl font-black text-[#1E1B4B]">Member Management</h2>
                <p className="mt-1 text-xs text-slate-500">New profiles are hidden from search until approved by admin.</p>
              </div>
              <form method="get" className="flex gap-2">
                <input name="q" defaultValue={search} placeholder="Search name, email, phone" className="min-w-0 rounded-full bg-slate-50 px-4 py-2.5 text-sm outline-none ring-1 ring-slate-200" />
                <button className="rounded-full bg-[#F43F5E] px-5 py-2.5 text-sm font-black text-white hover:bg-rose-600">Search</button>
              </form>
            </div>
            <div className="mt-5 overflow-x-auto">
              <table className="w-full min-w-[900px] text-left text-sm">
                <thead className="text-xs uppercase tracking-[0.15em] text-slate-400">
                  <tr>
                    <th className="py-3">Member</th>
                    <th>Status</th>
                    <th>Approval</th>
                    <th>Verification</th>
                    <th>Joined</th>
                    <th>Moderation Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {data.users.map((item) => (
                    <tr key={item.id} className="border-t border-slate-100 align-top">
                      <td className="py-4">
                        <p className="font-black text-[#1E1B4B]">{item.fullName}</p>
                        <p className="text-xs text-slate-500">{item.email} • {item.mobile}</p>
                        <p className="text-xs text-slate-400">{item.location || "Location not specified"}</p>
                      </td>
                      <td className="py-4"><StatusPill value={item.status} /></td>
                      <td className="py-4"><StatusPill value={item.approvalStatus} /></td>
                      <td className="py-4"><StatusPill value={item.verificationStatus} /></td>
                      <td className="py-4 text-xs font-semibold text-slate-500">{formatTime(item.createdAt)}</td>
                      <td className="py-4">
                        <div className="flex flex-wrap gap-1.5">
                          <Link href={`/profile/${item.id}`} className="rounded-full bg-slate-100 px-3 py-1.5 text-[11px] font-black text-slate-700 hover:bg-slate-200">View</Link>
                          {item.approvalStatus !== "approved" && <AdminAction userId={item.id} task="approveProfile" label="Approve" tone="green" />}
                          {item.approvalStatus !== "rejected" && <AdminAction userId={item.id} task="rejectProfile" label="Reject" tone="amber" />}
                          {item.verificationStatus !== "verified" ? (
                            <AdminAction userId={item.id} task="verifyProfile" label="Verify" tone="navy" />
                          ) : (
                            <AdminAction userId={item.id} task="unverifyProfile" label="Unverify" tone="amber" />
                          )}
                          {item.status !== "suspended" ? (
                            <AdminAction userId={item.id} task="suspendUser" label="Suspend" tone="red" />
                          ) : (
                            <AdminAction userId={item.id} task="activateUser" label="Activate" tone="rose" />
                          )}
                          <AdminAction userId={item.id} task="deleteUser" label="Delete" tone="red" />
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </section>

          <section id="reports" className="rounded-[2rem] bg-white p-5 shadow-xl shadow-slate-200/70">
            <h2 className="text-2xl font-black text-[#1E1B4B]">Reported Profiles & Posts</h2>
            <div className="mt-5 space-y-3">
              {data.reports.length === 0 ? (
                <p className="text-sm text-slate-500">No member reports at this time.</p>
              ) : (
                data.reports.map(({ report, reporter, reported }) => (
                  <article key={report.id} className="rounded-3xl border border-slate-100 p-4">
                    <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
                      <div>
                        <p className="font-black text-[#1E1B4B]">{report.reason}</p>
                        <p className="text-sm text-slate-600">
                          Reporter: {reporter?.fullName || "Anonymous"} {reported ? `• Reported User: ${reported.fullName}` : report.postId ? `• Reported Post #${report.postId}` : ""}
                        </p>
                        {report.details && <p className="mt-2 text-sm text-slate-600 bg-slate-50 p-2.5 rounded-xl">{report.details}</p>}
                      </div>
                      <StatusPill value={report.status} />
                    </div>
                    <form action="/api/actions" method="post" className="mt-4 flex flex-col gap-2 sm:flex-row sm:items-center">
                      <input type="hidden" name="action" value="adminReportAction" />
                      <input type="hidden" name="reportId" value={report.id} />
                      <select name="status" defaultValue={report.status} className="rounded-full bg-slate-50 px-4 py-2 text-sm font-semibold">
                        <option value="pending">Pending</option>
                        <option value="reviewed">Reviewed</option>
                        <option value="resolved">Resolved</option>
                        <option value="dismissed">Dismissed</option>
                      </select>
                      <input name="adminNote" defaultValue={report.adminNote || ""} placeholder="Admin resolution note" className="min-w-0 flex-1 rounded-full bg-slate-50 px-4 py-2 text-sm" />
                      {report.postId && (
                        <label className="flex items-center gap-2 text-xs font-bold text-red-700 bg-red-50 px-3 py-2 rounded-full">
                          <input type="checkbox" name="deleteReportedPost" value="true" />
                          Delete Post #{report.postId}
                        </label>
                      )}
                      <button className="rounded-full bg-[#1E1B4B] px-5 py-2 text-sm font-black text-white hover:bg-indigo-950">Update Report</button>
                    </form>
                  </article>
                ))
              )}
            </div>
          </section>

          <section id="verification" className="rounded-[2rem] bg-white p-5 shadow-xl shadow-slate-200/70">
            <h2 className="text-2xl font-black text-[#1E1B4B]">Verification Requests</h2>
            <p className="mt-2 text-xs text-slate-600">Verification indicates manual platform profile review and trust confirmation.</p>
            <div className="mt-5 grid gap-3 md:grid-cols-2">
              {data.verificationRequests.length === 0 ? (
                <p className="text-sm text-slate-500">No pending verification requests.</p>
              ) : (
                data.verificationRequests.map(({ request, profile }) => profile && (
                  <article key={request.id} className="rounded-3xl border border-slate-100 p-4">
                    <div className="flex items-center gap-3">
                      <Avatar profile={profile} />
                      <div>
                        <Link href={`/profile/${profile.userId}`} className="font-black text-[#1E1B4B] hover:text-[#F43F5E]">{profile.fullName}</Link>
                        <p className="text-xs text-slate-500">{request.note || "No note provided"}</p>
                      </div>
                    </div>
                    <div className="mt-3 flex gap-2">
                      <AdminAction userId={profile.userId} task="verifyProfile" label="Approve Verification" tone="green" />
                    </div>
                  </article>
                ))
              )}
            </div>
          </section>

          <section id="interests" className="rounded-[2rem] bg-white p-5 shadow-xl shadow-slate-200/70">
            <h2 className="text-2xl font-black text-[#1E1B4B]">Recent Interests Stream</h2>
            <div className="mt-5 space-y-3">
              {data.recentInterests.length === 0 ? (
                <p className="text-sm text-slate-500">No member interests recorded yet.</p>
              ) : (
                data.recentInterests.map(({ interest, sender, receiver }) => (
                  <article key={interest.id} className="rounded-3xl border border-slate-100 p-4 text-sm">
                    <div className="flex flex-wrap items-center justify-between gap-3">
                      <p><strong>{sender?.fullName || "User"}</strong> → <strong>{receiver?.fullName || "User"}</strong></p>
                      <StatusPill value={interest.status} />
                    </div>
                    <p className="mt-1 text-xs text-slate-400">{formatTime(interest.createdAt)}</p>
                  </article>
                ))
              )}
            </div>
          </section>

          <section id="announcements" className="grid gap-5 lg:grid-cols-2">
            <div className="rounded-[2rem] bg-white p-5 shadow-xl shadow-slate-200/70">
              <h2 className="text-2xl font-black text-[#1E1B4B]">Create Announcement</h2>
              <form action="/api/actions" method="post" className="mt-5 space-y-3">
                <input type="hidden" name="action" value="adminAnnouncement" />
                <input name="title" placeholder="Announcement title" className="w-full rounded-2xl border border-slate-200 px-4 py-3 text-sm outline-none focus:border-[#F43F5E]" required />
                <textarea name="body" rows={5} placeholder="Announcement details sent to all active members..." className="w-full rounded-2xl border border-slate-200 px-4 py-3 text-sm outline-none focus:border-[#F43F5E]" required />
                <button className="w-full rounded-full bg-[#F43F5E] px-5 py-3 font-black text-white shadow-lg shadow-rose-500/25 hover:bg-rose-600">Send Announcement</button>
              </form>
            </div>
            <div className="rounded-[2rem] bg-white p-5 shadow-xl shadow-slate-200/70">
              <h2 className="text-2xl font-black text-[#1E1B4B]">Recent Announcements</h2>
              <div className="mt-5 space-y-3">
                {data.announcements.length === 0 ? (
                  <p className="text-sm text-slate-500">No platform announcements published yet.</p>
                ) : (
                  data.announcements.map((announcement) => (
                    <article key={announcement.id} className="rounded-2xl bg-slate-50 p-4">
                      <p className="font-black text-[#1E1B4B]">{announcement.title}</p>
                      <p className="mt-1 text-sm text-slate-600">{announcement.body}</p>
                      <p className="mt-2 text-xs font-semibold text-slate-400">{formatTime(announcement.createdAt)}</p>
                    </article>
                  ))
                )}
              </div>
            </div>
          </section>
        </main>
      </div>
    </div>
  );
}
