import Link from "next/link";
import { ForgotPasswordForm } from "@/components/client-forms";
import { NoticeBar, SectionHeading } from "@/components/ui";
import { searchParam } from "@/lib/utils";

export const dynamic = "force-dynamic";

type ForgotPasswordPageProps = {
  searchParams: Promise<Record<string, string | string[] | undefined>>;
};

export default async function ForgotPasswordPage({ searchParams }: ForgotPasswordPageProps) {
  const params = await searchParams;
  const token = searchParam(params, "token");

  return (
    <div className="mx-auto max-w-3xl px-4 py-10 sm:px-6 lg:px-8">
      <NoticeBar notice={searchParam(params, "notice")} error={searchParam(params, "error")} />
      <SectionHeading eyebrow="Account Recovery" title={token ? "Reset your password" : "Forgot Password"}>
        {token ? "Choose a new strong password for your account." : "Enter your registered email. If it exists, a secure reset link will be sent."}
      </SectionHeading>
      <ForgotPasswordForm token={token || undefined} />
      <p className="mt-5 text-center text-sm font-semibold text-slate-600"><Link href="/login" className="text-[#F43F5E]">Back to Login</Link></p>
    </div>
  );
}
