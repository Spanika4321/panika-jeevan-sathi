import Link from "next/link";
import { APP_NAME, TAGLINE, WELCOME_TEXT, featureCards } from "@/lib/constants";
import { getHomeStats } from "@/lib/data";
import { getCurrentUser } from "@/lib/auth";
import { SafetyBanner } from "@/components/ui";

export const dynamic = "force-dynamic";

export default async function HomePage() {
  const [stats, user] = await Promise.all([
    getHomeStats().catch(() => ({ totalUsers: 0, verifiedProfiles: 0, successfulMatches: 0 })),
    getCurrentUser().catch(() => null),
  ]);

  return (
    <div>
      <section className="relative overflow-hidden">
        <div className="absolute inset-0 -z-10 bg-[radial-gradient(circle_at_15%_20%,rgba(244,63,94,0.18),transparent_26rem),radial-gradient(circle_at_85%_10%,rgba(30,27,75,0.18),transparent_24rem)]" />
        <div className="mx-auto grid max-w-7xl items-center gap-10 px-4 py-12 sm:px-6 md:py-20 lg:grid-cols-[1fr_0.9fr] lg:px-8">
          <div>
            <div className="inline-flex rounded-full border border-rose-100 bg-white/80 px-4 py-2 text-xs font-black uppercase tracking-[0.22em] text-[#F43F5E] shadow-sm">
              Trusted Matrimonial Platform
            </div>
            <h1 className="mt-5 text-4xl font-black tracking-tight text-[#1E1B4B] sm:text-6xl lg:text-7xl">{WELCOME_TEXT}</h1>
            <p className="mt-5 max-w-2xl text-lg leading-8 text-slate-700">Find someone who understands you, respects you and wants to build a beautiful future with you.</p>
            <p className="mt-3 text-base font-bold text-[#1E1B4B]">{TAGLINE}</p>

            {user && (
              <div className="mt-6 inline-flex items-center gap-2 rounded-2xl bg-emerald-50 px-4 py-2 text-sm font-bold text-emerald-800">
                <span>👋 Welcome back, <strong>{user.fullName}</strong>!</span>
              </div>
            )}

            <div className="mt-8 flex flex-col gap-3 sm:flex-row">
              <Link href="/find-matches" className="rounded-full bg-[#F43F5E] px-7 py-4 text-center font-black text-white shadow-xl shadow-rose-500/25 transition hover:-translate-y-0.5 hover:bg-rose-600">
                Find Your Partner
              </Link>
              {user ? (
                <Link href="/recommended-matches" className="rounded-full border border-[#1E1B4B]/10 bg-white px-7 py-4 text-center font-black text-[#1E1B4B] shadow-xl shadow-slate-200/70 transition hover:-translate-y-0.5 hover:border-[#F43F5E]">
                  Recommended Matches
                </Link>
              ) : (
                <Link href="/register" className="rounded-full border border-[#1E1B4B]/10 bg-white px-7 py-4 text-center font-black text-[#1E1B4B] shadow-xl shadow-slate-200/70 transition hover:-translate-y-0.5 hover:border-[#F43F5E]">
                  Create Profile
                </Link>
              )}
            </div>

            <div className="mt-8 grid max-w-xl grid-cols-3 gap-3">
              <div className="rounded-3xl bg-white/90 p-4 text-center shadow-sm">
                <p className="text-2xl font-black text-[#1E1B4B]">{stats.totalUsers}</p>
                <p className="text-xs font-bold text-slate-500">Members</p>
              </div>
              <div className="rounded-3xl bg-white/90 p-4 text-center shadow-sm">
                <p className="text-2xl font-black text-[#1E1B4B]">{stats.verifiedProfiles}</p>
                <p className="text-xs font-bold text-slate-500">Verified</p>
              </div>
              <div className="rounded-3xl bg-white/90 p-4 text-center shadow-sm">
                <p className="text-2xl font-black text-[#1E1B4B]">{stats.successfulMatches}</p>
                <p className="text-xs font-bold text-slate-500">Matches</p>
              </div>
            </div>
          </div>

          <div className="relative">
            <div className="absolute -inset-4 rounded-[2.5rem] bg-gradient-to-br from-[#F43F5E]/20 to-[#1E1B4B]/20 blur-2xl" />
            <div className="relative overflow-hidden rounded-[2rem] border border-white bg-white p-3 shadow-2xl shadow-slate-300/60">
              <img src="/images/panika-hero.png" alt="Matrimonial couple banner" className="aspect-[4/3] w-full rounded-[1.5rem] object-cover" loading="eager" />
              <div className="absolute bottom-6 left-6 right-6 rounded-3xl bg-white/92 p-4 shadow-xl backdrop-blur">
                <p className="text-sm font-black text-[#1E1B4B]">Privacy-first matching</p>
                <p className="mt-1 text-xs leading-5 text-slate-600">Accepted interests unlock private conversations. Phone and email stay hidden unless you choose otherwise.</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      <section className="mx-auto max-w-7xl px-4 py-10 sm:px-6 lg:px-8">
        <div className="mb-8 text-center">
          <p className="text-xs font-black uppercase tracking-[0.22em] text-[#F43F5E]">Why Panika Jeevan Sathi?</p>
          <h2 className="mt-2 text-3xl font-black text-[#1E1B4B] sm:text-4xl">Designed for trust, privacy and meaningful matching</h2>
        </div>
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {featureCards.map(([title, body, icon]) => (
            <article key={title} className="rounded-3xl border border-slate-100 bg-white p-6 shadow-sm transition hover:-translate-y-1 hover:shadow-xl">
              <div className="grid h-12 w-12 place-items-center rounded-2xl bg-rose-50 text-2xl">{icon}</div>
              <h3 className="mt-5 text-lg font-black text-[#1E1B4B]">{title}</h3>
              <p className="mt-2 text-sm leading-6 text-slate-600">{body}</p>
            </article>
          ))}
        </div>
      </section>

      <section className="mx-auto max-w-7xl px-4 pb-12 sm:px-6 lg:px-8">
        <SafetyBanner />
      </section>

      <section className="mx-auto max-w-5xl px-4 pb-16 text-center sm:px-6 lg:px-8">
        <div className="rounded-[2rem] bg-[#1E1B4B] p-8 text-white shadow-2xl shadow-indigo-950/20 sm:p-12">
          <p className="text-sm font-black uppercase tracking-[0.22em] text-rose-200">Start carefully. Move confidently.</p>
          <h2 className="mt-3 text-3xl font-black sm:text-4xl">
            {user ? "Explore matrimonial matches" : `Create your ${APP_NAME} profile today`}
          </h2>
          <p className="mx-auto mt-3 max-w-2xl text-sm leading-6 text-indigo-100">
            Registration uses email OTP and admin profile review before public visibility, so members can search with more confidence.
          </p>
          <Link href={user ? "/find-matches" : "/register"} className="mt-7 inline-flex rounded-full bg-white px-7 py-4 font-black text-[#1E1B4B] hover:bg-slate-100">
            {user ? "Explore Matches" : "Register Now"}
          </Link>
        </div>
      </section>
    </div>
  );
}
