import Link from "next/link";
import { requireUser } from "@/lib/auth";
import { getConversationList } from "@/lib/data";
import { formatTime, searchParam } from "@/lib/utils";
import { Avatar, EmptyState, NoticeBar, SectionHeading } from "@/components/ui";

export const dynamic = "force-dynamic";

type MessagesPageProps = {
  searchParams: Promise<Record<string, string | string[] | undefined>>;
};

export default async function MessagesPage({ searchParams }: MessagesPageProps) {
  const params = await searchParams;
  const user = await requireUser();
  const conversations = await getConversationList(user.id);

  return (
    <div className="mx-auto max-w-5xl px-4 py-8 sm:px-6 lg:px-8">
      <NoticeBar notice={searchParam(params, "notice")} error={searchParam(params, "error")} />
      <SectionHeading eyebrow="Messages" title="Private conversations">
        Messaging is available only after an interest is accepted. Keep conversations respectful and safe.
      </SectionHeading>
      <div className="rounded-[2rem] bg-white p-4 shadow-xl shadow-slate-200/70">
        {conversations.length === 0 ? <EmptyState title="No conversations yet" body="Accept or receive accepted matrimonial interests to begin private messaging." actionHref="/interests" actionLabel="View Interests" /> : conversations.map(({ conversation, other, lastMessage, unreadCount }) => other && (
          <article key={conversation.id} className="flex flex-col gap-4 border-b border-slate-100 p-4 last:border-b-0 sm:flex-row sm:items-center">
            <Link href={`/messages/${conversation.id}`} className="flex min-w-0 flex-1 items-center gap-4">
              <Avatar profile={other} />
              <div className="min-w-0">
                <div className="flex items-center gap-2"><h2 className="truncate font-black text-[#1E1B4B]">{other.fullName}</h2>{unreadCount > 0 && <span className="rounded-full bg-[#F43F5E] px-2 py-0.5 text-xs font-black text-white">{unreadCount}</span>}</div>
                <p className="truncate text-sm text-slate-600">{lastMessage?.content || "No messages yet"}</p>
                <p className="text-xs font-semibold text-slate-400">{lastMessage ? formatTime(lastMessage.createdAt) : formatTime(conversation.createdAt)}</p>
              </div>
            </Link>
            <form action="/api/actions" method="post">
              <input type="hidden" name="action" value="deleteConversation" />
              <input type="hidden" name="conversationId" value={conversation.id} />
              <button className="rounded-full bg-red-50 px-4 py-2 text-xs font-black text-red-700">Delete</button>
            </form>
          </article>
        ))}
      </div>
    </div>
  );
}
