import Link from "next/link";
import { notFound } from "next/navigation";
import { MessageComposer } from "@/components/client-forms";
import { Avatar, NoticeBar, SectionHeading } from "@/components/ui";
import { requireUser } from "@/lib/auth";
import { getChat } from "@/lib/data";
import { formatTime, searchParam } from "@/lib/utils";

export const dynamic = "force-dynamic";

type ChatPageProps = {
  params: Promise<{ id: string }>;
  searchParams: Promise<Record<string, string | string[] | undefined>>;
};

export default async function ChatPage({ params, searchParams }: ChatPageProps) {
  const [{ id }, query] = await Promise.all([params, searchParams]);
  const conversationId = Number.parseInt(id, 10);
  if (!Number.isFinite(conversationId)) notFound();
  const user = await requireUser();
  const chat = await getChat(user.id, conversationId);
  if (!chat) notFound();

  return (
    <div className="mx-auto flex min-h-[calc(100vh-12rem)] max-w-4xl flex-col px-4 py-6 sm:px-6 lg:px-8">
      <NoticeBar notice={searchParam(query, "notice")} error={searchParam(query, "error")} />
      <div className="sticky top-[73px] z-20 rounded-3xl border border-slate-100 bg-white/95 p-4 shadow-xl shadow-slate-200/60 backdrop-blur">
        <div className="flex items-center gap-3">
          {chat.other && <Avatar profile={chat.other} />}
          <div className="min-w-0 flex-1">
            <SectionHeading eyebrow="Private Chat" title={chat.other?.fullName || "Conversation"}>
              Only accepted matrimonial matches can exchange messages.
            </SectionHeading>
          </div>
          <Link href="/messages" className="rounded-full bg-slate-100 px-4 py-2 text-xs font-black text-slate-700 hover:bg-slate-200">Inbox</Link>
        </div>
      </div>

      <div className="flex-1 space-y-3 py-6">
        {chat.messages.length === 0 ? (
          <p className="rounded-3xl bg-white p-6 text-center text-sm font-semibold text-slate-500 shadow">No messages yet. Start with a respectful introduction.</p>
        ) : (
          chat.messages.map((message) => {
            const mine = message.senderId === user.id;
            return (
              <div key={message.id} className={`flex ${mine ? "justify-end" : "justify-start"}`}>
                <div className={`max-w-[82%] rounded-3xl px-4 py-3 shadow-sm ${mine ? "bg-[#F43F5E] text-white" : "bg-white text-slate-800"}`}>
                  <p className="whitespace-pre-line text-sm leading-6">{message.content}</p>
                  <p className={`mt-1 text-[11px] font-semibold ${mine ? "text-rose-100" : "text-slate-400"}`}>{formatTime(message.createdAt)} {mine && message.readAt ? "• Read" : ""}</p>
                </div>
              </div>
            );
          })
        )}
      </div>

      <MessageComposer conversationId={conversationId} isBlocked={chat.isBlocked} />
    </div>
  );
}
