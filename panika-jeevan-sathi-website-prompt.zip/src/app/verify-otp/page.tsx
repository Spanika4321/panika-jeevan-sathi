import Link from "next/link";
import { VerifyOtpForm } from "@/components/client-forms";
import { NoticeBar, SectionHeading } from "@/components/ui";
import { searchParam } from "@/lib/utils";

export const dynamic = "force-dynamic";

type VerifyOtpPageProps = {
  searchParams: Promise<Record<string, string | string[] | undefined>>;
};

export default async function VerifyOtpPage({ searchParams }: VerifyOtpPageProps) {
  const params = await searchParams;
  const email = searchParam(params, "email");
  const notice = searchParam(params, "notice");
  const error = searchParam(params, "error");

  return (
    <div className="mx-auto max-w-xl px-4 py-12 sm:px-6 lg:px-8">
      <NoticeBar notice={notice} error={error} />
      <SectionHeading eyebrow="Email Verification" title="Verify your email OTP">
        Enter the 6-digit verification code sent to your registered email to activate your account.
      </SectionHeading>
      <VerifyOtpForm initialEmail={email} />
      <div className="mt-6 flex flex-wrap justify-between text-xs font-bold text-slate-500">
        <Link href="/login" className="hover:text-[#F43F5E]">Already verified? Login here</Link>
        <Link href="/register" className="hover:text-[#F43F5E]">Register new account</Link>
      </div>
    </div>
  );
}
