import { CONTACT_EMAIL } from "@/lib/constants";
import { SectionHeading } from "@/components/ui";

export default function TermsPage() {
  return (
    <div className="mx-auto max-w-4xl px-4 py-10 sm:px-6 lg:px-8">
      <SectionHeading eyebrow="Terms & Conditions" title="Use Panika Jeevan Sathi responsibly">
        These terms support a respectful, truthful and safe matrimonial community.
      </SectionHeading>
      <div className="space-y-5 rounded-[2rem] bg-white p-6 text-sm leading-7 text-slate-700 shadow-xl shadow-slate-200/70">
        <h2 className="text-xl font-black text-[#1E1B4B]">English</h2>
        <p>Users must provide truthful information, use respectful communication and follow applicable laws. Fake profiles, harassment, fraud, money requests, abusive content and spam are prohibited.</p>
        <p>New profiles require admin approval before public visibility. Verification badges mean platform admin review only and do not represent government verification.</p>
        <p>Panika Jeevan Sathi provides tools for discovery and communication; relationship decisions remain the responsibility of users and families.</p>
        <h2 className="pt-4 text-xl font-black text-[#1E1B4B]">हिन्दी</h2>
        <p>Users को सही जानकारी देनी होगी, respectful communication रखना होगा और कानूनों का पालन करना होगा। Fake profiles, harassment, fraud, पैसे मांगना, abusive content और spam मना है।</p>
        <p>Public visibility से पहले new profiles को admin approval चाहिए। Verification badge केवल platform admin review दर्शाता है, government verification नहीं।</p>
        <p>Panika Jeevan Sathi discovery और communication tools देता है; relationship decisions users और families की जिम्मेदारी हैं।</p>
        <p>Contact: <a className="font-bold text-[#F43F5E]" href={`mailto:${CONTACT_EMAIL}`}>{CONTACT_EMAIL}</a></p>
      </div>
    </div>
  );
}
