import Link from "next/link";
import { RegisterWizard } from "@/components/client-forms";
import { SectionHeading } from "@/components/ui";
import { WELCOME_TEXT } from "@/lib/constants";

export const dynamic = "force-dynamic";

export default function RegisterPage() {
  return (
    <div className="mx-auto grid max-w-7xl gap-8 px-4 py-10 sm:px-6 lg:grid-cols-[0.85fr_1.15fr] lg:px-8">
      <aside className="rounded-[2rem] bg-[#1E1B4B] p-7 text-white shadow-2xl shadow-indigo-950/20 lg:sticky lg:top-24 lg:h-fit">
        <p className="text-xs font-black uppercase tracking-[0.2em] text-rose-200">Create Profile</p>
        <h1 className="mt-3 text-3xl font-black sm:text-4xl">{WELCOME_TEXT}</h1>
        <p className="mt-4 text-sm leading-6 text-indigo-100">Register in four simple steps. Email OTP verification is required and every new profile needs admin approval before public visibility.</p>
        <div className="mt-6 space-y-3 text-sm text-indigo-50">
          <p>✓ Genuine profile details</p>
          <p>✓ Privacy controls from day one</p>
          <p>✓ Admin-reviewed public visibility</p>
          <p>✓ सुरक्षित और आसान matrimonial experience</p>
        </div>
        <p className="mt-8 text-sm text-indigo-100">Already registered? <Link className="font-black text-white underline" href="/login">Login here</Link></p>
      </aside>
      <section>
        <SectionHeading eyebrow="Registration" title="Build your matrimonial profile">
          Your phone and email are private by default. You can edit profile and partner preferences later.
        </SectionHeading>
        <RegisterWizard />
      </section>
    </div>
  );
}
