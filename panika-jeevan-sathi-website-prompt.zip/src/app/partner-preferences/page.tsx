import { PreferencesEditor } from "@/components/client-forms";
import { NoticeBar, SectionHeading } from "@/components/ui";
import { requireUser } from "@/lib/auth";
import { getOwnPreferences } from "@/lib/data";
import { searchParam } from "@/lib/utils";

export const dynamic = "force-dynamic";

type PreferencesPageProps = {
  searchParams: Promise<Record<string, string | string[] | undefined>>;
};

export default async function PartnerPreferencesPage({ searchParams }: PreferencesPageProps) {
  const params = await searchParams;
  const user = await requireUser();
  const preferences = await getOwnPreferences(user.id);

  return (
    <div className="mx-auto max-w-5xl px-4 py-8 sm:px-6 lg:px-8">
      <NoticeBar notice={searchParam(params, "notice")} error={searchParam(params, "error")} />
      <SectionHeading eyebrow="Partner Preferences" title="Tell us what matters to you">
        Recommendations use these preferences with normal database-based matching logic. You can update them anytime.
      </SectionHeading>
      <PreferencesEditor
        gender={user.gender}
        preferences={preferences ? {
          lookingFor: preferences.lookingFor,
          ageMin: preferences.ageMin,
          ageMax: preferences.ageMax,
          location: preferences.location,
          religion: preferences.religion,
          community: preferences.community,
          motherTongue: preferences.motherTongue,
          maritalStatus: preferences.maritalStatus,
          education: preferences.education,
          profession: preferences.profession,
          incomeMin: preferences.incomeMin,
          incomeMax: preferences.incomeMax,
          heightMinCm: preferences.heightMinCm,
          heightMaxCm: preferences.heightMaxCm,
          description: preferences.description,
        } : null}
      />
    </div>
  );
}
