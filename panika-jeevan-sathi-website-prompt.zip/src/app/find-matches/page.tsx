import Link from "next/link";
import { getCurrentUser } from "@/lib/auth";
import { getSearchResults } from "@/lib/data";
import { searchParam } from "@/lib/utils";
import { EmptyState, NoticeBar, ProfileCard, SectionHeading } from "@/components/ui";
import { genderOptions, maritalStatusOptions } from "@/lib/constants";

export const dynamic = "force-dynamic";

type FindMatchesPageProps = {
  searchParams: Promise<Record<string, string | string[] | undefined>>;
};

function value(params: Record<string, string | string[] | undefined>, key: string) {
  return searchParam(params, key);
}

export default async function FindMatchesPage({ searchParams }: FindMatchesPageProps) {
  const params = await searchParams;
  const user = await getCurrentUser().catch(() => null);
  const { results, page, hasNext } = await getSearchResults(params, user?.id).catch(() => ({
    results: [],
    page: 1,
    hasNext: false,
  }));
  const nextParams = new URLSearchParams();
  Object.entries(params).forEach(([key, val]) => {
    const first = Array.isArray(val) ? val[0] : val;
    if (first) nextParams.set(key, first);
  });
  nextParams.set("page", String(page + 1));

  return (
    <div className="mx-auto max-w-7xl px-4 py-8 sm:px-6 lg:px-8">
      <NoticeBar notice={value(params, "notice")} error={value(params, "error")} />
      <div className="grid gap-8 lg:grid-cols-[320px_1fr]">
        <aside className="lg:sticky lg:top-24 lg:h-fit">
          <form className="space-y-4 rounded-3xl bg-white p-5 shadow-xl shadow-slate-200/70" method="get">
            <h2 className="text-xl font-black text-[#1E1B4B]">Search Filters</h2>
            <label className="block text-sm font-bold text-slate-700">Looking For<select name="lookingFor" defaultValue={value(params, "lookingFor")} className="mt-2 w-full rounded-2xl border border-slate-200 px-4 py-3"><option value="">Any</option>{genderOptions.map((option) => <option key={option}>{option}</option>)}</select></label>
            <div className="grid grid-cols-2 gap-3"><label className="block text-sm font-bold text-slate-700">Age Min<input name="ageMin" defaultValue={value(params, "ageMin")} type="number" className="mt-2 w-full rounded-2xl border border-slate-200 px-4 py-3" /></label><label className="block text-sm font-bold text-slate-700">Age Max<input name="ageMax" defaultValue={value(params, "ageMax")} type="number" className="mt-2 w-full rounded-2xl border border-slate-200 px-4 py-3" /></label></div>
            <label className="block text-sm font-bold text-slate-700">Location<input name="location" defaultValue={value(params, "location")} className="mt-2 w-full rounded-2xl border border-slate-200 px-4 py-3" /></label>
            <label className="block text-sm font-bold text-slate-700">Religion<input name="religion" defaultValue={value(params, "religion")} className="mt-2 w-full rounded-2xl border border-slate-200 px-4 py-3" /></label>
            <label className="block text-sm font-bold text-slate-700">Community/Caste<input name="community" defaultValue={value(params, "community")} className="mt-2 w-full rounded-2xl border border-slate-200 px-4 py-3" /></label>
            <label className="block text-sm font-bold text-slate-700">Mother Tongue<input name="motherTongue" defaultValue={value(params, "motherTongue")} className="mt-2 w-full rounded-2xl border border-slate-200 px-4 py-3" /></label>
            <label className="block text-sm font-bold text-slate-700">Marital Status<select name="maritalStatus" defaultValue={value(params, "maritalStatus")} className="mt-2 w-full rounded-2xl border border-slate-200 px-4 py-3"><option value="">Any</option>{maritalStatusOptions.map((option) => <option key={option}>{option}</option>)}</select></label>
            <label className="block text-sm font-bold text-slate-700">Education<input name="education" defaultValue={value(params, "education")} className="mt-2 w-full rounded-2xl border border-slate-200 px-4 py-3" /></label>
            <label className="block text-sm font-bold text-slate-700">Profession<input name="profession" defaultValue={value(params, "profession")} className="mt-2 w-full rounded-2xl border border-slate-200 px-4 py-3" /></label>
            <div className="grid grid-cols-2 gap-3"><label className="block text-sm font-bold text-slate-700">Income Min<input name="incomeMin" defaultValue={value(params, "incomeMin")} type="number" className="mt-2 w-full rounded-2xl border border-slate-200 px-4 py-3" /></label><label className="block text-sm font-bold text-slate-700">Height Min<input name="heightMin" defaultValue={value(params, "heightMin")} type="number" className="mt-2 w-full rounded-2xl border border-slate-200 px-4 py-3" /></label></div>
            <label className="block text-sm font-bold text-slate-700">Sort By<select name="sort" defaultValue={value(params, "sort") || "recent"} className="mt-2 w-full rounded-2xl border border-slate-200 px-4 py-3"><option value="recent">Recently Joined</option><option value="relevant">Most Relevant</option><option value="location">Location</option><option value="age">Age</option></select></label>
            <button className="w-full rounded-full bg-[#F43F5E] px-5 py-3 font-black text-white shadow-lg shadow-rose-500/25">Apply Filters</button>
            <Link href="/find-matches" className="block rounded-full bg-slate-100 px-5 py-3 text-center text-sm font-black text-slate-700">Reset</Link>
          </form>
        </aside>

        <section>
          <SectionHeading eyebrow="Find Matches" title="Search matrimonial profiles">
            Use filters to discover admin-approved profiles. New registrations are hidden until review. {!user && <span className="font-bold text-[#F43F5E]"> Login to see members-only profiles.</span>}
          </SectionHeading>
          {results.length === 0 ? (
            <EmptyState title="No profiles found" body="Try changing filters or come back after more admin-approved profiles join." actionHref="/recommended-matches" actionLabel="View Recommendations" />
          ) : (
            <>
              <div className="grid gap-5 md:grid-cols-2 xl:grid-cols-3">
                {results.map((profile) => <ProfileCard key={profile.userId} profile={profile} viewerId={user?.id} />)}
              </div>
              <div className="mt-8 flex justify-center gap-3">
                {page > 1 && <Link href={`/find-matches?page=${page - 1}`} className="rounded-full bg-white px-5 py-3 text-sm font-black text-[#1E1B4B] shadow">Previous</Link>}
                {hasNext && <Link href={`/find-matches?${nextParams.toString()}`} className="rounded-full bg-[#1E1B4B] px-5 py-3 text-sm font-black text-white shadow">Next Page</Link>}
              </div>
            </>
          )}
        </section>
      </div>
    </div>
  );
}
