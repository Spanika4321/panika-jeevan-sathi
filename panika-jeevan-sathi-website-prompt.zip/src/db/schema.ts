import {
  boolean,
  date,
  index,
  integer,
  pgTable,
  serial,
  text,
  timestamp,
  uniqueIndex,
  varchar,
} from "drizzle-orm/pg-core";

const now = () => timestamp("created_at", { withTimezone: true }).defaultNow().notNull();
const updated = () => timestamp("updated_at", { withTimezone: true }).defaultNow().notNull();

export const users = pgTable(
  "users",
  {
    id: serial("id").primaryKey(),
    fullName: varchar("full_name", { length: 160 }).notNull(),
    gender: varchar("gender", { length: 24 }).notNull(),
    dateOfBirth: date("date_of_birth"),
    email: varchar("email", { length: 255 }).notNull(),
    mobile: varchar("mobile", { length: 32 }).notNull(),
    passwordHash: text("password_hash").notNull(),
    role: varchar("role", { length: 24 }).default("member").notNull(),
    status: varchar("status", { length: 32 }).default("email_pending").notNull(),
    emailVerified: boolean("email_verified").default(false).notNull(),
    mobileVerified: boolean("mobile_verified").default(false).notNull(),
    lastLoginAt: timestamp("last_login_at", { withTimezone: true }),
    createdAt: now(),
    updatedAt: updated(),
  },
  (table) => [
    uniqueIndex("users_email_unique_idx").on(table.email),
    uniqueIndex("users_mobile_unique_idx").on(table.mobile),
    index("users_status_idx").on(table.status),
    index("users_role_idx").on(table.role),
  ],
);

export const sessions = pgTable(
  "sessions",
  {
    id: serial("id").primaryKey(),
    userId: integer("user_id")
      .notNull()
      .references(() => users.id, { onDelete: "cascade" }),
    tokenHash: text("token_hash").notNull(),
    expiresAt: timestamp("expires_at", { withTimezone: true }).notNull(),
    lastSeenAt: timestamp("last_seen_at", { withTimezone: true }).defaultNow().notNull(),
    createdAt: now(),
  },
  (table) => [
    uniqueIndex("sessions_token_hash_unique_idx").on(table.tokenHash),
    index("sessions_user_idx").on(table.userId),
    index("sessions_expires_idx").on(table.expiresAt),
  ],
);

export const profiles = pgTable(
  "profiles",
  {
    id: serial("id").primaryKey(),
    userId: integer("user_id")
      .notNull()
      .references(() => users.id, { onDelete: "cascade" }),
    displayName: varchar("display_name", { length: 160 }).notNull(),
    profilePhotoUrl: text("profile_photo_url"),
    headline: varchar("headline", { length: 220 }),
    about: text("about"),
    familyDetails: text("family_details"),
    lifestyle: text("lifestyle"),
    religion: varchar("religion", { length: 100 }),
    community: varchar("community", { length: 120 }),
    motherTongue: varchar("mother_tongue", { length: 100 }),
    maritalStatus: varchar("marital_status", { length: 80 }),
    education: varchar("education", { length: 160 }),
    profession: varchar("profession", { length: 160 }),
    income: integer("income"),
    location: varchar("location", { length: 180 }),
    heightCm: integer("height_cm"),
    approvalStatus: varchar("approval_status", { length: 32 }).default("pending").notNull(),
    verificationStatus: varchar("verification_status", { length: 32 }).default("unverified").notNull(),
    visibility: varchar("visibility", { length: 32 }).default("members").notNull(),
    createdAt: now(),
    updatedAt: updated(),
  },
  (table) => [
    uniqueIndex("profiles_user_unique_idx").on(table.userId),
    index("profiles_approval_idx").on(table.approvalStatus),
    index("profiles_location_idx").on(table.location),
    index("profiles_religion_idx").on(table.religion),
    index("profiles_community_idx").on(table.community),
    index("profiles_profession_idx").on(table.profession),
    index("profiles_education_idx").on(table.education),
    index("profiles_marital_idx").on(table.maritalStatus),
  ],
);

export const partnerPreferences = pgTable(
  "partner_preferences",
  {
    id: serial("id").primaryKey(),
    userId: integer("user_id")
      .notNull()
      .references(() => users.id, { onDelete: "cascade" }),
    lookingFor: varchar("looking_for", { length: 24 }),
    ageMin: integer("age_min"),
    ageMax: integer("age_max"),
    location: varchar("location", { length: 180 }),
    religion: varchar("religion", { length: 100 }),
    community: varchar("community", { length: 120 }),
    motherTongue: varchar("mother_tongue", { length: 100 }),
    maritalStatus: varchar("marital_status", { length: 80 }),
    education: varchar("education", { length: 160 }),
    profession: varchar("profession", { length: 160 }),
    incomeMin: integer("income_min"),
    incomeMax: integer("income_max"),
    heightMinCm: integer("height_min_cm"),
    heightMaxCm: integer("height_max_cm"),
    description: text("description"),
    createdAt: now(),
    updatedAt: updated(),
  },
  (table) => [uniqueIndex("partner_preferences_user_unique_idx").on(table.userId)],
);

export const privacySettings = pgTable(
  "privacy_settings",
  {
    id: serial("id").primaryKey(),
    userId: integer("user_id")
      .notNull()
      .references(() => users.id, { onDelete: "cascade" }),
    hidePhone: boolean("hide_phone").default(true).notNull(),
    hideEmail: boolean("hide_email").default(true).notNull(),
    profileVisibility: varchar("profile_visibility", { length: 32 }).default("members").notNull(),
    allowMessagesFrom: varchar("allow_messages_from", { length: 32 }).default("accepted_matches").notNull(),
    createdAt: now(),
    updatedAt: updated(),
  },
  (table) => [uniqueIndex("privacy_settings_user_unique_idx").on(table.userId)],
);

export const photos = pgTable(
  "photos",
  {
    id: serial("id").primaryKey(),
    userId: integer("user_id")
      .notNull()
      .references(() => users.id, { onDelete: "cascade" }),
    url: text("url").notNull(),
    caption: varchar("caption", { length: 180 }),
    isPrimary: boolean("is_primary").default(false).notNull(),
    approvalStatus: varchar("approval_status", { length: 32 }).default("pending").notNull(),
    createdAt: now(),
  },
  (table) => [index("photos_user_idx").on(table.userId)],
);

export const emailOtps = pgTable(
  "email_otps",
  {
    id: serial("id").primaryKey(),
    userId: integer("user_id")
      .notNull()
      .references(() => users.id, { onDelete: "cascade" }),
    email: varchar("email", { length: 255 }).notNull(),
    codeHash: text("code_hash").notNull(),
    purpose: varchar("purpose", { length: 48 }).default("registration").notNull(),
    attempts: integer("attempts").default(0).notNull(),
    expiresAt: timestamp("expires_at", { withTimezone: true }).notNull(),
    consumedAt: timestamp("consumed_at", { withTimezone: true }),
    createdAt: now(),
  },
  (table) => [
    index("email_otps_user_idx").on(table.userId),
    index("email_otps_email_idx").on(table.email),
  ],
);

export const passwordResetTokens = pgTable(
  "password_reset_tokens",
  {
    id: serial("id").primaryKey(),
    userId: integer("user_id")
      .notNull()
      .references(() => users.id, { onDelete: "cascade" }),
    tokenHash: text("token_hash").notNull(),
    expiresAt: timestamp("expires_at", { withTimezone: true }).notNull(),
    consumedAt: timestamp("consumed_at", { withTimezone: true }),
    createdAt: now(),
  },
  (table) => [
    uniqueIndex("password_reset_token_unique_idx").on(table.tokenHash),
    index("password_reset_user_idx").on(table.userId),
  ],
);

export const interests = pgTable(
  "interests",
  {
    id: serial("id").primaryKey(),
    senderId: integer("sender_id")
      .notNull()
      .references(() => users.id, { onDelete: "cascade" }),
    receiverId: integer("receiver_id")
      .notNull()
      .references(() => users.id, { onDelete: "cascade" }),
    status: varchar("status", { length: 32 }).default("pending").notNull(),
    message: text("message"),
    createdAt: now(),
    updatedAt: updated(),
  },
  (table) => [
    uniqueIndex("interests_sender_receiver_unique_idx").on(table.senderId, table.receiverId),
    index("interests_sender_idx").on(table.senderId),
    index("interests_receiver_idx").on(table.receiverId),
    index("interests_status_idx").on(table.status),
  ],
);

export const matches = pgTable(
  "matches",
  {
    id: serial("id").primaryKey(),
    userOneId: integer("user_one_id")
      .notNull()
      .references(() => users.id, { onDelete: "cascade" }),
    userTwoId: integer("user_two_id")
      .notNull()
      .references(() => users.id, { onDelete: "cascade" }),
    interestId: integer("interest_id").references(() => interests.id, { onDelete: "set null" }),
    score: integer("score").default(0).notNull(),
    status: varchar("status", { length: 32 }).default("active").notNull(),
    createdAt: now(),
  },
  (table) => [
    uniqueIndex("matches_pair_unique_idx").on(table.userOneId, table.userTwoId),
    index("matches_user_one_idx").on(table.userOneId),
    index("matches_user_two_idx").on(table.userTwoId),
  ],
);

export const shortlists = pgTable(
  "shortlists",
  {
    id: serial("id").primaryKey(),
    userId: integer("user_id")
      .notNull()
      .references(() => users.id, { onDelete: "cascade" }),
    shortlistedUserId: integer("shortlisted_user_id")
      .notNull()
      .references(() => users.id, { onDelete: "cascade" }),
    createdAt: now(),
  },
  (table) => [
    uniqueIndex("shortlists_unique_idx").on(table.userId, table.shortlistedUserId),
    index("shortlists_user_idx").on(table.userId),
  ],
);

export const profileLikes = pgTable(
  "profile_likes",
  {
    id: serial("id").primaryKey(),
    userId: integer("user_id")
      .notNull()
      .references(() => users.id, { onDelete: "cascade" }),
    likedUserId: integer("liked_user_id")
      .notNull()
      .references(() => users.id, { onDelete: "cascade" }),
    createdAt: now(),
  },
  (table) => [uniqueIndex("profile_likes_unique_idx").on(table.userId, table.likedUserId)],
);

export const blocks = pgTable(
  "blocks",
  {
    id: serial("id").primaryKey(),
    blockerId: integer("blocker_id")
      .notNull()
      .references(() => users.id, { onDelete: "cascade" }),
    blockedUserId: integer("blocked_user_id")
      .notNull()
      .references(() => users.id, { onDelete: "cascade" }),
    reason: text("reason"),
    createdAt: now(),
  },
  (table) => [
    uniqueIndex("blocks_unique_idx").on(table.blockerId, table.blockedUserId),
    index("blocks_blocker_idx").on(table.blockerId),
    index("blocks_blocked_idx").on(table.blockedUserId),
  ],
);

export const conversations = pgTable(
  "conversations",
  {
    id: serial("id").primaryKey(),
    status: varchar("status", { length: 32 }).default("active").notNull(),
    createdAt: now(),
    updatedAt: updated(),
  },
  (table) => [index("conversations_status_idx").on(table.status)],
);

export const conversationParticipants = pgTable(
  "conversation_participants",
  {
    id: serial("id").primaryKey(),
    conversationId: integer("conversation_id")
      .notNull()
      .references(() => conversations.id, { onDelete: "cascade" }),
    userId: integer("user_id")
      .notNull()
      .references(() => users.id, { onDelete: "cascade" }),
    deletedAt: timestamp("deleted_at", { withTimezone: true }),
    createdAt: now(),
  },
  (table) => [
    uniqueIndex("conversation_participants_unique_idx").on(table.conversationId, table.userId),
    index("conversation_participants_user_idx").on(table.userId),
  ],
);

export const messages = pgTable(
  "messages",
  {
    id: serial("id").primaryKey(),
    conversationId: integer("conversation_id")
      .notNull()
      .references(() => conversations.id, { onDelete: "cascade" }),
    senderId: integer("sender_id")
      .notNull()
      .references(() => users.id, { onDelete: "cascade" }),
    receiverId: integer("receiver_id")
      .notNull()
      .references(() => users.id, { onDelete: "cascade" }),
    content: text("content").notNull(),
    readAt: timestamp("read_at", { withTimezone: true }),
    createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
  },
  (table) => [
    index("messages_conversation_idx").on(table.conversationId),
    index("messages_receiver_read_idx").on(table.receiverId, table.readAt),
  ],
);

export const notifications = pgTable(
  "notifications",
  {
    id: serial("id").primaryKey(),
    userId: integer("user_id")
      .notNull()
      .references(() => users.id, { onDelete: "cascade" }),
    actorId: integer("actor_id").references(() => users.id, { onDelete: "set null" }),
    type: varchar("type", { length: 64 }).notNull(),
    title: varchar("title", { length: 180 }).notNull(),
    body: text("body"),
    linkUrl: text("link_url"),
    readAt: timestamp("read_at", { withTimezone: true }),
    createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
  },
  (table) => [
    index("notifications_user_idx").on(table.userId),
    index("notifications_read_idx").on(table.readAt),
  ],
);

export const posts = pgTable(
  "posts",
  {
    id: serial("id").primaryKey(),
    authorId: integer("author_id")
      .notNull()
      .references(() => users.id, { onDelete: "cascade" }),
    content: text("content").notNull(),
    photoUrl: text("photo_url"),
    status: varchar("status", { length: 32 }).default("active").notNull(),
    createdAt: now(),
    updatedAt: updated(),
  },
  (table) => [
    index("posts_author_idx").on(table.authorId),
    index("posts_status_idx").on(table.status),
  ],
);

export const comments = pgTable(
  "comments",
  {
    id: serial("id").primaryKey(),
    postId: integer("post_id")
      .notNull()
      .references(() => posts.id, { onDelete: "cascade" }),
    authorId: integer("author_id")
      .notNull()
      .references(() => users.id, { onDelete: "cascade" }),
    content: text("content").notNull(),
    createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
  },
  (table) => [
    index("comments_post_idx").on(table.postId),
    index("comments_author_idx").on(table.authorId),
  ],
);

export const postLikes = pgTable(
  "post_likes",
  {
    id: serial("id").primaryKey(),
    postId: integer("post_id")
      .notNull()
      .references(() => posts.id, { onDelete: "cascade" }),
    userId: integer("user_id")
      .notNull()
      .references(() => users.id, { onDelete: "cascade" }),
    createdAt: now(),
  },
  (table) => [uniqueIndex("post_likes_unique_idx").on(table.postId, table.userId)],
);

export const reports = pgTable(
  "reports",
  {
    id: serial("id").primaryKey(),
    reporterId: integer("reporter_id").references(() => users.id, { onDelete: "set null" }),
    reportedUserId: integer("reported_user_id").references(() => users.id, { onDelete: "cascade" }),
    postId: integer("post_id").references(() => posts.id, { onDelete: "cascade" }),
    reason: varchar("reason", { length: 160 }).notNull(),
    details: text("details"),
    status: varchar("status", { length: 32 }).default("pending").notNull(),
    adminNote: text("admin_note"),
    createdAt: now(),
    updatedAt: updated(),
  },
  (table) => [
    index("reports_status_idx").on(table.status),
    index("reports_reported_user_idx").on(table.reportedUserId),
    index("reports_post_idx").on(table.postId),
  ],
);

export const verificationRequests = pgTable(
  "verification_requests",
  {
    id: serial("id").primaryKey(),
    userId: integer("user_id")
      .notNull()
      .references(() => users.id, { onDelete: "cascade" }),
    status: varchar("status", { length: 32 }).default("pending").notNull(),
    note: text("note"),
    reviewedByUserId: integer("reviewed_by_user_id").references(() => users.id, { onDelete: "set null" }),
    reviewedAt: timestamp("reviewed_at", { withTimezone: true }),
    createdAt: now(),
    updatedAt: updated(),
  },
  (table) => [
    index("verification_requests_user_idx").on(table.userId),
    index("verification_requests_status_idx").on(table.status),
  ],
);

export const adminUsers = pgTable(
  "admin_users",
  {
    id: serial("id").primaryKey(),
    userId: integer("user_id")
      .notNull()
      .references(() => users.id, { onDelete: "cascade" }),
    name: varchar("name", { length: 160 }).notNull(),
    email: varchar("email", { length: 255 }).notNull(),
    role: varchar("role", { length: 40 }).default("owner").notNull(),
    isActive: boolean("is_active").default(true).notNull(),
    createdAt: now(),
  },
  (table) => [
    uniqueIndex("admin_users_user_unique_idx").on(table.userId),
    uniqueIndex("admin_users_email_unique_idx").on(table.email),
  ],
);

export const announcements = pgTable(
  "announcements",
  {
    id: serial("id").primaryKey(),
    adminUserId: integer("admin_user_id").references(() => adminUsers.id, { onDelete: "set null" }),
    title: varchar("title", { length: 180 }).notNull(),
    body: text("body").notNull(),
    audience: varchar("audience", { length: 40 }).default("all").notNull(),
    createdAt: now(),
  },
  (table) => [index("announcements_created_idx").on(table.createdAt)],
);

export type User = typeof users.$inferSelect;
export type NewUser = typeof users.$inferInsert;
export type Profile = typeof profiles.$inferSelect;
export type PartnerPreference = typeof partnerPreferences.$inferSelect;
