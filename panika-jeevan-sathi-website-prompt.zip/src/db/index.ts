import { drizzle } from "drizzle-orm/node-postgres";
import { Pool, PoolConfig } from "pg";
import * as schema from "./schema";

function buildConnectionString(): string {
  if (process.env.DATABASE_URL) return process.env.DATABASE_URL;
  if (process.env.POSTGRES_URL) return process.env.POSTGRES_URL;

  const user = process.env.PGUSER || process.env.DB_USER;
  const password = process.env.PGPASSWORD || process.env.DB_PASSWORD;
  const host = process.env.PGHOST || process.env.DB_HOST || "127.0.0.1";
  const port = process.env.PGPORT || process.env.DB_PORT || "5432";
  const database = process.env.PGDATABASE || process.env.DB_NAME;

  if (user && database) {
    const auth = password ? `${encodeURIComponent(user)}:${encodeURIComponent(password)}@` : `${encodeURIComponent(user)}@`;
    return `postgresql://${auth}${host}:${port}/${database}`;
  }

  throw new Error(
    "DATABASE_URL is required. Set DATABASE_URL (or PGUSER/PGPASSWORD/PGHOST/PGPORT/PGDATABASE) as environment variables before starting the application.",
  );
}

const connectionString = buildConnectionString();

const isSslRequired =
  connectionString.includes("sslmode=require") ||
  connectionString.includes("ssl=true") ||
  process.env.DATABASE_SSL === "true" ||
  process.env.PGSSLMODE === "require";

const poolConfig: PoolConfig = {
  connectionString,
  max: parseInt(process.env.DB_POOL_MAX || "10", 10),
  idleTimeoutMillis: parseInt(process.env.DB_IDLE_TIMEOUT || "30000", 10),
  connectionTimeoutMillis: parseInt(process.env.DB_CONN_TIMEOUT || "5000", 10),
};

if (isSslRequired) {
  poolConfig.ssl = { rejectUnauthorized: false };
}

const globalForDb = globalThis as typeof globalThis & {
  __panikaJeevanSathiPool?: Pool;
};

export const pool =
  globalForDb.__panikaJeevanSathiPool ??
  new Pool(poolConfig);

// Handle idle connection errors gracefully so Passenger/cPanel does not crash
pool.on("error", (err) => {
  console.error("[Database Pool] Unexpected error on idle client:", err);
});

if (process.env.NODE_ENV !== "production") {
  globalForDb.__panikaJeevanSathiPool = pool;
}

export const db = drizzle(pool, { schema });
