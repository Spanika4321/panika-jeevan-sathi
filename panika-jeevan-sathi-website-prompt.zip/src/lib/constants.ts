export const APP_NAME = "PANIKA JEEVAN SATHI";
export const WELCOME_TEXT = "WELLCOME TO PANIKA JEEVAN SATHI";
export const TAGLINE = "Find a Life Partner. Build a Beautiful Future.";

export const BRAND = {
  navy: "#1E1B4B",
  rose: "#F43F5E",
};

export const SITE_URL =
  process.env.NEXT_PUBLIC_SITE_URL ||
  process.env.SITE_URL ||
  "https://panikajeevansathi.coolstore.in";

export const ADMIN_NAME = "Panika Sukul";
export const ADMIN_EMAIL = "sukulpanika939@gmail.com";
export const CONTACT_EMAIL = "sukulpanika939@gmail.com";
export const CONTACT_WHATSAPP = "8099834725";

export const navLinks = [
  { href: "/", label: "Home", icon: "⌂" },
  { href: "/find-matches", label: "Find Matches", icon: "♡" },
  { href: "/messages", label: "Messages", icon: "✉" },
  { href: "/notifications", label: "Notifications", icon: "🔔" },
  { href: "/profile", label: "Profile", icon: "👤" },
] as const;

export const featureCards = [
  ["Genuine Profiles", "Admin-reviewed profile visibility with verification badges for trusted profiles.", "✅"],
  ["Easy Match Search", "Filter by age, location, religion, community, education, profession and more.", "🔎"],
  ["Secure Messaging", "Private chat opens only after accepted matrimonial interest.", "🔐"],
  ["Detailed Profiles", "Understand education, career, family, lifestyle and partner preferences clearly.", "📋"],
  ["Mobile Friendly", "Fast, touch-friendly screens for Android phones, tablets, laptops and desktops.", "📱"],
  ["Privacy Focused", "Hide phone/email, control profile visibility, block and report unsafe users.", "🛡️"],
] as const;

export const safetyEnglish = [
  "Never send money to anyone you meet online.",
  "Always verify a person's identity before making important decisions.",
  "Meet families in safe public or family environments before commitment.",
  "Report suspicious behavior, pressure, fraud or harassment immediately.",
];

export const safetyHindi = [
  "ऑनलाइन मिले किसी भी व्यक्ति को कभी पैसे न भेजें।",
  "महत्वपूर्ण निर्णय लेने से पहले व्यक्ति की पहचान अवश्य सत्यापित करें।",
  "रिश्ता आगे बढ़ाने से पहले परिवार या सुरक्षित सार्वजनिक स्थान पर मिलें।",
  "संदिग्ध व्यवहार, दबाव, धोखाधड़ी या परेशानी को तुरंत रिपोर्ट करें।",
];

export const genderOptions = ["Female", "Male", "Other"];
export const maritalStatusOptions = ["Never Married", "Divorced", "Widowed", "Separated"];
export const visibilityOptions = ["members", "public", "private"];
