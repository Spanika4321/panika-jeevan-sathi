import nodemailer from "nodemailer";
import { APP_NAME, CONTACT_EMAIL } from "./constants";

async function sendViaSmtp(to: string, subject: string, html: string, text: string) {
  const host = process.env.SMTP_HOST;
  const port = parseInt(process.env.SMTP_PORT || "465", 10);
  const user = process.env.SMTP_USER;
  const pass = process.env.SMTP_PASS || process.env.SMTP_PASSWORD;
  const from = process.env.SMTP_FROM || process.env.EMAIL_FROM || `"${APP_NAME}" <${user || CONTACT_EMAIL}>`;

  if (!host || !user || !pass) return false;

  try {
    const transporter = nodemailer.createTransport({
      host,
      port,
      secure: port === 465 || process.env.SMTP_SECURE === "true",
      auth: { user, pass },
      tls: {
        rejectUnauthorized: process.env.SMTP_REJECT_UNAUTHORIZED !== "false",
      },
    });

    await transporter.sendMail({
      from,
      to,
      subject,
      text,
      html,
    });
    return true;
  } catch (error) {
    console.error(`[${APP_NAME}] SMTP send failed:`, error);
    return false;
  }
}

async function sendViaResend(to: string, subject: string, html: string) {
  const apiKey = process.env.RESEND_API_KEY;
  if (!apiKey) return false;

  try {
    const response = await fetch("https://api.resend.com/emails", {
      method: "POST",
      headers: {
        Authorization: `Bearer ${apiKey}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        from: process.env.EMAIL_FROM || `${APP_NAME} <onboarding@resend.dev>`,
        to,
        subject,
        html,
      }),
    });
    return response.ok;
  } catch {
    return false;
  }
}

async function sendViaWebhook(to: string, subject: string, html: string, text: string) {
  const webhookUrl = process.env.EMAIL_WEBHOOK_URL;
  if (!webhookUrl) return false;

  try {
    const response = await fetch(webhookUrl, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ to, subject, html, text, from: process.env.EMAIL_FROM || CONTACT_EMAIL }),
    });
    return response.ok;
  } catch {
    return false;
  }
}

export async function sendOtpEmail(to: string, otp: string) {
  const subject = `${APP_NAME} email verification OTP`;
  const text = `Your ${APP_NAME} verification OTP is ${otp}. It expires in 15 minutes. Never share this OTP with anyone.`;
  const html = `
    <div style="font-family:Arial,sans-serif;background:#f8fafc;padding:24px;color:#0f172a">
      <div style="max-width:560px;margin:auto;background:#ffffff;border-radius:20px;padding:28px;border:1px solid #e2e8f0">
        <h1 style="color:#1E1B4B;margin:0 0 8px">${APP_NAME}</h1>
        <p style="font-size:16px;margin:0 0 18px">Email verification OTP / ईमेल सत्यापन OTP</p>
        <div style="font-size:32px;letter-spacing:8px;font-weight:700;color:#F43F5E;padding:18px;border-radius:16px;background:#fff1f2;text-align:center">${otp}</div>
        <p style="line-height:1.6">This OTP expires in 15 minutes. Never share it with anyone.<br/>यह OTP 15 मिनट में समाप्त हो जाएगा। इसे किसी के साथ साझा न करें।</p>
      </div>
    </div>`;

  const delivered =
    (await sendViaSmtp(to, subject, html, text)) ||
    (await sendViaResend(to, subject, html)) ||
    (await sendViaWebhook(to, subject, html, text));

  if (!delivered) {
    console.info(`[${APP_NAME}] OTP generated for ${to}: ${otp}`);
  }

  return { delivered };
}

export async function sendPasswordResetEmail(to: string, resetLink: string) {
  const subject = `${APP_NAME} password reset`;
  const text = `Reset your ${APP_NAME} password here: ${resetLink}. This link expires in 30 minutes.`;
  const html = `
    <div style="font-family:Arial,sans-serif;background:#f8fafc;padding:24px;color:#0f172a">
      <div style="max-width:560px;margin:auto;background:#ffffff;border-radius:20px;padding:28px;border:1px solid #e2e8f0">
        <h1 style="color:#1E1B4B;margin:0 0 8px">${APP_NAME}</h1>
        <p>Use the secure button below to reset your password.</p>
        <a href="${resetLink}" style="display:inline-block;background:#F43F5E;color:white;text-decoration:none;padding:12px 18px;border-radius:999px;font-weight:700">Reset Password</a>
        <p style="line-height:1.6">This link expires in 30 minutes. If you did not request it, ignore this email.</p>
      </div>
    </div>`;

  const delivered =
    (await sendViaSmtp(to, subject, html, text)) ||
    (await sendViaResend(to, subject, html)) ||
    (await sendViaWebhook(to, subject, html, text));

  if (!delivered) {
    console.info(`[${APP_NAME}] Password reset link for ${to}: ${resetLink}`);
  }

  return { delivered };
}
