"use client";

import Link from "next/link";
import { useState, type ReactNode } from "react";
import { APP_NAME, CONTACT_EMAIL, CONTACT_WHATSAPP, TAGLINE } from "@/lib/constants";
import type { SessionUser } from "@/lib/data-types";
import { Logo } from "./logo";

type SiteChromeProps = {
  children: ReactNode;
  user: SessionUser | null;
  unreadCount: number;
};

export function SiteChrome({ children, user, unreadCount }: SiteChromeProps) {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  return (
    <div className="min-h-screen bg-[#f8fafc] text-slate-900">
      <header className="sticky top-0 z-40 border-b border-slate-200/80 bg-white/95 backdrop-blur-xl">
        <nav className="mx-auto flex max-w-7xl items-center justify-between gap-3 px-4 py-3 sm:px-6 lg:px-8">
          <Logo />

          <div className="hidden items-center gap-1 xl:flex">
            <Link href="/" className="rounded-full px-3.5 py-2 text-sm font-bold text-slate-700 transition hover:bg-rose-50 hover:text-[#F43F5E]">Home</Link>
            <Link href="/find-matches" className="rounded-full px-3.5 py-2 text-sm font-bold text-slate-700 transition hover:bg-rose-50 hover:text-[#F43F5E]">Matches</Link>
            <Link href="/recommended-matches" className="rounded-full px-3.5 py-2 text-sm font-bold text-slate-700 transition hover:bg-rose-50 hover:text-[#F43F5E]">Recommended</Link>
            <Link href="/feed" className="rounded-full px-3.5 py-2 text-sm font-bold text-slate-700 transition hover:bg-rose-50 hover:text-[#F43F5E]">Feed</Link>
            {user && (
              <>
                <Link href="/interests" className="rounded-full px-3.5 py-2 text-sm font-bold text-slate-700 transition hover:bg-rose-50 hover:text-[#F43F5E]">Interests</Link>
                <Link href="/messages" className="rounded-full px-3.5 py-2 text-sm font-bold text-slate-700 transition hover:bg-rose-50 hover:text-[#F43F5E]">Messages</Link>
                <Link href="/notifications" className="relative rounded-full px-3.5 py-2 text-sm font-bold text-slate-700 transition hover:bg-rose-50 hover:text-[#F43F5E]">
                  Notifications
                  {unreadCount > 0 && (
                    <span className="ml-1.5 inline-flex h-5 min-w-5 items-center justify-center rounded-full bg-[#F43F5E] px-1.5 text-[10px] font-black text-white">
                      {unreadCount}
                    </span>
                  )}
                </Link>
                <Link href="/shortlist" className="rounded-full px-3.5 py-2 text-sm font-bold text-slate-700 transition hover:bg-rose-50 hover:text-[#F43F5E]">Shortlist</Link>
              </>
            )}
          </div>

          <div className="hidden items-center gap-2 lg:flex">
            {user ? (
              <>
                {user.role === "admin" && (
                  <Link href="/admin" className="rounded-full bg-indigo-900 px-3.5 py-1.5 text-xs font-black text-white shadow-sm hover:bg-indigo-950">
                    Admin
                  </Link>
                )}
                <Link href="/profile" className="flex items-center gap-2 rounded-full bg-slate-100 px-3 py-1.5 text-xs font-bold text-slate-800 hover:bg-slate-200">
                  <span className="grid h-6 w-6 place-items-center rounded-full bg-[#1E1B4B] text-[10px] font-black text-white">
                    {user.fullName.slice(0, 2).toUpperCase()}
                  </span>
                  <span className="max-w-[100px] truncate">{user.fullName.split(" ")[0]}</span>
                </Link>
                <Link href="/settings" className="rounded-full p-2 text-slate-500 hover:bg-slate-100 hover:text-slate-900" title="Settings">
                  ⚙️
                </Link>
                <form action="/api/actions" method="post">
                  <input type="hidden" name="action" value="logout" />
                  <button className="rounded-full bg-slate-100 px-3.5 py-1.5 text-xs font-black text-slate-700 hover:bg-red-50 hover:text-red-700">
                    Logout
                  </button>
                </form>
              </>
            ) : (
              <>
                <Link href="/login" className="rounded-full px-4 py-2 text-sm font-bold text-[#1E1B4B] hover:bg-slate-100">
                  Login
                </Link>
                <Link href="/register" className="rounded-full bg-[#F43F5E] px-5 py-2 text-sm font-bold text-white shadow-lg shadow-rose-500/25 transition hover:bg-rose-600">
                  Register
                </Link>
              </>
            )}
          </div>

          <div className="flex items-center gap-2 lg:hidden">
            {user && (
              <Link href="/notifications" className="relative p-2 text-lg">
                🔔
                {unreadCount > 0 && (
                  <span className="absolute right-1 top-1 grid h-4 w-4 place-items-center rounded-full bg-[#F43F5E] text-[9px] font-black text-white">
                    {unreadCount}
                  </span>
                )}
              </Link>
            )}
            <button
              type="button"
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="rounded-2xl border border-slate-200 bg-slate-50 p-2 text-lg text-slate-800"
              aria-label="Toggle mobile menu"
            >
              {mobileMenuOpen ? "✕" : "☰"}
            </button>
          </div>
        </nav>

        {mobileMenuOpen && (
          <div className="border-b border-slate-200 bg-white px-4 py-5 shadow-2xl lg:hidden">
            {user ? (
              <div className="mb-4 flex items-center justify-between border-b border-slate-100 pb-4">
                <div>
                  <p className="font-black text-[#1E1B4B]">{user.fullName}</p>
                  <p className="text-xs text-slate-500">{user.email}</p>
                </div>
                {user.role === "admin" && (
                  <Link href="/admin" onClick={() => setMobileMenuOpen(false)} className="rounded-full bg-indigo-900 px-3 py-1 text-xs font-black text-white">
                    Admin Panel
                  </Link>
                )}
              </div>
            ) : (
              <div className="mb-4 flex gap-2 border-b border-slate-100 pb-4">
                <Link href="/login" onClick={() => setMobileMenuOpen(false)} className="flex-1 rounded-full bg-slate-100 py-2.5 text-center text-xs font-black text-slate-800">
                  Login
                </Link>
                <Link href="/register" onClick={() => setMobileMenuOpen(false)} className="flex-1 rounded-full bg-[#F43F5E] py-2.5 text-center text-xs font-black text-white">
                  Register
                </Link>
              </div>
            )}

            <div className="grid grid-cols-2 gap-2 text-sm font-bold text-slate-700">
              <Link href="/" onClick={() => setMobileMenuOpen(false)} className="rounded-2xl bg-slate-50 p-3 hover:bg-rose-50">⌂ Home</Link>
              <Link href="/find-matches" onClick={() => setMobileMenuOpen(false)} className="rounded-2xl bg-slate-50 p-3 hover:bg-rose-50">♡ Matches</Link>
              <Link href="/recommended-matches" onClick={() => setMobileMenuOpen(false)} className="rounded-2xl bg-slate-50 p-3 hover:bg-rose-50">⭐ Recommended</Link>
              <Link href="/feed" onClick={() => setMobileMenuOpen(false)} className="rounded-2xl bg-slate-50 p-3 hover:bg-rose-50">📰 Community Feed</Link>
              {user && (
                <>
                  <Link href="/interests" onClick={() => setMobileMenuOpen(false)} className="rounded-2xl bg-slate-50 p-3 hover:bg-rose-50">💌 Interests</Link>
                  <Link href="/messages" onClick={() => setMobileMenuOpen(false)} className="rounded-2xl bg-slate-50 p-3 hover:bg-rose-50">✉ Messages</Link>
                  <Link href="/notifications" onClick={() => setMobileMenuOpen(false)} className="rounded-2xl bg-slate-50 p-3 hover:bg-rose-50">
                    🔔 Notifications {unreadCount > 0 && `(${unreadCount})`}
                  </Link>
                  <Link href="/shortlist" onClick={() => setMobileMenuOpen(false)} className="rounded-2xl bg-slate-50 p-3 hover:bg-rose-50">🔖 Shortlist</Link>
                  <Link href="/profile" onClick={() => setMobileMenuOpen(false)} className="rounded-2xl bg-slate-50 p-3 hover:bg-rose-50">👤 My Profile</Link>
                  <Link href="/partner-preferences" onClick={() => setMobileMenuOpen(false)} className="rounded-2xl bg-slate-50 p-3 hover:bg-rose-50">⚙️ Preferences</Link>
                  <Link href="/settings" onClick={() => setMobileMenuOpen(false)} className="rounded-2xl bg-slate-50 p-3 hover:bg-rose-50">🛡️ Settings & Privacy</Link>
                </>
              )}
              <Link href="/safety-guidelines" onClick={() => setMobileMenuOpen(false)} className="rounded-2xl bg-slate-50 p-3 hover:bg-rose-50">⚠️ Safety Guide</Link>
              <Link href="/help" onClick={() => setMobileMenuOpen(false)} className="rounded-2xl bg-slate-50 p-3 hover:bg-rose-50">❓ Help Center</Link>
              <Link href="/about" onClick={() => setMobileMenuOpen(false)} className="rounded-2xl bg-slate-50 p-3 hover:bg-rose-50">ℹ️ About Us</Link>
            </div>

            {user && (
              <form action="/api/actions" method="post" className="mt-4">
                <input type="hidden" name="action" value="logout" />
                <button className="w-full rounded-full bg-red-50 py-2.5 text-xs font-black text-red-700">
                  Logout of Account
                </button>
              </form>
            )}
          </div>
        )}
      </header>

      <main className="pb-24 lg:pb-0">{children}</main>

      <footer className="border-t border-slate-200 bg-white">
        <div className="mx-auto grid max-w-7xl gap-8 px-4 py-10 sm:px-6 md:grid-cols-[1.4fr_1fr_1fr] lg:px-8">
          <div>
            <Logo />
            <p className="mt-4 max-w-md text-sm leading-6 text-slate-600">Helping people find meaningful relationships and life partners.</p>
            <p className="mt-2 text-sm font-semibold text-[#1E1B4B]">{TAGLINE}</p>
          </div>
          <div>
            <h3 className="text-sm font-black uppercase tracking-[0.18em] text-slate-500">Links</h3>
            <div className="mt-4 grid gap-2 text-sm text-slate-600">
              <Link href="/about" className="hover:text-[#F43F5E]">About Us</Link>
              <Link href="/contact" className="hover:text-[#F43F5E]">Contact Us</Link>
              <Link href="/privacy-policy" className="hover:text-[#F43F5E]">Privacy Policy</Link>
              <Link href="/terms" className="hover:text-[#F43F5E]">Terms & Conditions</Link>
              <Link href="/safety-guidelines" className="hover:text-[#F43F5E]">Safety Guidelines</Link>
              <Link href="/help" className="hover:text-[#F43F5E]">Help Center</Link>
            </div>
          </div>
          <div>
            <h3 className="text-sm font-black uppercase tracking-[0.18em] text-slate-500">Contact</h3>
            <div className="mt-4 space-y-2 text-sm text-slate-600">
              <p>Email: <a className="font-semibold text-[#1E1B4B]" href={`mailto:${CONTACT_EMAIL}`}>{CONTACT_EMAIL}</a></p>
              <p>WhatsApp: <a className="font-semibold text-[#1E1B4B]" href={`https://wa.me/91${CONTACT_WHATSAPP}`}>{CONTACT_WHATSAPP}</a></p>
              <p className="text-xs text-slate-500">Dedicated Matrimonial Support & Inquiries</p>
            </div>
          </div>
        </div>
        <div className="border-t border-slate-100 px-4 py-5 text-center text-xs font-semibold text-slate-500">© {APP_NAME}. All Rights Reserved.</div>
      </footer>

      <nav className="fixed inset-x-0 bottom-0 z-50 border-t border-slate-200 bg-white/95 px-2 py-2 shadow-[0_-16px_40px_rgba(15,23,42,0.08)] backdrop-blur-xl lg:hidden">
        <div className="mx-auto grid max-w-md grid-cols-5 gap-1">
          <Link href="/" className="flex flex-col items-center gap-1 rounded-2xl px-2 py-2 text-[11px] font-bold text-slate-600 hover:bg-rose-50 hover:text-[#F43F5E]">
            <span className="text-base leading-none">⌂</span>
            <span className="truncate">Home</span>
          </Link>
          <Link href="/find-matches" className="flex flex-col items-center gap-1 rounded-2xl px-2 py-2 text-[11px] font-bold text-slate-600 hover:bg-rose-50 hover:text-[#F43F5E]">
            <span className="text-base leading-none">♡</span>
            <span className="truncate">Matches</span>
          </Link>
          <Link href="/feed" className="flex flex-col items-center gap-1 rounded-2xl px-2 py-2 text-[11px] font-bold text-slate-600 hover:bg-rose-50 hover:text-[#F43F5E]">
            <span className="text-base leading-none">📰</span>
            <span className="truncate">Feed</span>
          </Link>
          <Link href={user ? "/messages" : "/login"} className="flex flex-col items-center gap-1 rounded-2xl px-2 py-2 text-[11px] font-bold text-slate-600 hover:bg-rose-50 hover:text-[#F43F5E]">
            <span className="text-base leading-none">✉</span>
            <span className="truncate">Chat</span>
          </Link>
          <Link href={user ? "/profile" : "/login"} className="flex flex-col items-center gap-1 rounded-2xl px-2 py-2 text-[11px] font-bold text-slate-600 hover:bg-rose-50 hover:text-[#F43F5E]">
            <span className="text-base leading-none">👤</span>
            <span className="truncate">{user ? "Profile" : "Login"}</span>
          </Link>
        </div>
      </nav>
    </div>
  );
}
