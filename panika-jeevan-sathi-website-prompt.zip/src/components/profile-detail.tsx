import Link from "next/link";
import { getProfileDetails } from "@/lib/data";
import { formatDate, moneyLabel } from "@/lib/utils";
import { Avatar, FieldValue, SafetyBanner, StatusPill } from "./ui";

type ProfileDetailData = NonNullable<Awaited<ReturnType<typeof getProfileDetails>>>;

export function ProfileDetail({ profile, viewerId }: { profile: ProfileDetailData; viewerId?: number | null }) {
  const mini = {
    userId: profile.userId,
    fullName: profile.fullName,
    age: profile.age,
    location: profile.location,
    profession: profile.profession,
    education: profile.education,
    profilePhotoUrl: profile.profilePhotoUrl,
    verificationStatus: profile.verificationStatus,
  };
  const isSelf = viewerId === profile.userId;
  const sent = profile.sentInterest;
  const received = profile.receivedInterest;

  return (
    <div className="grid gap-6 lg:grid-cols-[0.9fr_1.35fr]">
      <aside className="space-y-5 lg:sticky lg:top-24 lg:h-fit">
        <section className="rounded-[2rem] bg-white p-6 text-center shadow-xl shadow-slate-200/70">
          <div className="flex justify-center"><Avatar profile={mini} size="xl" /></div>
          <h1 className="mt-5 text-3xl font-black text-[#1E1B4B]">{profile.fullName}</h1>
          <p className="mt-2 text-sm font-semibold text-slate-600">{[profile.age ? `${profile.age} yrs` : null, profile.location, profile.profession].filter(Boolean).join(" • ")}</p>
          <div className="mt-4 flex flex-wrap justify-center gap-2"><StatusPill value={profile.approvalStatus} /><StatusPill value={profile.verificationStatus} /></div>
          {profile.headline && <p className="mt-4 rounded-2xl bg-rose-50 p-3 text-sm font-bold text-[#F43F5E]">{profile.headline}</p>}
          <div className="mt-6 grid gap-2">
            {isSelf ? (
              <>
                <Link href="/profile/edit" className="rounded-full bg-[#F43F5E] px-5 py-3 text-sm font-black text-white transition hover:bg-rose-600">Edit Profile</Link>
                <Link href="/partner-preferences" className="rounded-full bg-[#1E1B4B] px-5 py-3 text-sm font-black text-white transition hover:bg-indigo-950">Partner Preferences</Link>
                <form action="/api/actions" method="post">
                  <input type="hidden" name="action" value="requestVerification" />
                  <button className="w-full rounded-full bg-emerald-50 px-5 py-3 text-sm font-black text-emerald-700 transition hover:bg-emerald-100" type="submit">Request Verification</button>
                </form>
                <form action="/api/actions" method="post" onSubmit={(e) => { if (!confirm("Are you sure you want to delete your profile? This cannot be undone.")) e.preventDefault(); }}>
                  <input type="hidden" name="action" value="deleteProfile" />
                  <button className="w-full rounded-full bg-red-50 px-5 py-3 text-sm font-black text-red-700 transition hover:bg-red-100" type="submit">Delete Profile</button>
                </form>
              </>
            ) : (
              <>
                {profile.accepted ? (
                  <div className="rounded-2xl bg-emerald-50 p-3 text-center">
                    <p className="text-xs font-black uppercase tracking-wider text-emerald-800">Connected Matrimonial Match</p>
                    <form action="/api/actions" method="post" className="mt-2">
                      <input type="hidden" name="action" value="startConversation" />
                      <input type="hidden" name="targetUserId" value={profile.userId} />
                      <button className="w-full rounded-full bg-[#1E1B4B] px-5 py-2.5 text-sm font-black text-white transition hover:bg-indigo-950" type="submit">Open Chat</button>
                    </form>
                  </div>
                ) : received && received.status === "pending" ? (
                  <div className="rounded-2xl bg-rose-50 p-3 text-center">
                    <p className="text-xs font-black uppercase tracking-wider text-[#F43F5E]">Sent You an Interest</p>
                    <div className="mt-2 grid grid-cols-2 gap-2">
                      <form action="/api/actions" method="post">
                        <input type="hidden" name="action" value="interestStatus" />
                        <input type="hidden" name="interestId" value={received.id} />
                        <input type="hidden" name="status" value="accepted" />
                        <button className="w-full rounded-full bg-[#F43F5E] px-4 py-2 text-xs font-black text-white" type="submit">Accept</button>
                      </form>
                      <form action="/api/actions" method="post">
                        <input type="hidden" name="action" value="interestStatus" />
                        <input type="hidden" name="interestId" value={received.id} />
                        <input type="hidden" name="status" value="rejected" />
                        <button className="w-full rounded-full bg-slate-100 px-4 py-2 text-xs font-black text-slate-700" type="submit">Reject</button>
                      </form>
                    </div>
                  </div>
                ) : sent && sent.status === "pending" ? (
                  <div className="rounded-2xl bg-amber-50 p-3 text-center">
                    <p className="text-xs font-black uppercase tracking-wider text-amber-800">Interest Sent (Pending)</p>
                    <form action="/api/actions" method="post" className="mt-2">
                      <input type="hidden" name="action" value="cancelInterest" />
                      <input type="hidden" name="interestId" value={sent.id} />
                      <button className="w-full rounded-full bg-slate-200 px-4 py-2 text-xs font-black text-slate-700 hover:bg-red-50 hover:text-red-700" type="submit">Cancel Interest</button>
                    </form>
                  </div>
                ) : (
                  <form action="/api/actions" method="post">
                    <input type="hidden" name="action" value="sendInterest" />
                    <input type="hidden" name="targetUserId" value={profile.userId} />
                    <button className="w-full rounded-full bg-[#F43F5E] px-5 py-3 text-sm font-black text-white shadow-lg shadow-rose-500/25 transition hover:bg-rose-600" type="submit">Send Interest</button>
                  </form>
                )}

                <form action="/api/actions" method="post">
                  <input type="hidden" name="action" value="profileLike" />
                  <input type="hidden" name="targetUserId" value={profile.userId} />
                  <button className="w-full rounded-full bg-rose-50 px-5 py-3 text-sm font-black text-[#F43F5E] transition hover:bg-rose-100" type="submit">Like Profile</button>
                </form>

                <form action="/api/actions" method="post">
                  <input type="hidden" name="action" value="shortlist" />
                  <input type="hidden" name="targetUserId" value={profile.userId} />
                  <button className="w-full rounded-full bg-slate-100 px-5 py-3 text-sm font-black text-slate-700 transition hover:bg-slate-200" type="submit">Add to Shortlist</button>
                </form>

                <Link href={`/report-user?userId=${profile.userId}`} className="rounded-full bg-amber-50 px-5 py-3 text-center text-sm font-black text-amber-800 transition hover:bg-amber-100">Report Profile</Link>
                <form action="/api/actions" method="post">
                  <input type="hidden" name="action" value="blockUser" />
                  <input type="hidden" name="blockedUserId" value={profile.userId} />
                  <button className="w-full rounded-full bg-red-50 px-5 py-3 text-sm font-black text-red-700 transition hover:bg-red-100" type="submit">Block Profile</button>
                </form>
              </>
            )}
          </div>
        </section>
        <SafetyBanner />
      </aside>

      <section className="space-y-5">
        <div className="rounded-[2rem] bg-white p-6 shadow-xl shadow-slate-200/70">
          <h2 className="text-2xl font-black text-[#1E1B4B]">About Me</h2>
          <p className="mt-3 whitespace-pre-line text-sm leading-7 text-slate-700">{profile.about || "This member has not added a detailed introduction yet."}</p>
        </div>

        <div className="grid gap-4 sm:grid-cols-2">
          <FieldValue label="Age" value={profile.age ? `${profile.age} years` : undefined} />
          <FieldValue label="Location" value={profile.location} />
          <FieldValue label="Profession" value={profile.profession} />
          <FieldValue label="Education" value={profile.education} />
          <FieldValue label="Income" value={moneyLabel(profile.income)} />
          <FieldValue label="Height" value={profile.heightCm ? `${profile.heightCm} cm` : undefined} />
          <FieldValue label="Religion" value={profile.religion} />
          <FieldValue label="Community/Caste" value={profile.community} />
          <FieldValue label="Mother Tongue" value={profile.motherTongue} />
          <FieldValue label="Marital Status" value={profile.maritalStatus} />
          <FieldValue label="Joined" value={formatDate(profile.createdAt)} />
          <FieldValue label="Visibility" value={profile.visibility} />
        </div>

        <div className="grid gap-5 md:grid-cols-2">
          <div className="rounded-[2rem] bg-white p-6 shadow-xl shadow-slate-200/70">
            <h2 className="text-xl font-black text-[#1E1B4B]">Family Details</h2>
            <p className="mt-3 whitespace-pre-line text-sm leading-7 text-slate-700">{profile.familyDetails || "Family details not shared yet."}</p>
          </div>
          <div className="rounded-[2rem] bg-white p-6 shadow-xl shadow-slate-200/70">
            <h2 className="text-xl font-black text-[#1E1B4B]">Lifestyle</h2>
            <p className="mt-3 whitespace-pre-line text-sm leading-7 text-slate-700">{profile.lifestyle || "Lifestyle details not shared yet."}</p>
          </div>
        </div>

        <div className="rounded-[2rem] bg-white p-6 shadow-xl shadow-slate-200/70">
          <h2 className="text-xl font-black text-[#1E1B4B]">Partner Preferences</h2>
          <div className="mt-4 grid gap-4 sm:grid-cols-2">
            <FieldValue label="Looking For" value={profile.preferences?.lookingFor} />
            <FieldValue label="Age Range" value={profile.preferences?.ageMin || profile.preferences?.ageMax ? `${profile.preferences?.ageMin || "Any"} - ${profile.preferences?.ageMax || "Any"}` : undefined} />
            <FieldValue label="Location" value={profile.preferences?.location} />
            <FieldValue label="Religion/Community" value={[profile.preferences?.religion, profile.preferences?.community].filter(Boolean).join(" / ")} />
            <FieldValue label="Education" value={profile.preferences?.education} />
            <FieldValue label="Profession" value={profile.preferences?.profession} />
          </div>
          <p className="mt-4 whitespace-pre-line rounded-2xl bg-slate-50 p-4 text-sm leading-7 text-slate-700">{profile.preferences?.description || "Partner preference details not shared yet."}</p>
        </div>

        <div className="rounded-[2rem] bg-white p-6 shadow-xl shadow-slate-200/70">
          <h2 className="text-xl font-black text-[#1E1B4B]">Private Contact Information</h2>
          <p className="mt-2 text-sm leading-6 text-slate-600">Contact details are hidden by default and shown only when privacy settings allow it.</p>
          <div className="mt-4 grid gap-4 sm:grid-cols-2">
            <FieldValue label="Email" value={profile.canSeeEmail ? profile.email : "Hidden by privacy"} />
            <FieldValue label="Mobile" value={profile.canSeePhone ? profile.mobile : "Hidden by privacy"} />
          </div>
        </div>
      </section>
    </div>
  );
}
