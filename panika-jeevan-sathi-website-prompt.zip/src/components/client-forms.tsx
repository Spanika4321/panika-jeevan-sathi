"use client";

import { FormEvent, useMemo, useState } from "react";
import type { ActionResult } from "@/lib/data-types";
import { genderOptions, maritalStatusOptions, visibilityOptions } from "@/lib/constants";

type ProfileEditorProps = {
  user: {
    fullName: string;
    gender: string;
    dateOfBirth: string | null;
    mobile: string;
  };
  profile: {
    profilePhotoUrl: string | null;
    headline: string | null;
    about: string | null;
    familyDetails: string | null;
    lifestyle: string | null;
    religion: string | null;
    community: string | null;
    motherTongue: string | null;
    maritalStatus: string | null;
    education: string | null;
    profession: string | null;
    income: number | null;
    location: string | null;
    heightCm: number | null;
    visibility: string;
  };
};

type PreferenceEditorProps = {
  gender: string;
  preferences: {
    lookingFor: string | null;
    ageMin: number | null;
    ageMax: number | null;
    location: string | null;
    religion: string | null;
    community: string | null;
    motherTongue: string | null;
    maritalStatus: string | null;
    education: string | null;
    profession: string | null;
    incomeMin: number | null;
    incomeMax: number | null;
    heightMinCm: number | null;
    heightMaxCm: number | null;
    description: string | null;
  } | null;
};

type PrivacyEditorProps = {
  privacy: {
    hidePhone: boolean;
    hideEmail: boolean;
    profileVisibility: string;
    allowMessagesFrom: string;
  } | null;
};

async function fileToDataUrl(file: File) {
  return new Promise<string>((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(String(reader.result));
    reader.onerror = reject;
    reader.readAsDataURL(file);
  });
}

async function postAction(formData: FormData): Promise<ActionResult> {
  formData.set("_json", "1");
  const response = await fetch("/api/actions", { method: "POST", body: formData, headers: { Accept: "application/json" } });
  return response.json() as Promise<ActionResult>;
}

function TextInput({ label, name, value, onChange, type = "text", required = false, placeholder }: { label: string; name: string; value: string; onChange: (name: string, value: string) => void; type?: string; required?: boolean; placeholder?: string }) {
  return (
    <label className="block">
      <span className="text-sm font-bold text-slate-700">{label}</span>
      <input name={name} type={type} value={value} required={required} placeholder={placeholder} onChange={(event) => onChange(name, event.target.value)} className="mt-2 w-full rounded-2xl border border-slate-200 bg-white px-4 py-3 text-sm outline-none transition focus:border-[#F43F5E] focus:ring-4 focus:ring-rose-100" />
    </label>
  );
}

function SelectInput({ label, name, value, onChange, options, required = false }: { label: string; name: string; value: string; onChange: (name: string, value: string) => void; options: string[]; required?: boolean }) {
  return (
    <label className="block">
      <span className="text-sm font-bold text-slate-700">{label}</span>
      <select name={name} value={value} required={required} onChange={(event) => onChange(name, event.target.value)} className="mt-2 w-full rounded-2xl border border-slate-200 bg-white px-4 py-3 text-sm outline-none transition focus:border-[#F43F5E] focus:ring-4 focus:ring-rose-100">
        <option value="">Select</option>
        {options.map((option) => <option key={option} value={option}>{option}</option>)}
      </select>
    </label>
  );
}

function TextArea({ label, name, value, onChange, rows = 4, placeholder }: { label: string; name: string; value: string; onChange: (name: string, value: string) => void; rows?: number; placeholder?: string }) {
  return (
    <label className="block md:col-span-2">
      <span className="text-sm font-bold text-slate-700">{label}</span>
      <textarea name={name} value={value} rows={rows} placeholder={placeholder} onChange={(event) => onChange(name, event.target.value)} className="mt-2 w-full rounded-2xl border border-slate-200 bg-white px-4 py-3 text-sm outline-none transition focus:border-[#F43F5E] focus:ring-4 focus:ring-rose-100" />
    </label>
  );
}

function FormMessage({ message, error }: { message?: string; error?: string }) {
  if (!message && !error) return null;
  return <div className={`rounded-2xl px-4 py-3 text-sm font-bold ${error ? "bg-red-50 text-red-700" : "bg-emerald-50 text-emerald-700"}`}>{error || message}</div>;
}

export function VerifyOtpForm({ initialEmail = "" }: { initialEmail?: string }) {
  const [loading, setLoading] = useState(false);
  const [resending, setResending] = useState(false);
  const [message, setMessage] = useState("");
  const [error, setError] = useState("");
  const [email, setEmail] = useState(initialEmail);
  const [otp, setOtp] = useState("");

  async function submit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setLoading(true);
    setError("");
    setMessage("");
    const formData = new FormData();
    formData.set("action", "verifyOtp");
    formData.set("email", email);
    formData.set("otp", otp);
    const result = await postAction(formData);
    setLoading(false);
    if (!result.ok) {
      setError(result.message);
    } else {
      setMessage(result.message);
      window.location.href = result.redirectTo || "/login";
    }
  }

  async function handleResend() {
    if (!email.trim()) {
      setError("Please enter your registered email first.");
      return;
    }
    setResending(true);
    setError("");
    setMessage("");
    const formData = new FormData();
    formData.set("action", "resendOtp");
    formData.set("email", email);
    const result = await postAction(formData);
    setResending(false);
    if (!result.ok) setError(result.message);
    else setMessage(result.message);
  }

  return (
    <form onSubmit={submit} className="space-y-4 rounded-3xl bg-white p-6 shadow-xl shadow-slate-200/70">
      <TextInput label="Registered Email" name="email" value={email} onChange={(_, val) => setEmail(val)} type="email" required placeholder="your.name@example.com" />
      <TextInput label="6-Digit OTP" name="otp" value={otp} onChange={(_, val) => setOtp(val)} required placeholder="123456" />
      <FormMessage message={message} error={error} />
      <button disabled={loading} className="w-full rounded-full bg-[#F43F5E] px-6 py-3 font-black text-white shadow-lg shadow-rose-500/25 disabled:opacity-60">{loading ? "Verifying..." : "Verify & Activate Profile"}</button>
      <div className="pt-2 text-center">
        <button type="button" disabled={resending} onClick={handleResend} className="text-xs font-bold text-[#1E1B4B] underline hover:text-[#F43F5E] disabled:opacity-50">
          {resending ? "Sending new OTP..." : "Didn't get OTP? Resend code"}
        </button>
      </div>
    </form>
  );
}

export function RegisterWizard() {
  const [step, setStep] = useState(1);
  const [loading, setLoading] = useState(false);
  const [message, setMessage] = useState("");
  const [error, setError] = useState("");
  const [registeredEmail, setRegisteredEmail] = useState("");
  const [form, setForm] = useState<Record<string, string>>({ gender: "", maritalStatus: "", profilePhotoUrl: "" });

  const progress = useMemo(() => `${Math.round((step / 4) * 100)}%`, [step]);
  const value = (name: string) => form[name] || "";
  const update = (name: string, nextValue: string) => setForm((current) => ({ ...current, [name]: nextValue }));

  async function submitRegistration() {
    setLoading(true);
    setError("");
    setMessage("");
    const formData = new FormData();
    formData.set("action", "register");
    Object.entries(form).forEach(([key, val]) => formData.set(key, val));
    const result = await postAction(formData);
    setLoading(false);
    if (!result.ok) {
      setError(result.message);
      return;
    }
    setRegisteredEmail(value("email"));
    setMessage(result.message);
  }

  if (registeredEmail) {
    return (
      <div className="rounded-3xl bg-white p-6 shadow-xl shadow-slate-200/70">
        <h2 className="text-2xl font-black text-[#1E1B4B]">Verify Email OTP</h2>
        <p className="mt-2 text-sm leading-6 text-slate-600">Enter the verification code sent to <strong>{registeredEmail}</strong>. Your profile will become visible in matches once approved by platform admin.</p>
        <div className="mt-5">
          <VerifyOtpForm initialEmail={registeredEmail} />
        </div>
      </div>
    );
  }

  return (
    <div className="rounded-3xl bg-white p-5 shadow-xl shadow-slate-200/70 sm:p-7">
      <div className="mb-6">
        <div className="flex items-center justify-between text-xs font-black uppercase tracking-[0.16em] text-slate-500"><span>Step {step} of 4</span><span>{progress}</span></div>
        <div className="mt-3 h-2 overflow-hidden rounded-full bg-slate-100"><div className="h-full rounded-full bg-[#F43F5E] transition-all" style={{ width: progress }} /></div>
      </div>
      <form onSubmit={(event) => { event.preventDefault(); if (step < 4) setStep(step + 1); else void submitRegistration(); }} className="space-y-5">
        {step === 1 && (
          <div className="grid gap-4 md:grid-cols-2">
            <TextInput label="Full Name" name="fullName" value={value("fullName")} onChange={update} required placeholder="Full Name" />
            <SelectInput label="Gender" name="gender" value={value("gender")} onChange={update} options={genderOptions} required />
            <TextInput label="Date of Birth" name="dateOfBirth" value={value("dateOfBirth")} onChange={update} type="date" required />
            <TextInput label="Email" name="email" value={value("email")} onChange={update} type="email" required placeholder="user@example.com" />
            <TextInput label="Mobile Number" name="mobile" value={value("mobile")} onChange={update} required placeholder="10-digit mobile" />
            <TextInput label="Password" name="password" value={value("password")} onChange={update} type="password" required placeholder="8+ chars with letters & numbers" />
          </div>
        )}
        {step === 2 && (
          <div className="grid gap-4 md:grid-cols-2">
            <TextInput label="Religion" name="religion" value={value("religion")} onChange={update} placeholder="e.g. Hindu" />
            <TextInput label="Community/Caste" name="community" value={value("community")} onChange={update} placeholder="e.g. Panika" />
            <TextInput label="Mother Tongue" name="motherTongue" value={value("motherTongue")} onChange={update} placeholder="e.g. Hindi" />
            <SelectInput label="Marital Status" name="maritalStatus" value={value("maritalStatus")} onChange={update} options={maritalStatusOptions} />
          </div>
        )}
        {step === 3 && (
          <div className="grid gap-4 md:grid-cols-2">
            <TextInput label="Education" name="education" value={value("education")} onChange={update} placeholder="e.g. B.Tech / MBA / Graduate" />
            <TextInput label="Profession" name="profession" value={value("profession")} onChange={update} placeholder="e.g. Software Engineer / Business" />
            <TextInput label="Annual Income (₹)" name="income" value={value("income")} onChange={update} type="number" placeholder="Annual income in INR" />
            <TextInput label="Location" name="location" value={value("location")} onChange={update} placeholder="City, State" />
          </div>
        )}
        {step === 4 && (
          <div className="grid gap-4 md:grid-cols-2">
            <TextArea label="About Yourself" name="about" value={value("about")} onChange={update} placeholder="Share your personality, values, family background and aspirations." />
            <TextArea label="Partner Preference" name="partnerPreference" value={value("partnerPreference")} onChange={update} placeholder="Describe the kind of life partner and family values you are seeking." />
            <label className="block md:col-span-2">
              <span className="text-sm font-bold text-slate-700">Profile Photo</span>
              <input type="file" accept="image/*" onChange={async (event) => { const file = event.target.files?.[0]; if (file) update("profilePhotoUrl", await fileToDataUrl(file)); }} className="mt-2 w-full rounded-2xl border border-dashed border-slate-300 bg-slate-50 px-4 py-4 text-sm" />
              {value("profilePhotoUrl") && <img src={value("profilePhotoUrl")} alt="Preview" className="mt-3 h-24 w-24 rounded-full object-cover shadow" />}
            </label>
          </div>
        )}
        <FormMessage message={message} error={error} />
        <div className="flex gap-3">
          {step > 1 && <button type="button" onClick={() => setStep(step - 1)} className="rounded-full border border-slate-200 px-6 py-3 font-black text-slate-700 hover:bg-slate-50">Back</button>}
          <button disabled={loading} className="flex-1 rounded-full bg-[#F43F5E] px-6 py-3 font-black text-white shadow-lg shadow-rose-500/25 transition hover:bg-rose-600 disabled:opacity-60">{loading ? "Saving..." : step < 4 ? "Continue" : "Create Profile"}</button>
        </div>
      </form>
    </div>
  );
}

export function LoginForm({ returnTo = "/profile" }: { returnTo?: string }) {
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [form, setForm] = useState({ identifier: "", password: "" });
  const update = (name: string, nextValue: string) => setForm((current) => ({ ...current, [name]: nextValue }));

  async function submit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setLoading(true);
    setError("");
    const result = await postAction(new FormData(event.currentTarget));
    setLoading(false);
    if (!result.ok) setError(result.message);
    else window.location.href = result.redirectTo || "/profile";
  }

  return (
    <form onSubmit={submit} className="space-y-4 rounded-3xl bg-white p-6 shadow-xl shadow-slate-200/70">
      <input type="hidden" name="action" value="login" />
      <input type="hidden" name="returnTo" value={returnTo} />
      <TextInput label="Email or Mobile" name="identifier" value={form.identifier} onChange={update} required placeholder="user@example.com or 10-digit mobile" />
      <TextInput label="Password" name="password" value={form.password} onChange={update} type="password" required placeholder="Your password" />
      <FormMessage error={error} />
      <button disabled={loading} className="w-full rounded-full bg-[#F43F5E] px-6 py-3 font-black text-white shadow-lg shadow-rose-500/25 transition hover:bg-rose-600 disabled:opacity-60">{loading ? "Logging in..." : "Login"}</button>
    </form>
  );
}

export function ForgotPasswordForm({ token }: { token?: string }) {
  const [loading, setLoading] = useState(false);
  const [message, setMessage] = useState("");
  const [error, setError] = useState("");
  const [form, setForm] = useState<Record<string, string>>({});
  const update = (name: string, nextValue: string) => setForm((current) => ({ ...current, [name]: nextValue }));

  async function submit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setLoading(true);
    setMessage("");
    setError("");
    const result = await postAction(new FormData(event.currentTarget));
    setLoading(false);
    if (!result.ok) setError(result.message);
    else {
      setMessage(result.message);
      if (result.redirectTo === "/login") window.location.href = "/login";
    }
  }

  return (
    <form onSubmit={submit} className="space-y-4 rounded-3xl bg-white p-6 shadow-xl shadow-slate-200/70">
      <input type="hidden" name="action" value={token ? "resetPassword" : "forgotPassword"} />
      {token ? <input type="hidden" name="token" value={token} /> : null}
      {token ? (
        <TextInput label="New Password" name="password" type="password" value={form.password || ""} onChange={update} required placeholder="8+ characters with letters & numbers" />
      ) : (
        <TextInput label="Registered Email" name="email" type="email" value={form.email || ""} onChange={update} required placeholder="your.name@example.com" />
      )}
      <FormMessage message={message} error={error} />
      <button disabled={loading} className="w-full rounded-full bg-[#F43F5E] px-6 py-3 font-black text-white shadow-lg shadow-rose-500/25 transition hover:bg-rose-600 disabled:opacity-60">{loading ? "Please wait..." : token ? "Reset Password" : "Send Reset Link"}</button>
    </form>
  );
}

export function ProfileEditor({ user, profile }: ProfileEditorProps) {
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [form, setForm] = useState<Record<string, string>>({
    fullName: user.fullName,
    gender: user.gender,
    dateOfBirth: user.dateOfBirth || "",
    mobile: user.mobile,
    profilePhotoUrl: profile.profilePhotoUrl || "",
    headline: profile.headline || "",
    about: profile.about || "",
    familyDetails: profile.familyDetails || "",
    lifestyle: profile.lifestyle || "",
    religion: profile.religion || "",
    community: profile.community || "",
    motherTongue: profile.motherTongue || "",
    maritalStatus: profile.maritalStatus || "",
    education: profile.education || "",
    profession: profile.profession || "",
    income: profile.income?.toString() || "",
    location: profile.location || "",
    heightCm: profile.heightCm?.toString() || "",
    visibility: profile.visibility || "public",
  });
  const update = (name: string, nextValue: string) => setForm((current) => ({ ...current, [name]: nextValue }));
  const value = (name: string) => form[name] || "";

  async function submit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setLoading(true);
    setError("");
    const formData = new FormData();
    formData.set("action", "updateProfile");
    Object.entries(form).forEach(([key, val]) => formData.set(key, val));
    const result = await postAction(formData);
    setLoading(false);
    if (!result.ok) setError(result.message);
    else window.location.href = result.redirectTo || "/profile";
  }

  return (
    <form onSubmit={submit} className="space-y-5 rounded-3xl bg-white p-5 shadow-xl shadow-slate-200/70 sm:p-7">
      <div className="grid gap-4 md:grid-cols-2">
        <TextInput label="Full Name" name="fullName" value={value("fullName")} onChange={update} required />
        <SelectInput label="Gender" name="gender" value={value("gender")} onChange={update} options={genderOptions} required />
        <TextInput label="Date of Birth" name="dateOfBirth" type="date" value={value("dateOfBirth")} onChange={update} required />
        <TextInput label="Mobile Number" name="mobile" value={value("mobile")} onChange={update} required />
        <TextInput label="Headline" name="headline" value={value("headline")} onChange={update} placeholder="e.g. Caring, family-oriented professional" />
        <TextInput label="Location" name="location" value={value("location")} onChange={update} placeholder="City, State" />
        <TextInput label="Religion" name="religion" value={value("religion")} onChange={update} placeholder="e.g. Hindu" />
        <TextInput label="Community/Caste" name="community" value={value("community")} onChange={update} placeholder="e.g. Panika" />
        <TextInput label="Mother Tongue" name="motherTongue" value={value("motherTongue")} onChange={update} placeholder="e.g. Hindi" />
        <SelectInput label="Marital Status" name="maritalStatus" value={value("maritalStatus")} onChange={update} options={maritalStatusOptions} />
        <TextInput label="Education" name="education" value={value("education")} onChange={update} placeholder="e.g. B.Tech / M.Com" />
        <TextInput label="Profession" name="profession" value={value("profession")} onChange={update} placeholder="e.g. Banking / Business" />
        <TextInput label="Annual Income (₹)" name="income" type="number" value={value("income")} onChange={update} placeholder="e.g. 500000" />
        <TextInput label="Height (cm)" name="heightCm" type="number" value={value("heightCm")} onChange={update} placeholder="e.g. 172" />
        <SelectInput label="Profile Visibility" name="visibility" value={value("visibility")} onChange={update} options={visibilityOptions} />
        <label className="block">
          <span className="text-sm font-bold text-slate-700">Profile Photo</span>
          <input type="file" accept="image/*" onChange={async (event) => { const file = event.target.files?.[0]; if (file) update("profilePhotoUrl", await fileToDataUrl(file)); }} className="mt-2 w-full rounded-2xl border border-dashed border-slate-300 bg-slate-50 px-4 py-3 text-sm" />
          {value("profilePhotoUrl") && <img src={value("profilePhotoUrl")} alt="Profile preview" className="mt-3 h-20 w-20 rounded-full object-cover shadow" />}
        </label>
        <TextArea label="About Me" name="about" value={value("about")} onChange={update} placeholder="Tell members about yourself, your upbringing and your character." />
        <TextArea label="Family Details" name="familyDetails" value={value("familyDetails")} onChange={update} placeholder="Parents, siblings, native place, family values." />
        <TextArea label="Lifestyle" name="lifestyle" value={value("lifestyle")} onChange={update} placeholder="Diet, habits, interests, hobbies." />
      </div>
      <FormMessage error={error} />
      <div className="flex flex-col gap-3 sm:flex-row">
        <button disabled={loading} className="flex-1 rounded-full bg-[#F43F5E] px-6 py-3 font-black text-white shadow-lg shadow-rose-500/25 transition hover:bg-rose-600 disabled:opacity-60">{loading ? "Saving..." : "Save Profile"}</button>
      </div>
    </form>
  );
}

export function PreferencesEditor({ gender, preferences }: PreferenceEditorProps) {
  const defaultLookingFor = gender === "Male" ? "Female" : gender === "Female" ? "Male" : "";
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [form, setForm] = useState<Record<string, string>>({
    lookingFor: preferences?.lookingFor || defaultLookingFor,
    ageMin: preferences?.ageMin?.toString() || "",
    ageMax: preferences?.ageMax?.toString() || "",
    location: preferences?.location || "",
    religion: preferences?.religion || "",
    community: preferences?.community || "",
    motherTongue: preferences?.motherTongue || "",
    maritalStatus: preferences?.maritalStatus || "",
    education: preferences?.education || "",
    profession: preferences?.profession || "",
    incomeMin: preferences?.incomeMin?.toString() || "",
    incomeMax: preferences?.incomeMax?.toString() || "",
    heightMinCm: preferences?.heightMinCm?.toString() || "",
    heightMaxCm: preferences?.heightMaxCm?.toString() || "",
    description: preferences?.description || "",
  });
  const update = (name: string, nextValue: string) => setForm((current) => ({ ...current, [name]: nextValue }));
  const value = (name: string) => form[name] || "";

  async function submit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setLoading(true);
    setError("");
    const formData = new FormData();
    formData.set("action", "updatePreferences");
    Object.entries(form).forEach(([key, val]) => formData.set(key, val));
    const result = await postAction(formData);
    setLoading(false);
    if (!result.ok) setError(result.message);
    else window.location.href = result.redirectTo || "/partner-preferences";
  }

  return (
    <form onSubmit={submit} className="space-y-5 rounded-3xl bg-white p-5 shadow-xl shadow-slate-200/70 sm:p-7">
      <div className="grid gap-4 md:grid-cols-2">
        <SelectInput label="Looking For" name="lookingFor" value={value("lookingFor")} onChange={update} options={genderOptions} />
        <TextInput label="Age Min" name="ageMin" type="number" value={value("ageMin")} onChange={update} placeholder="e.g. 21" />
        <TextInput label="Age Max" name="ageMax" type="number" value={value("ageMax")} onChange={update} placeholder="e.g. 30" />
        <TextInput label="Preferred Location" name="location" value={value("location")} onChange={update} placeholder="e.g. Delhi, Mumbai or State" />
        <TextInput label="Preferred Religion" name="religion" value={value("religion")} onChange={update} placeholder="e.g. Hindu" />
        <TextInput label="Preferred Community/Caste" name="community" value={value("community")} onChange={update} placeholder="e.g. Panika" />
        <TextInput label="Preferred Mother Tongue" name="motherTongue" value={value("motherTongue")} onChange={update} placeholder="e.g. Hindi" />
        <SelectInput label="Preferred Marital Status" name="maritalStatus" value={value("maritalStatus")} onChange={update} options={maritalStatusOptions} />
        <TextInput label="Preferred Education" name="education" value={value("education")} onChange={update} placeholder="e.g. Graduate or higher" />
        <TextInput label="Preferred Profession" name="profession" value={value("profession")} onChange={update} placeholder="e.g. Private / Govt / Any" />
        <TextInput label="Minimum Income (₹)" name="incomeMin" type="number" value={value("incomeMin")} onChange={update} placeholder="e.g. 300000" />
        <TextInput label="Maximum Income (₹)" name="incomeMax" type="number" value={value("incomeMax")} onChange={update} placeholder="Optional" />
        <TextInput label="Height Min (cm)" name="heightMinCm" type="number" value={value("heightMinCm")} onChange={update} placeholder="e.g. 155" />
        <TextInput label="Height Max (cm)" name="heightMaxCm" type="number" value={value("heightMaxCm")} onChange={update} placeholder="e.g. 185" />
        <TextArea label="Partner Preference Details" name="description" value={value("description")} onChange={update} placeholder="Describe values, lifestyle expectations, and family compatibility." />
      </div>
      <FormMessage error={error} />
      <button disabled={loading} className="w-full rounded-full bg-[#F43F5E] px-6 py-3 font-black text-white shadow-lg shadow-rose-500/25 transition hover:bg-rose-600 disabled:opacity-60">{loading ? "Saving..." : "Save Preferences"}</button>
    </form>
  );
}

export function PrivacySettingsForm({ privacy }: PrivacyEditorProps) {
  return (
    <form action="/api/actions" method="post" className="space-y-4 rounded-3xl bg-white p-5 shadow-xl shadow-slate-200/70 sm:p-7">
      <input type="hidden" name="action" value="updatePrivacy" />
      <label className="flex items-center justify-between gap-4 rounded-2xl bg-slate-50 p-4 text-sm font-bold text-slate-700"><span>Hide phone number from non-accepted users</span><input type="checkbox" name="hidePhone" defaultChecked={privacy?.hidePhone ?? true} className="h-5 w-5 accent-[#F43F5E]" /></label>
      <label className="flex items-center justify-between gap-4 rounded-2xl bg-slate-50 p-4 text-sm font-bold text-slate-700"><span>Hide email address from non-accepted users</span><input type="checkbox" name="hideEmail" defaultChecked={privacy?.hideEmail ?? true} className="h-5 w-5 accent-[#F43F5E]" /></label>
      <label className="block"><span className="text-sm font-bold text-slate-700">Profile visibility</span><select name="profileVisibility" defaultValue={privacy?.profileVisibility || "public"} className="mt-2 w-full rounded-2xl border border-slate-200 px-4 py-3 text-sm"><option value="public">Public (visible in search after admin approval)</option><option value="members">Members only (logged-in members only)</option><option value="private">Private (hidden from search)</option></select></label>
      <label className="block"><span className="text-sm font-bold text-slate-700">Messages allowed from</span><select name="allowMessagesFrom" defaultValue={privacy?.allowMessagesFrom || "accepted_matches"} className="mt-2 w-full rounded-2xl border border-slate-200 px-4 py-3 text-sm"><option value="accepted_matches">Accepted matches only</option><option value="admin_override">Admin override only</option></select></label>
      <button className="w-full rounded-full bg-[#F43F5E] px-6 py-3 font-black text-white shadow-lg shadow-rose-500/25 transition hover:bg-rose-600">Save Privacy Settings</button>
    </form>
  );
}

export function MessageComposer({ conversationId, isBlocked = false }: { conversationId: number; isBlocked?: boolean }) {
  const [content, setContent] = useState("");
  const [loading, setLoading] = useState(false);

  if (isBlocked) {
    return (
      <div className="rounded-2xl border border-red-200 bg-red-50 p-4 text-center text-sm font-bold text-red-700">
        Messaging is disabled because of a user block.
      </div>
    );
  }

  async function submit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    if (!content.trim()) return;
    setLoading(true);
    const formData = new FormData();
    formData.set("action", "sendMessage");
    formData.set("conversationId", String(conversationId));
    formData.set("content", content);
    const result = await postAction(formData);
    setLoading(false);
    if (result.ok) {
      setContent("");
      window.location.reload();
    }
  }

  return (
    <form onSubmit={submit} className="sticky bottom-20 flex gap-2 rounded-3xl border border-slate-200 bg-white p-3 shadow-xl lg:bottom-4">
      <input value={content} onChange={(event) => setContent(event.target.value)} placeholder="Write a respectful message..." className="min-w-0 flex-1 rounded-full bg-slate-50 px-4 py-3 text-sm outline-none focus:ring-4 focus:ring-rose-100" />
      <button disabled={loading} className="rounded-full bg-[#F43F5E] px-5 py-3 text-sm font-black text-white transition hover:bg-rose-600 disabled:opacity-60">Send</button>
    </form>
  );
}

export function PostComposer() {
  const [content, setContent] = useState("");
  const [photoUrl, setPhotoUrl] = useState("");
  const [loading, setLoading] = useState(false);
  async function submit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setLoading(true);
    const formData = new FormData();
    formData.set("action", "createPost");
    formData.set("content", content);
    formData.set("photoUrl", photoUrl);
    const result = await postAction(formData);
    setLoading(false);
    if (result.ok) window.location.href = "/feed";
  }
  return (
    <form onSubmit={submit} className="space-y-4 rounded-3xl bg-white p-5 shadow-xl shadow-slate-200/70">
      <textarea value={content} onChange={(event) => setContent(event.target.value)} placeholder="Share a positive matrimonial community update..." rows={4} className="w-full rounded-2xl border border-slate-200 px-4 py-3 text-sm outline-none focus:border-[#F43F5E] focus:ring-4 focus:ring-rose-100" />
      {photoUrl && <img src={photoUrl} alt="Post preview" className="max-h-72 w-full rounded-2xl object-cover" />}
      <input type="file" accept="image/*" onChange={async (event) => { const file = event.target.files?.[0]; if (file) setPhotoUrl(await fileToDataUrl(file)); }} className="w-full rounded-2xl border border-dashed border-slate-300 bg-slate-50 px-4 py-3 text-sm" />
      <button disabled={loading} className="w-full rounded-full bg-[#F43F5E] px-6 py-3 font-black text-white shadow-lg shadow-rose-500/25 transition hover:bg-rose-600 disabled:opacity-60">{loading ? "Sharing..." : "Share Post"}</button>
    </form>
  );
}
