import Link from "next/link";
import type { MiniProfile, ProfileCardData } from "@/lib/data-types";
import { safetyEnglish, safetyHindi } from "@/lib/constants";
import { clsx, initials, moneyLabel, profileSummary } from "@/lib/utils";

export function NoticeBar({ notice, error }: { notice?: string; error?: string }) {
  const message = error || notice;
  if (!message) return null;
  return (
    <div className={clsx("mx-auto mb-5 max-w-5xl rounded-2xl border px-4 py-3 text-sm font-semibold", error ? "border-red-200 bg-red-50 text-red-700" : "border-emerald-200 bg-emerald-50 text-emerald-700")}>
      {message}
    </div>
  );
}

export function SectionHeading({ eyebrow, title, children }: { eyebrow?: string; title: string; children?: React.ReactNode }) {
  return (
    <div className="mb-6">
      {eyebrow && <p className="text-xs font-black uppercase tracking-[0.2em] text-[#F43F5E]">{eyebrow}</p>}
      <h1 className="mt-2 text-3xl font-black tracking-tight text-[#1E1B4B] sm:text-4xl">{title}</h1>
      {children && <div className="mt-3 max-w-3xl text-sm leading-6 text-slate-600 sm:text-base">{children}</div>}
    </div>
  );
}

export function StatusPill({ value }: { value?: string | null }) {
  const label = value || "unknown";
  const styles = label === "verified" || label === "approved" || label === "accepted" || label === "active"
    ? "bg-emerald-50 text-emerald-700 ring-emerald-200"
    : label === "pending" || label === "email_pending"
      ? "bg-amber-50 text-amber-700 ring-amber-200"
      : label === "rejected" || label === "suspended" || label === "deleted"
        ? "bg-red-50 text-red-700 ring-red-200"
        : "bg-slate-100 text-slate-700 ring-slate-200";
  return <span className={clsx("inline-flex items-center rounded-full px-3 py-1 text-xs font-black capitalize ring-1", styles)}>{label.replace("_", " ")}</span>;
}

export function Avatar({ profile, size = "md" }: { profile: Pick<MiniProfile, "fullName" | "profilePhotoUrl" | "verificationStatus">; size?: "sm" | "md" | "lg" | "xl" }) {
  const sizeClass = size === "sm" ? "h-11 w-11" : size === "lg" ? "h-20 w-20" : size === "xl" ? "h-32 w-32" : "h-14 w-14";
  return (
    <div className={clsx("relative shrink-0 overflow-hidden rounded-full bg-gradient-to-br from-indigo-950 to-rose-500 p-0.5 shadow-lg", sizeClass)}>
      {profile.profilePhotoUrl ? (
        <img src={profile.profilePhotoUrl} alt={profile.fullName} loading="lazy" className="h-full w-full rounded-full object-cover" />
      ) : (
        <div className="grid h-full w-full place-items-center rounded-full bg-white text-base font-black text-[#1E1B4B]">{initials(profile.fullName)}</div>
      )}
      {profile.verificationStatus === "verified" && <span className="absolute bottom-0 right-0 grid h-6 w-6 place-items-center rounded-full bg-emerald-500 text-xs text-white ring-2 ring-white">✓</span>}
    </div>
  );
}

export function EmptyState({ title, body, actionHref, actionLabel }: { title: string; body: string; actionHref?: string; actionLabel?: string }) {
  return (
    <div className="rounded-3xl border border-dashed border-slate-300 bg-white p-8 text-center shadow-sm">
      <div className="mx-auto grid h-14 w-14 place-items-center rounded-2xl bg-rose-50 text-2xl">♡</div>
      <h3 className="mt-4 text-xl font-black text-[#1E1B4B]">{title}</h3>
      <p className="mx-auto mt-2 max-w-md text-sm leading-6 text-slate-600">{body}</p>
      {actionHref && actionLabel && (
        <Link href={actionHref} className="mt-5 inline-flex rounded-full bg-[#F43F5E] px-5 py-3 text-sm font-black text-white shadow-lg shadow-rose-500/20">{actionLabel}</Link>
      )}
    </div>
  );
}

export function SafetyBanner() {
  return (
    <section className="rounded-3xl border border-amber-200 bg-gradient-to-br from-amber-50 to-white p-5 shadow-sm">
      <div className="flex flex-col gap-4 md:flex-row md:items-start">
        <div className="grid h-12 w-12 shrink-0 place-items-center rounded-2xl bg-amber-100 text-2xl">⚠️</div>
        <div>
          <h2 className="text-lg font-black text-amber-900">Safety First / सुरक्षा सबसे पहले</h2>
          <div className="mt-3 grid gap-4 text-sm leading-6 text-amber-900 md:grid-cols-2">
            <ul className="list-disc space-y-1 pl-5">{safetyEnglish.map((item) => <li key={item}>{item}</li>)}</ul>
            <ul className="list-disc space-y-1 pl-5">{safetyHindi.map((item) => <li key={item}>{item}</li>)}</ul>
          </div>
        </div>
      </div>
    </section>
  );
}

export function ProfileCard({ profile, viewerId }: { profile: ProfileCardData; viewerId?: number | null }) {
  const mini: MiniProfile = {
    userId: profile.userId,
    fullName: profile.fullName,
    age: profile.age,
    location: profile.location,
    profession: profile.profession,
    education: profile.education,
    profilePhotoUrl: profile.profilePhotoUrl,
    verificationStatus: profile.verificationStatus,
  };
  const isSelf = viewerId === profile.userId;

  return (
    <article className="group overflow-hidden rounded-3xl border border-slate-100 bg-white shadow-sm transition hover:-translate-y-1 hover:shadow-2xl hover:shadow-slate-200/70">
      <div className="relative h-44 bg-gradient-to-br from-[#1E1B4B] via-indigo-900 to-[#F43F5E]">
        {profile.profilePhotoUrl ? <img src={profile.profilePhotoUrl} alt={profile.fullName} loading="lazy" className="h-full w-full object-cover opacity-95" /> : <div className="grid h-full place-items-center text-6xl font-black text-white/90">{initials(profile.fullName)}</div>}
        {profile.matchPercent && <span className="absolute left-4 top-4 rounded-full bg-white px-3 py-1 text-xs font-black text-[#F43F5E] shadow">{profile.matchPercent}% Match</span>}
        {profile.verificationStatus === "verified" && <span className="absolute right-4 top-4 rounded-full bg-emerald-500 px-3 py-1 text-xs font-black text-white shadow">✓ Verified</span>}
      </div>
      <div className="p-5">
        <div className="flex items-start gap-3">
          <Avatar profile={mini} />
          <div className="min-w-0">
            <h3 className="truncate text-lg font-black text-[#1E1B4B]">{profile.fullName}</h3>
            <p className="text-sm font-semibold text-slate-600">{profileSummary(profile)}</p>
          </div>
        </div>
        <p className="mt-4 line-clamp-3 min-h-[4.5rem] text-sm leading-6 text-slate-600">{profile.headline || profile.about || "Looking for a respectful, meaningful and family-oriented life partnership."}</p>
        <div className="mt-4 grid grid-cols-2 gap-2 text-xs font-semibold text-slate-600">
          <span className="rounded-2xl bg-slate-50 px-3 py-2">{profile.religion || "Religion not shared"}</span>
          <span className="rounded-2xl bg-slate-50 px-3 py-2">{moneyLabel(profile.income)}</span>
        </div>
        <div className="mt-5 grid gap-2 sm:grid-cols-3">
          <Link href={`/profile/${profile.userId}`} className="rounded-full bg-[#1E1B4B] px-4 py-2 text-center text-xs font-black text-white">View Profile</Link>
          {!isSelf && (
            <form action="/api/actions" method="post">
              <input type="hidden" name="action" value="sendInterest" />
              <input type="hidden" name="targetUserId" value={profile.userId} />
              <button className="w-full rounded-full bg-[#F43F5E] px-4 py-2 text-xs font-black text-white" type="submit">Interest</button>
            </form>
          )}
          {!isSelf && (
            <form action="/api/actions" method="post">
              <input type="hidden" name="action" value="shortlist" />
              <input type="hidden" name="targetUserId" value={profile.userId} />
              <button className="w-full rounded-full bg-rose-50 px-4 py-2 text-xs font-black text-[#F43F5E]" type="submit">Shortlist</button>
            </form>
          )}
        </div>
      </div>
    </article>
  );
}

export function FieldValue({ label, value }: { label: string; value?: React.ReactNode }) {
  return (
    <div className="rounded-2xl bg-slate-50 p-4">
      <p className="text-xs font-black uppercase tracking-[0.16em] text-slate-400">{label}</p>
      <div className="mt-1 text-sm font-bold text-slate-800">{value || "Not shared"}</div>
    </div>
  );
}
