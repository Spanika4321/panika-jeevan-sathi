import Link from "next/link";
import { APP_NAME, TAGLINE } from "@/lib/constants";

export function Logo({ compact = false }: { compact?: boolean }) {
  return (
    <Link href="/" className="group flex items-center gap-3" aria-label={`${APP_NAME} home`}>
      <span className="relative grid h-11 w-11 shrink-0 place-items-center overflow-hidden rounded-2xl bg-[#1E1B4B] text-white shadow-lg shadow-rose-500/20">
        <span className="absolute inset-0 bg-[radial-gradient(circle_at_30%_20%,rgba(244,63,94,0.95),transparent_36%),radial-gradient(circle_at_70%_75%,rgba(255,255,255,0.28),transparent_34%)]" />
        <span className="relative text-lg font-black tracking-tight">PJ</span>
      </span>
      <span className="leading-tight">
        <span className="block text-sm font-black tracking-[0.16em] text-[#1E1B4B] sm:text-base">{APP_NAME}</span>
        {!compact && <span className="hidden text-xs font-medium text-slate-500 sm:block">{TAGLINE}</span>}
      </span>
    </Link>
  );
}
