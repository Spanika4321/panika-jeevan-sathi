import "dotenv/config";
import { NextRequest } from "next/server";
import { GET as healthGet } from "../src/app/api/health/route";
import { POST as actionsPost } from "../src/app/api/actions/route";

let passed = 0;

function check(cond: boolean, name: string) {
  if (cond) {
    passed++;
    console.log(`  ✓ HTTP PASS: ${name}`);
  } else {
    throw new Error(`HTTP FAIL: ${name}`);
  }
}

async function testHttpEndpoints() {
  console.log("\n[TEST GROUP 13] API Route Handlers");

  // Health endpoint
  const healthRes = await healthGet();
  const healthJson = await healthRes.json();
  check(healthRes.status === 200 && healthJson.ok === true, "/api/health returns 200 ok:true");

  // Invalid action
  const formDataBad = new FormData();
  formDataBad.set("action", "nonExistentAction");
  formDataBad.set("_json", "1");
  const badReq = new NextRequest("http://localhost:3000/api/actions", {
    method: "POST",
    body: formDataBad,
    headers: { Accept: "application/json" },
  });
  const badRes = await actionsPost(badReq);
  const badJson = await badRes.json();
  check(badRes.status === 400 && badJson.ok === false, "Unknown action returns 400 with error");

  // Login failure
  const formDataLoginFail = new FormData();
  formDataLoginFail.set("action", "login");
  formDataLoginFail.set("identifier", "nonexistent@panika.local");
  formDataLoginFail.set("password", "WrongPass123!");
  formDataLoginFail.set("_json", "1");
  const loginFailReq = new NextRequest("http://localhost:3000/api/actions", {
    method: "POST",
    body: formDataLoginFail,
    headers: { Accept: "application/json" },
  });
  const loginFailRes = await actionsPost(loginFailReq);
  const loginFailJson = await loginFailRes.json();
  check(loginFailRes.status === 400 && loginFailJson.ok === false, "Invalid login credentials rejected");

  // Resend OTP failure for nonexistent email
  const formDataResendBad = new FormData();
  formDataResendBad.set("action", "resendOtp");
  formDataResendBad.set("email", "doesnotexist@panika.local");
  formDataResendBad.set("_json", "1");
  const resendBadReq = new NextRequest("http://localhost:3000/api/actions", {
    method: "POST",
    body: formDataResendBad,
    headers: { Accept: "application/json" },
  });
  const resendBadRes = await actionsPost(resendBadReq);
  const resendBadJson = await resendBadRes.json();
  check(resendBadRes.status === 400 && resendBadJson.ok === false, "Resend OTP for unknown email rejected");

  console.log(`\nHTTP API assertions passed: ${passed}`);
}

testHttpEndpoints()
  .then(() => process.exit(0))
  .catch((err) => {
    console.error(err);
    process.exit(1);
  });
