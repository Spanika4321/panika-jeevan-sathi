import "dotenv/config";
import { and, eq, or } from "drizzle-orm";
import { db } from "../src/db";
import {
  adminUsers,
  announcements,
  blocks,
  comments,
  conversationParticipants,
  conversations,
  emailOtps,
  interests,
  matches,
  messages,
  notifications,
  partnerPreferences,
  passwordResetTokens,
  photos,
  postLikes,
  posts,
  privacySettings,
  profileLikes,
  profiles,
  reports,
  sessions,
  shortlists,
  users,
  verificationRequests,
} from "../src/db/schema";
import {
  hashPassword,
  verifyPassword,
  generateOtp,
  hashSecret,
  isStrongPassword,
} from "../src/lib/security";
import {
  getSearchResults,
  getRecommendedMatches,
  getProfileDetails,
  getInterestsData,
  getConversationList,
  getChat,
  getNotifications,
  getUnreadNotificationCount,
  getFeed,
  getAdminDashboardData,
  getBlockedUsers,
} from "../src/lib/data";
import {
  canUsersMessage,
  createMatchForAcceptedInterest,
  createNotification,
  findOrCreateConversation,
} from "../src/lib/mutations";
import { ADMIN_EMAIL } from "../src/lib/constants";

let passedCount = 0;
let failedCount = 0;

function assert(condition: boolean, testName: string) {
  if (condition) {
    passedCount++;
    console.log(`  ✓ PASS: ${testName}`);
  } else {
    failedCount++;
    console.error(`  ✗ FAIL: ${testName}`);
    throw new Error(`Test failed: ${testName}`);
  }
}

async function runAllTests() {
  console.log("=================================================");
  console.log("STARTING PANIKA JEEVAN SATHI COMPREHENSIVE SUITE");
  console.log("=================================================");

  // 1. Password security tests
  console.log("\n[TEST GROUP 1] Security & Cryptography");
  const rawPw = "SecureP@ss2026!";
  const hashed = hashPassword(rawPw);
  assert(hashed.startsWith("pbkdf2_sha512$"), "Password hash format is PBKDF2 with SHA-512");
  assert(verifyPassword(rawPw, hashed), "Correct password verifies");
  assert(!verifyPassword("WrongPassword123!", hashed), "Incorrect password rejected");
  assert(isStrongPassword(rawPw), "Strong password criteria met");
  assert(!isStrongPassword("short"), "Weak short password rejected");

  const testOtp = generateOtp();
  assert(testOtp.length === 6 && /^\d+$/.test(testOtp), "OTP is 6 numeric digits");
  const otpHash = hashSecret(testOtp);
  assert(hashSecret(testOtp) === otpHash, "Secret hashing is deterministic");

  // Clean up any old test users
  const testEmails = [
    "test.priya@panika.local",
    "test.rahul@panika.local",
    "test.amit@panika.local",
  ];
  for (const email of testEmails) {
    const existing = await db.select({ id: users.id }).from(users).where(eq(users.email, email));
    if (existing[0]) {
      await db.delete(users).where(eq(users.id, existing[0].id));
    }
  }

  // 2. User Registration & Email OTP Flow
  console.log("\n[TEST GROUP 2] Registration & Email OTP Verification");
  // Register User A (Priya, Female, 24)
  const [userA] = await db
    .insert(users)
    .values({
      fullName: "Priya Panika",
      gender: "Female",
      dateOfBirth: "2002-05-15",
      email: "test.priya@panika.local",
      mobile: "+919876543210",
      passwordHash: hashPassword("PriyaPanika@2026"),
      role: "member",
      status: "email_pending",
      emailVerified: false,
    })
    .returning();

  assert(userA !== undefined, "User A registered successfully");
  assert(userA.status === "email_pending", "Initial status is email_pending");
  assert(!userA.emailVerified, "Email verified is false prior to OTP");

  // Insert profile, preferences, privacy
  await db.insert(profiles).values({
    userId: userA.id,
    displayName: userA.fullName,
    headline: "Caring software engineer from Delhi",
    about: "Looking for a well-educated, respectful partner with strong family values.",
    familyDetails: "Father is a teacher, mother is a homemaker.",
    lifestyle: "Vegetarian, non-smoker, enjoys classical music.",
    religion: "Hindu",
    community: "Panika",
    motherTongue: "Hindi",
    maritalStatus: "Never Married",
    education: "B.Tech Computer Science",
    profession: "Software Engineer",
    income: 1200000,
    location: "Delhi, India",
    heightCm: 165,
    approvalStatus: "pending",
    verificationStatus: "unverified",
    visibility: "public",
  });

  await db.insert(partnerPreferences).values({
    userId: userA.id,
    lookingFor: "Male",
    ageMin: 24,
    ageMax: 32,
    location: "Delhi",
    religion: "Hindu",
    community: "Panika",
    motherTongue: "Hindi",
    maritalStatus: "Never Married",
    education: "Graduate",
    incomeMin: 800000,
  });

  await db.insert(privacySettings).values({
    userId: userA.id,
    hidePhone: true,
    hideEmail: true,
    profileVisibility: "public",
  });

  // Generate OTP for User A
  const otpA = generateOtp();
  await db.insert(emailOtps).values({
    userId: userA.id,
    email: userA.email,
    codeHash: hashSecret(otpA),
    purpose: "registration",
    expiresAt: new Date(Date.now() + 15 * 60 * 1000),
  });

  // Verify User A with correct OTP
  await db.update(users).set({ emailVerified: true, status: "active" }).where(eq(users.id, userA.id));
  const [verifiedUserA] = await db.select().from(users).where(eq(users.id, userA.id));
  assert(verifiedUserA.emailVerified === true, "User A email marked verified");
  assert(verifiedUserA.status === "active", "User A status transitioned to active");

  // Register User B (Rahul, Male, 27)
  const [userB] = await db
    .insert(users)
    .values({
      fullName: "Rahul Panika",
      gender: "Male",
      dateOfBirth: "1999-08-20",
      email: "test.rahul@panika.local",
      mobile: "+919876543211",
      passwordHash: hashPassword("RahulPanika@2026"),
      role: "member",
      status: "active",
      emailVerified: true,
    })
    .returning();

  await db.insert(profiles).values({
    userId: userB.id,
    displayName: userB.fullName,
    headline: "Senior Consultant in Delhi NCR",
    about: "Values-driven professional looking for a life partner.",
    familyDetails: "Respected Panika family in Delhi.",
    lifestyle: "Non-smoker, fitness enthusiast.",
    religion: "Hindu",
    community: "Panika",
    motherTongue: "Hindi",
    maritalStatus: "Never Married",
    education: "MBA Finance",
    profession: "Senior Consultant",
    income: 1500000,
    location: "Delhi, India",
    heightCm: 178,
    approvalStatus: "approved",
    verificationStatus: "verified",
    visibility: "public",
  });

  await db.insert(partnerPreferences).values({
    userId: userB.id,
    lookingFor: "Female",
    ageMin: 22,
    ageMax: 28,
    location: "Delhi",
    religion: "Hindu",
    community: "Panika",
    motherTongue: "Hindi",
  });

  await db.insert(privacySettings).values({
    userId: userB.id,
    hidePhone: true,
    hideEmail: true,
    profileVisibility: "public",
  });

  // 3. Profile details & privacy check
  console.log("\n[TEST GROUP 3] Profile Details & Privacy Enforcement");
  // Before User A is approved, guest cannot see User A
  const guestDetailsA = await getProfileDetails(userA.id, null);
  assert(guestDetailsA === null, "Unapproved profile is hidden from guest search/details");

  // Approve User A
  await db.update(profiles).set({ approvalStatus: "approved" }).where(eq(profiles.userId, userA.id));
  const guestDetailsAApproved = await getProfileDetails(userA.id, null);
  assert(guestDetailsAApproved !== null, "Approved profile is accessible to guests");
  assert(guestDetailsAApproved?.canSeePhone === false, "Guest cannot see private phone number");
  assert(guestDetailsAApproved?.canSeeEmail === false, "Guest cannot see private email address");

  // Owner can see their own contact details
  const ownerDetailsA = await getProfileDetails(userA.id, {
    id: userA.id,
    fullName: userA.fullName,
    email: userA.email,
    mobile: userA.mobile,
    gender: userA.gender,
    dateOfBirth: userA.dateOfBirth,
    role: userA.role,
    status: userA.status,
    emailVerified: userA.emailVerified,
  });
  assert(ownerDetailsA !== null && ownerDetailsA.canSeePhone === true, "Owner can see own phone number");
  assert(ownerDetailsA !== null && ownerDetailsA.canSeeEmail === true, "Owner can see own email address");

  // 4. Search and Match Filtering
  console.log("\n[TEST GROUP 4] Match Search & Database Filters");
  const searchFemales = await getSearchResults({ lookingFor: "Female" }, userB.id);
  assert(searchFemales.results.some((p) => p.userId === userA.id), "Gender filter returns female profiles");

  const searchMales = await getSearchResults({ lookingFor: "Male" }, userA.id);
  assert(searchMales.results.some((p) => p.userId === userB.id), "Gender filter returns male profiles");

  const searchAgeFilter = await getSearchResults({ ageMin: "23", ageMax: "26" }, userB.id);
  assert(searchAgeFilter.results.some((p) => p.userId === userA.id), "Age range 23-26 includes 24yo User A");

  const searchReligionFilter = await getSearchResults({ religion: "Hindu", community: "Panika" }, userB.id);
  assert(searchReligionFilter.results.some((p) => p.userId === userA.id), "Religion & community filter matches User A");

  const searchLocationFilter = await getSearchResults({ location: "Delhi" }, userB.id);
  assert(searchLocationFilter.results.some((p) => p.userId === userA.id), "Location filter matches Delhi");

  const searchIncomeFilter = await getSearchResults({ incomeMin: "1000000" }, userB.id);
  assert(searchIncomeFilter.results.some((p) => p.userId === userA.id), "Income filter matches >= 10 Lakh");

  // 5. Recommended Matches & Percentage calculation
  console.log("\n[TEST GROUP 5] Match Percentage & Recommendations");
  const recommendationsForB = await getRecommendedMatches({
    id: userB.id,
    fullName: userB.fullName,
    email: userB.email,
    mobile: userB.mobile,
    gender: userB.gender,
    dateOfBirth: userB.dateOfBirth,
    role: userB.role,
    status: userB.status,
    emailVerified: userB.emailVerified,
  });
  const matchAInRecs = recommendationsForB.find((p) => p.userId === userA.id);
  assert(matchAInRecs !== undefined, "User A is recommended to User B");
  assert((matchAInRecs?.matchPercent ?? 0) >= 80, `High match percentage computed (${matchAInRecs?.matchPercent}%)`);

  // 6. Interest System
  console.log("\n[TEST GROUP 6] Matrimonial Interest System");
  // User B sends interest to User A
  const [interestBA] = await db
    .insert(interests)
    .values({
      senderId: userB.id,
      receiverId: userA.id,
      status: "pending",
      message: "Namaste Priya ji, I found your profile well-aligned with our family values.",
    })
    .returning();

  assert(interestBA.status === "pending", "Interest sent in pending state");

  // Check interests data
  const dataA = await getInterestsData(userA.id);
  assert(dataA.received.some((r) => r.interest.id === interestBA.id), "User A received interest");

  const dataB = await getInterestsData(userB.id);
  assert(dataB.sent.some((s) => s.interest.id === interestBA.id), "User B has sent interest recorded");

  // Before accept, messaging is NOT permitted
  const canMessageBefore = await canUsersMessage(userA.id, userB.id);
  assert(!canMessageBefore, "Messaging blocked prior to interest acceptance");

  // User A accepts interest
  await db.update(interests).set({ status: "accepted" }).where(eq(interests.id, interestBA.id));
  await createMatchForAcceptedInterest(interestBA.id, userB.id, userA.id, 94);

  // Now messaging is permitted
  const canMessageAfter = await canUsersMessage(userA.id, userB.id);
  assert(canMessageAfter, "Messaging unlocked after interest is accepted");

  // Accepted match can now see contact info if privacy allows
  await db.update(privacySettings).set({ hidePhone: false }).where(eq(privacySettings.userId, userA.id));
  const detailsAfterAccept = await getProfileDetails(userA.id, {
    id: userB.id,
    fullName: userB.fullName,
    email: userB.email,
    mobile: userB.mobile,
    gender: userB.gender,
    dateOfBirth: userB.dateOfBirth,
    role: userB.role,
    status: userB.status,
    emailVerified: userB.emailVerified,
  });
  assert(detailsAfterAccept?.canSeePhone === true, "Accepted match can see phone when allowed in privacy settings");

  // 7. Messaging System
  console.log("\n[TEST GROUP 7] Private Messaging System");
  const conversationId = await findOrCreateConversation(userA.id, userB.id);
  assert(conversationId > 0, "Conversation created successfully");

  // User B sends message
  const [msg1] = await db
    .insert(messages)
    .values({
      conversationId,
      senderId: userB.id,
      receiverId: userA.id,
      content: "Hello Priya ji, glad we connected. How are you?",
    })
    .returning();

  assert(msg1.content.includes("glad we connected"), "Message content saved");

  // User A views chat
  const chatA = await getChat(userA.id, conversationId);
  assert(chatA !== null, "User A can read conversation");
  assert((chatA?.messages.length ?? 0) >= 1, "Messages returned in chat");

  // Verify read receipt was marked
  const [readMsg] = await db.select().from(messages).where(eq(messages.id, msg1.id));
  assert(readMsg.readAt !== null, "Read receipt marked upon opening chat");

  // 8. Notifications System
  console.log("\n[TEST GROUP 8] Notifications");
  await createNotification({
    userId: userA.id,
    actorId: userB.id,
    type: "new_interest",
    title: "New Matrimonial Interest",
    body: `${userB.fullName} sent you an interest.`,
    linkUrl: "/interests",
  });

  const unreadCountA = await getUnreadNotificationCount(userA.id);
  assert(unreadCountA >= 1, "Unread notification count reflected");

  const notifsA = await getNotifications(userA.id);
  assert(notifsA.some((n) => n.title.includes("New Matrimonial Interest")), "Notification retrieved");

  // 9. Community Feed & Comments
  console.log("\n[TEST GROUP 9] Community Feed & Posts");
  const [post1] = await db
    .insert(posts)
    .values({
      authorId: userB.id,
      content: "Belief in mutual respect and understanding is the true foundation of marriage.",
      status: "active",
    })
    .returning();

  assert(post1.id > 0, "Feed post created");

  // User A likes post
  await db.insert(postLikes).values({ postId: post1.id, userId: userA.id });

  // User A comments on post
  const [comment1] = await db
    .insert(comments)
    .values({
      postId: post1.id,
      authorId: userA.id,
      content: "Very well said, couldn't agree more.",
    })
    .returning();

  assert(comment1.id > 0, "Feed comment created");

  const feedList = await getFeed(userA.id);
  const foundPost = feedList.find((f) => f.post.id === post1.id);
  assert(foundPost !== undefined, "Post visible in feed");
  assert((foundPost?.likesCount ?? 0) >= 1, "Post like count incremented");
  assert((foundPost?.commentsCount ?? 0) >= 1, "Post comments count incremented");
  assert(foundPost?.likedByMe === true, "likedByMe flag accurately set");

  // 10. Shortlist & Likes
  console.log("\n[TEST GROUP 10] Shortlist & Profile Likes");
  await db.insert(shortlists).values({ userId: userA.id, shortlistedUserId: userB.id }).onConflictDoNothing();
  const shortlistsA = await db.select().from(shortlists).where(eq(shortlists.userId, userA.id));
  assert(shortlistsA.some((s) => s.shortlistedUserId === userB.id), "Profile added to shortlist");

  await db.insert(profileLikes).values({ userId: userA.id, likedUserId: userB.id }).onConflictDoNothing();
  const likesA = await db.select().from(profileLikes).where(eq(profileLikes.userId, userA.id));
  assert(likesA.some((l) => l.likedUserId === userB.id), "Profile liked");

  // 11. Blocking & Safety
  console.log("\n[TEST GROUP 11] Blocking & Safety System");
  await db.insert(blocks).values({ blockerId: userA.id, blockedUserId: userB.id, reason: "Testing safety block" });
  const blockedByA = await getBlockedUsers(userA.id);
  assert(blockedByA.some((b) => b.blockedUserId === userB.id), "User B listed in User A's blocked list");

  // Check that User B is now excluded from User A's search results
  const searchAfterBlock = await getSearchResults({ lookingFor: "Male" }, userA.id);
  assert(!searchAfterBlock.results.some((p) => p.userId === userB.id), "Blocked user excluded from search results");

  // Unblock
  await db.delete(blocks).where(and(eq(blocks.blockerId, userA.id), eq(blocks.blockedUserId, userB.id)));
  const searchAfterUnblock = await getSearchResults({ lookingFor: "Male" }, userA.id);
  assert(searchAfterUnblock.results.some((p) => p.userId === userB.id), "Unblocked user reappears in search");

  // Report user
  const [report1] = await db
    .insert(reports)
    .values({
      reporterId: userA.id,
      reportedUserId: userB.id,
      reason: "Test safety concern",
      details: "Automated test report verification",
      status: "pending",
    })
    .returning();
  assert(report1.status === "pending", "Safety report registered");

  // 12. Admin Controls & Dashboard
  console.log("\n[TEST GROUP 12] Admin Moderation & Management");
  const adminStats = await getAdminDashboardData();
  assert(adminStats.stats.totalUsers >= 2, "Admin stats reflect total registered users");
  assert(adminStats.stats.verifiedProfiles >= 1, "Admin stats reflect verified profiles");
  assert(adminStats.stats.pendingReports >= 1, "Admin stats reflect pending reports");
  assert(adminStats.reports.some((r) => r.report.id === report1.id), "Admin can view safety report");

  // Admin verifies User A
  await db.update(profiles).set({ verificationStatus: "verified" }).where(eq(profiles.userId, userA.id));
  const [verifiedA] = await db.select({ status: profiles.verificationStatus }).from(profiles).where(eq(profiles.userId, userA.id));
  assert(verifiedA.status === "verified", "Admin verified User A profile");

  // Admin suspends and reactivates user
  await db.update(users).set({ status: "suspended" }).where(eq(users.id, userA.id));
  const [suspendedA] = await db.select({ status: users.status }).from(users).where(eq(users.id, userA.id));
  assert(suspendedA.status === "suspended", "Admin suspended User A");

  await db.update(users).set({ status: "active" }).where(eq(users.id, userA.id));
  const [reactivatedA] = await db.select({ status: users.status }).from(users).where(eq(users.id, userA.id));
  assert(reactivatedA.status === "active", "Admin reactivated User A");

  // Admin announcement broadcast
  const [announcement] = await db
    .insert(announcements)
    .values({
      title: "Welcome to Panika Jeevan Sathi",
      body: "Our community welcomes new members. Please maintain respectful communication.",
      audience: "all",
    })
    .returning();
  assert(announcement.id > 0, "Admin announcement published");

  // Clean up test data
  console.log("\n[CLEANUP] Removing test artifacts");
  await db.delete(reports).where(eq(reports.id, report1.id));
  await db.delete(announcements).where(eq(announcements.id, announcement.id));
  await db.delete(comments).where(eq(comments.id, comment1.id));
  await db.delete(posts).where(eq(posts.id, post1.id));
  await db.delete(users).where(or(eq(users.id, userA.id), eq(users.id, userB.id)));

  console.log("\n=================================================");
  console.log(`PANIKA JEEVAN SATHI TEST RESULTS:`);
  console.log(`Passed: ${passedCount}`);
  console.log(`Failed: ${failedCount}`);
  console.log("=================================================");
}

runAllTests()
  .then(() => {
    console.log("SUCCESS: All functional test suites passed!");
    process.exit(0);
  })
  .catch((err) => {
    console.error("FATAL: Test suite encountered an error:", err);
    process.exit(1);
  });
