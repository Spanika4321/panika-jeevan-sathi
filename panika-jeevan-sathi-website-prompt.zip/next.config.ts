import path from "path";
import type { NextConfig } from "next";

const customOrigins = process.env.ALLOWED_ORIGINS
  ? process.env.ALLOWED_ORIGINS.split(",").map((o) => o.trim()).filter(Boolean)
  : [];

// Fallback origins for local development/testing only. Production origins should
// always be supplied via the ALLOWED_ORIGINS environment variable.
const devFallbackOrigins = ["localhost:3000", "127.0.0.1:3000", "localhost", "127.0.0.1"];

const nextConfig: NextConfig = {
  poweredByHeader: false,
  reactStrictMode: true,
  productionBrowserSourceMaps: false,
  experimental: {
    cpus: 1,
    workerThreads: false,
    serverActions: {
      allowedOrigins: [...customOrigins, ...devFallbackOrigins],
    },
  },
  webpack: (config) => {
    config.resolve.alias = {
      ...(config.resolve.alias || {}),
      "@": path.resolve(process.cwd(), "src"),
    };
    return config;
  },
};

export default nextConfig;
