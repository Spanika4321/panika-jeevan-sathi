# Panika Jeevan Sathi — Final cPanel Production Deployment Guide

**ZIP file:** `panika-jeevan-sathi-cpanel-final.zip`
**Target deployment path:** `/home/panikaje/panika-jeevan-sathi`

This ZIP contains the **complete prebuilt production `.next` build**. You do **NOT** need to run `next build` (or `npm run build`) on the cPanel server — that step was already completed and tested before packaging. cPanel only needs to install dependencies and start the app directly from the prebuilt bundle.

---

## 1. Upload and Extract

1. Log into cPanel.
2. Open **File Manager**.
3. Navigate to (or create) the folder: `/home/panikaje/panika-jeevan-sathi`
4. Upload `panika-jeevan-sathi-cpanel-final.zip` **into that folder**.
5. Right-click the ZIP → **Extract**. Make sure you extract it *inside* `/home/panikaje/panika-jeevan-sathi` (the ZIP's contents are already flat at the root — do not create an extra nested subfolder).
6. In File Manager **Settings** (top-right gear icon), enable **Show Hidden Files**.
7. Confirm the following exist directly inside `/home/panikaje/panika-jeevan-sathi`:
   - `.next/` (prebuilt production build — contains `BUILD_ID`)
   - `public/`
   - `src/`
   - `server.js`
   - `app.js`
   - `package.json`
   - `package-lock.json`
8. Delete the ZIP file from the server after extraction (optional, saves disk space).

Folder structure after extraction:
```
/home/panikaje/panika-jeevan-sathi/
├── .next/              (prebuilt production build — DO NOT DELETE, DO NOT REBUILD)
│   └── BUILD_ID
├── public/
├── src/
├── server.js            (production server — startup file for cPanel)
├── app.js                (alternate startup file, delegates to server.js)
├── package.json
├── package-lock.json
├── next.config.ts
├── tsconfig.json
├── jsconfig.json
├── drizzle.config.ts
├── postcss.config.mjs
├── eslint.config.mjs
├── next-env.d.ts
├── .env.example          (copy this to .env and fill in real values)
└── CPANEL_DEPLOYMENT_GUIDE.md
```

---

## 2. Create the Node.js Application in cPanel

1. In cPanel, open **Setup Node.js App** (under *Software*).
2. Click **Create Application**:
   - **Node.js version**: `24.19.0` (or the closest available 20.x / 22.x version).
   - **Application mode**: `Production`.
   - **Application root**: `panika-jeevan-sathi` (relative to your home directory — resolves to `/home/panikaje/panika-jeevan-sathi`).
   - **Application URL**: select your domain (e.g. `panikajeevansathi.coolstore.in`).
   - **Application startup file**: `server.js`
3. Click **Create**.

cPanel automatically assigns a port and injects it as `process.env.PORT` when the app starts. `server.js` reads `process.env.PORT` directly (with `3000` only as a safe fallback if `PORT` is ever unset) — **no code changes are needed for this.**

---

## 3. Set Environment Variables

**Never** put real secrets inside the ZIP or any file you upload/share. Set the following directly in cPanel's **Setup Node.js App → Environment Variables** panel (recommended), or in a `.env` file created **directly on the server after extraction** (not included in the ZIP).

| Variable | Example / Required Value |
|---|---|
| `SITE_URL` | `https://panikajeevansathi.coolstore.in` |
| `NEXT_PUBLIC_SITE_URL` | `https://panikajeevansathi.coolstore.in` |
| `ALLOWED_ORIGINS` | `panikajeevansathi.coolstore.in,www.panikajeevansathi.coolstore.in` |
| `NODE_ENV` | `production` |
| `DATABASE_URL` | *(your real PostgreSQL connection string — get from cPanel → PostgreSQL Databases)* |
| `SMTP_HOST` | `mail.panikajeevansathi.coolstore.in` |
| `SMTP_PORT` | `465` |
| `SMTP_USER` | `contact@panikajeevansathi.coolstore.in` |
| `SMTP_PASS` | *(your real email account password — get from cPanel → Email Accounts)* |
| `SMTP_SECURE` | `true` |
| `SMTP_FROM` | `"Panika Jeevan Sathi" <contact@panikajeevansathi.coolstore.in>` |
| `DB_POOL_MAX` | `10` |

**Do not set `PORT` manually** — cPanel's Node.js Application Manager assigns this automatically.

To use a `.env` file instead of the cPanel UI: copy `.env.example` to `.env` in the application root and fill in the same real values. This file must stay only on the server and never be re-uploaded, zipped, or shared.

---

## 4. Install Dependencies

1. On the **Setup Node.js App** page, copy the "Enter to the virtual environment" command shown at the top, for example:
   ```bash
   source /home/panikaje/nodevenv/panika-jeevan-sathi/24/bin/activate && cd /home/panikaje/panika-jeevan-sathi
   ```
2. Open cPanel **Terminal** and run that command.
3. Install dependencies:
   ```bash
   npm install
   ```
   This only installs `node_modules`. It does **not** rebuild the app — `.next` is already prebuilt and included in the ZIP.

---

## 5. Apply the Database Schema

Push the Drizzle ORM schema to your PostgreSQL database (uses the `DATABASE_URL` you set in Step 3):
```bash
npx drizzle-kit push
```

---

## 6. Start the Application

1. Return to **Setup Node.js App** in cPanel.
2. Click **Restart** (or **Start App**).
3. cPanel runs:
   ```bash
   npm start
   ```
   which executes `node server.js` directly — the production server starts immediately from the prebuilt `.next` bundle, with **no build step on the server.**
4. Visit your domain (e.g. `https://panikajeevansathi.coolstore.in`) to confirm the site loads.

---

## 7. Updating the Site Later (Optional — done on your own machine, not on cPanel)

If you ever need to change the code:
1. Make your changes in a development environment with sufficient memory.
2. Run:
   ```bash
   npm install
   npm run build
   ```
3. Confirm the build completes with zero errors and `.next/BUILD_ID` is regenerated.
4. Package the updated project (including the new `.next` folder) into a ZIP and re-upload it to `/home/panikaje/panika-jeevan-sathi`, replacing the old files.
5. Restart the app in cPanel **Setup Node.js App**.

This keeps the memory-constrained cPanel server from ever needing to run `next build` itself.

---

## Admin Access

- **Admin Panel URL**: `https://panikajeevansathi.coolstore.in/admin`
- Log in using the admin account's registered email and password to access user management, profile approvals, verification requests, safety reports, and platform announcements.
